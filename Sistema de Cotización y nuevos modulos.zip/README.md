
  # Sistema de Cotización de Servicios Técnicos

  This is a code bundle for Sistema de Cotización de Servicios Técnicos. The original project is available at https://www.figma.com/design/TXs5SvxqoORJSF8qHGRFCS/Sistema-de-Cotizaci%C3%B3n-de-Servicios-T%C3%A9cnicos.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  