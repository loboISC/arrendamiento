-- =====================================================
-- CONSULTAS SQL IMPORTANTES PARA EL SISTEMA
-- Sistema de Cotizaciones TecnoSeguridad Pro
-- =====================================================

-- =====================================================
-- 1. CONSULTAS PARA COTIZACIONES
-- =====================================================

-- Obtener cotización completa con todos sus datos
CREATE OR REPLACE VIEW quotation_details AS
SELECT 
    q.*,
    c.company_name,
    c.contact_name,
    c.contact_email,
    c.contact_phone,
    c.address,
    c.tax_id,
    u.first_name || ' ' || u.last_name AS advisor_name,
    u.email AS advisor_email,
    u.department AS advisor_department,
    (
        SELECT COUNT(*) 
        FROM quotation_items qi 
        WHERE qi.quotation_id = q.id
    ) AS items_count,
    (
        SELECT jsonb_agg(
            jsonb_build_object(
                'id', qi.id,
                'service_name', qi.service_name,
                'quantity', qi.quantity,
                'unit_price', qi.unit_price,
                'total_price', qi.total_price,
                'scheduled_date', qi.scheduled_date,
                'location', qi.location,
                'scaffold_type', st.name,
                'observations', qi.observations
            ) ORDER BY qi.sort_order
        )
        FROM quotation_items qi
        LEFT JOIN scaffold_types st ON qi.scaffold_type_id = st.id
        WHERE qi.quotation_id = q.id
    ) AS items
FROM quotations q
JOIN clients c ON q.client_id = c.id
JOIN users u ON q.advisor_id = u.id;

-- Consulta para dashboard del asesor
SELECT 
    COUNT(*) FILTER (WHERE status = 'draft') AS draft_count,
    COUNT(*) FILTER (WHERE status = 'generated') AS generated_count,
    COUNT(*) FILTER (WHERE status = 'sent') AS sent_count,
    COUNT(*) FILTER (WHERE status = 'approved') AS approved_count,
    SUM(total_amount) FILTER (WHERE status = 'approved' AND created_at >= date_trunc('month', CURRENT_DATE)) AS monthly_approved_value,
    SUM(total_amount) FILTER (WHERE status IN ('generated', 'sent', 'approved') AND created_at >= date_trunc('month', CURRENT_DATE)) AS monthly_total_value
FROM quotations 
WHERE advisor_id = $1 -- ID del asesor
AND created_at >= date_trunc('year', CURRENT_DATE);

-- Cotizaciones próximas a vencer
SELECT 
    q.id,
    q.quotation_number,
    q.valid_until,
    c.company_name,
    q.total_amount,
    q.status,
    (q.valid_until - CURRENT_DATE) AS days_until_expiry
FROM quotations q
JOIN clients c ON q.client_id = c.id
WHERE q.status IN ('generated', 'sent', 'viewed')
AND q.valid_until BETWEEN CURRENT_DATE AND (CURRENT_DATE + INTERVAL '7 days')
ORDER BY q.valid_until ASC;

-- =====================================================
-- 2. CONSULTAS PARA FACTURAS
-- =====================================================

-- Vista completa de facturas
CREATE OR REPLACE VIEW invoice_details AS
SELECT 
    i.*,
    c.company_name,
    c.contact_name,
    c.contact_email,
    c.tax_id,
    u.first_name || ' ' || u.last_name AS advisor_name,
    q.quotation_number,
    (i.due_date - CURRENT_DATE) AS days_until_due,
    CASE 
        WHEN i.due_date < CURRENT_DATE AND i.status != 'paid' THEN 'overdue'
        ELSE i.status
    END AS current_status
FROM invoices i
JOIN clients c ON i.client_id = c.id
JOIN users u ON i.advisor_id = u.id
JOIN quotations q ON i.quotation_id = q.id;

-- Facturas vencidas
SELECT 
    i.id,
    i.invoice_number,
    i.due_date,
    c.company_name,
    i.balance_due,
    (CURRENT_DATE - i.due_date) AS days_overdue
FROM invoices i
JOIN clients c ON i.client_id = c.id
WHERE i.due_date < CURRENT_DATE 
AND i.status NOT IN ('paid', 'cancelled')
ORDER BY i.due_date ASC;

-- Estado de cartera por asesor
SELECT 
    u.first_name || ' ' || u.last_name AS advisor_name,
    COUNT(i.id) AS total_invoices,
    SUM(i.total_amount) AS total_invoiced,
    SUM(i.paid_amount) AS total_collected,
    SUM(i.balance_due) AS total_pending,
    COUNT(*) FILTER (WHERE i.due_date < CURRENT_DATE AND i.status != 'paid') AS overdue_count,
    SUM(i.balance_due) FILTER (WHERE i.due_date < CURRENT_DATE AND i.status != 'paid') AS overdue_amount
FROM invoices i
JOIN users u ON i.advisor_id = u.id
WHERE i.created_at >= date_trunc('year', CURRENT_DATE)
GROUP BY u.id, u.first_name, u.last_name
ORDER BY total_pending DESC;

-- =====================================================
-- 3. CONSULTAS PARA REPORTES
-- =====================================================

-- Reporte mensual de ventas
SELECT 
    date_trunc('month', q.created_at) AS month,
    COUNT(*) AS quotations_count,
    COUNT(*) FILTER (WHERE q.status = 'approved') AS approved_count,
    SUM(q.total_amount) AS total_quoted,
    SUM(q.total_amount) FILTER (WHERE q.status = 'approved') AS total_approved,
    ROUND(
        (COUNT(*) FILTER (WHERE q.status = 'approved')::DECIMAL / COUNT(*)) * 100, 2
    ) AS approval_rate
FROM quotations q
WHERE q.created_at >= date_trunc('year', CURRENT_DATE)
GROUP BY date_trunc('month', q.created_at)
ORDER BY month;

-- Servicios más cotizados
SELECT 
    s.name AS service_name,
    COUNT(qi.id) AS times_quoted,
    SUM(qi.quantity) AS total_quantity,
    SUM(qi.total_price) AS total_value,
    AVG(qi.unit_price) AS avg_unit_price
FROM quotation_items qi
JOIN services s ON qi.service_id = s.id
JOIN quotations q ON qi.quotation_id = q.id
WHERE q.created_at >= date_trunc('month', CURRENT_DATE)
GROUP BY s.id, s.name
ORDER BY times_quoted DESC;

-- Clientes más activos
SELECT 
    c.company_name,
    c.contact_name,
    COUNT(q.id) AS quotations_count,
    COUNT(*) FILTER (WHERE q.status = 'approved') AS approved_count,
    SUM(q.total_amount) AS total_quoted,
    SUM(q.total_amount) FILTER (WHERE q.status = 'approved') AS total_approved,
    MAX(q.created_at) AS last_quotation_date
FROM clients c
LEFT JOIN quotations q ON c.id = q.client_id
WHERE q.created_at >= date_trunc('year', CURRENT_DATE) OR q.created_at IS NULL
GROUP BY c.id, c.company_name, c.contact_name
ORDER BY total_approved DESC NULLS LAST;

-- =====================================================
-- 4. CONSULTAS PARA ADMINISTRACIÓN
-- =====================================================

-- Resumen ejecutivo del sistema
SELECT 
    (SELECT COUNT(*) FROM users WHERE status = 'active') AS active_users,
    (SELECT COUNT(*) FROM clients WHERE status = 'active') AS active_clients,
    (SELECT COUNT(*) FROM quotations WHERE created_at >= date_trunc('month', CURRENT_DATE)) AS monthly_quotations,
    (SELECT COUNT(*) FROM invoices WHERE created_at >= date_trunc('month', CURRENT_DATE)) AS monthly_invoices,
    (SELECT SUM(total_amount) FROM quotations WHERE status = 'approved' AND created_at >= date_trunc('month', CURRENT_DATE)) AS monthly_approved_value,
    (SELECT SUM(balance_due) FROM invoices WHERE status NOT IN ('paid', 'cancelled')) AS total_pending_collection;

-- Actividad del sistema por usuario
SELECT 
    u.first_name || ' ' || u.last_name AS user_name,
    u.department,
    COUNT(al.id) AS total_actions,
    MAX(al.created_at) AS last_activity,
    COUNT(DISTINCT al.entity_id) FILTER (WHERE al.entity_type = 'quotation') AS quotations_touched,
    COUNT(DISTINCT al.entity_id) FILTER (WHERE al.entity_type = 'invoice') AS invoices_touched
FROM users u
LEFT JOIN activity_logs al ON u.id = al.user_id AND al.created_at >= CURRENT_DATE - INTERVAL '30 days'
WHERE u.status = 'active'
GROUP BY u.id, u.first_name, u.last_name, u.department
ORDER BY last_activity DESC NULLS LAST;

-- =====================================================
-- 5. FUNCIONES ÚTILES
-- =====================================================

-- Función para calcular totales de cotización
CREATE OR REPLACE FUNCTION calculate_quotation_totals(quotation_uuid UUID)
RETURNS TABLE(
    subtotal DECIMAL(15,2),
    tax_amount DECIMAL(15,2),
    total_amount DECIMAL(15,2)
) AS $$
DECLARE
    quote_record RECORD;
    calculated_subtotal DECIMAL(15,2);
    calculated_tax DECIMAL(15,2);
    calculated_total DECIMAL(15,2);
BEGIN
    -- Obtener información de la cotización
    SELECT * INTO quote_record FROM quotations WHERE id = quotation_uuid;
    
    -- Calcular subtotal
    SELECT COALESCE(SUM(qi.total_price), 0) INTO calculated_subtotal
    FROM quotation_items qi
    WHERE qi.quotation_id = quotation_uuid;
    
    -- Aplicar descuento
    calculated_subtotal := calculated_subtotal - COALESCE(quote_record.discount_amount, 0);
    
    -- Calcular impuestos
    calculated_tax := calculated_subtotal * (COALESCE(quote_record.tax_percentage, 0) / 100);
    
    -- Calcular total
    calculated_total := calculated_subtotal + calculated_tax;
    
    -- Actualizar la cotización
    UPDATE quotations 
    SET 
        subtotal = calculated_subtotal,
        tax_amount = calculated_tax,
        total_amount = calculated_total,
        updated_at = NOW()
    WHERE id = quotation_uuid;
    
    RETURN QUERY SELECT calculated_subtotal, calculated_tax, calculated_total;
END;
$$ LANGUAGE plpgsql;

-- Función para generar PDF de cotización (placeholder)
CREATE OR REPLACE FUNCTION generate_quotation_pdf(quotation_uuid UUID)
RETURNS UUID AS $$
DECLARE
    document_id UUID;
    quotation_data RECORD;
    filename VARCHAR(255);
BEGIN
    -- Obtener datos de la cotización
    SELECT * INTO quotation_data 
    FROM quotation_details 
    WHERE id = quotation_uuid;
    
    -- Generar nombre del archivo
    filename := quotation_data.quotation_number || '_cotizacion.pdf';
    
    -- Insertar registro del documento
    INSERT INTO documents (
        entity_type,
        entity_id,
        document_type,
        filename,
        original_filename,
        file_path,
        title,
        uploaded_by,
        created_at
    ) VALUES (
        'quotation',
        quotation_uuid,
        'pdf',
        filename,
        filename,
        '/documents/quotations/' || quotation_uuid || '/' || filename,
        'Cotización ' || quotation_data.quotation_number,
        quotation_data.advisor_id,
        NOW()
    ) RETURNING id INTO document_id;
    
    -- Aquí iría la lógica para generar el PDF real
    -- Por ahora solo retornamos el ID del documento
    
    RETURN document_id;
END;
$$ LANGUAGE plpgsql;

-- =====================================================
-- 6. TRIGGERS ADICIONALES
-- =====================================================

-- Trigger para recalcular totales cuando se modifican items
CREATE OR REPLACE FUNCTION recalculate_quotation_totals()
RETURNS TRIGGER AS $$
BEGIN
    -- Recalcular totales de la cotización
    PERFORM calculate_quotation_totals(
        CASE 
            WHEN TG_OP = 'DELETE' THEN OLD.quotation_id
            ELSE NEW.quotation_id
        END
    );
    
    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER quotation_items_totals_trigger
    AFTER INSERT OR UPDATE OR DELETE ON quotation_items
    FOR EACH ROW EXECUTE FUNCTION recalculate_quotation_totals();

-- Trigger para log de actividades
CREATE OR REPLACE FUNCTION log_activity()
RETURNS TRIGGER AS $$
DECLARE
    entity_type_name VARCHAR(50);
    action_name VARCHAR(100);
    entity_id_value UUID;
BEGIN
    -- Determinar el tipo de entidad y acción
    entity_type_name := TG_TABLE_NAME;
    action_name := TG_OP;
    
    entity_id_value := CASE 
        WHEN TG_OP = 'DELETE' THEN OLD.id
        ELSE NEW.id
    END;
    
    -- Insertar log de actividad
    INSERT INTO activity_logs (
        user_id,
        action,
        entity_type,
        entity_id,
        details,
        created_at
    ) VALUES (
        CASE 
            WHEN TG_OP = 'DELETE' AND entity_type_name = 'quotations' THEN OLD.advisor_id
            WHEN entity_type_name = 'quotations' THEN NEW.advisor_id
            WHEN TG_OP = 'DELETE' AND entity_type_name = 'invoices' THEN OLD.advisor_id
            WHEN entity_type_name = 'invoices' THEN NEW.advisor_id
            ELSE NULL
        END,
        action_name,
        entity_type_name,
        entity_id_value,
        jsonb_build_object(
            'table', TG_TABLE_NAME,
            'operation', TG_OP,
            'timestamp', NOW()
        ),
        NOW()
    );
    
    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

-- Aplicar trigger de logging a tablas importantes
CREATE TRIGGER quotations_activity_log
    AFTER INSERT OR UPDATE OR DELETE ON quotations
    FOR EACH ROW EXECUTE FUNCTION log_activity();

CREATE TRIGGER invoices_activity_log
    AFTER INSERT OR UPDATE OR DELETE ON invoices
    FOR EACH ROW EXECUTE FUNCTION log_activity();

-- =====================================================
-- COMENTARIOS SOBRE LAS CONSULTAS
-- =====================================================

/*
ESTAS CONSULTAS CUBREN:

1. OPERACIONES BÁSICAS:
   - Obtener cotizaciones completas con todos los datos relacionados
   - Calcular totales automáticamente
   - Generar documentos PDF

2. DASHBOARDS Y REPORTES:
   - Métricas para asesores
   - Estados de cartera
   - Reportes de ventas mensuales
   - Análisis de servicios más vendidos

3. ADMINISTRACIÓN:
   - Monitoreo de actividad del sistema
   - Resúmenes ejecutivos
   - Gestión de vencimientos

4. AUTOMATIZACIÓN:
   - Triggers para mantener consistencia
   - Funciones para cálculos complejos
   - Logging automático de actividades

5. OPTIMIZACIÓN:
   - Vistas materializadas para consultas frecuentes
   - Índices apropiados para performance
   - Funciones para operaciones complejas

USO RECOMENDADO:
- Estas consultas están listas para ser integradas en una API REST
- Cada consulta incluye los parámetros necesarios ($1, $2, etc.)
- Las vistas simplifican las consultas desde la aplicación
- Los triggers mantienen la integridad automáticamente
*/