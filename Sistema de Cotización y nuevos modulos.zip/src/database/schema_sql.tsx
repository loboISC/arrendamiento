-- =====================================================
-- SISTEMA DE COTIZACIONES TECNOSEGURIDAD PRO
-- Esquema de Base de Datos PostgreSQL
-- =====================================================

-- Extensiones necesarias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =====================================================
-- 1. USUARIOS Y AUTENTICACIÓN
-- =====================================================

-- Tabla de usuarios del sistema (asesores, administradores)
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    employee_id VARCHAR(50) UNIQUE,
    department VARCHAR(100) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'advisor', -- advisor, manager, admin
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- active, inactive, suspended
    avatar_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_login_at TIMESTAMP WITH TIME ZONE
);

-- Tabla de sesiones de usuario
CREATE TABLE user_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- 2. CLIENTES
-- =====================================================

-- Tabla de clientes
CREATE TABLE clients (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_name VARCHAR(255) NOT NULL,
    tax_id VARCHAR(50), -- NIT en Colombia
    contact_name VARCHAR(255) NOT NULL,
    contact_email VARCHAR(255) NOT NULL,
    contact_phone VARCHAR(20) NOT NULL,
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100) DEFAULT 'Colombia',
    postal_code VARCHAR(20),
    industry VARCHAR(100),
    client_type VARCHAR(50) DEFAULT 'regular', -- regular, vip, corporate
    payment_terms INTEGER DEFAULT 30, -- días de pago
    preferred_payment_method VARCHAR(50) DEFAULT 'transferencia',
    credit_limit DECIMAL(15,2),
    notes TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- active, inactive
    created_by UUID NOT NULL REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Contactos adicionales del cliente
CREATE TABLE client_contacts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(20),
    position VARCHAR(100),
    is_primary BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- 3. SERVICIOS Y PRECIOS
-- =====================================================

-- Catálogo de servicios
CREATE TABLE services (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    service_code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    service_type VARCHAR(50) NOT NULL, -- curso, inspeccion, inspeccion-liberacion
    base_price DECIMAL(15,2),
    unit VARCHAR(50), -- por persona, por andamio, por día
    duration_hours INTEGER,
    requirements TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- active, inactive
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Precios especiales por cliente o volumen
CREATE TABLE service_pricing (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    service_id UUID NOT NULL REFERENCES services(id) ON DELETE CASCADE,
    client_id UUID REFERENCES clients(id), -- NULL para precios generales
    price DECIMAL(15,2) NOT NULL,
    min_quantity INTEGER DEFAULT 1,
    max_quantity INTEGER,
    valid_from DATE NOT NULL,
    valid_until DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tipos de andamios (para servicios de inspección)
CREATE TABLE scaffold_types (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    base_inspection_price DECIMAL(15,2),
    complexity_factor DECIMAL(3,2) DEFAULT 1.0,
    is_active BOOLEAN DEFAULT TRUE
);

-- =====================================================
-- 4. COTIZACIONES
-- =====================================================

-- Tabla principal de cotizaciones
CREATE TABLE quotations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    quotation_number VARCHAR(50) UNIQUE NOT NULL,
    client_id UUID NOT NULL REFERENCES clients(id),
    advisor_id UUID NOT NULL REFERENCES users(id),
    status VARCHAR(30) NOT NULL DEFAULT 'draft', 
    -- draft, generated, sent, viewed, approved, rejected, expired, invoiced
    
    -- Fechas importantes
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    generated_at TIMESTAMP WITH TIME ZONE,
    sent_at TIMESTAMP WITH TIME ZONE,
    viewed_at TIMESTAMP WITH TIME ZONE,
    valid_until DATE NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE,
    
    -- Información financiera
    subtotal DECIMAL(15,2) NOT NULL DEFAULT 0,
    discount_percentage DECIMAL(5,2) DEFAULT 0,
    discount_amount DECIMAL(15,2) DEFAULT 0,
    tax_percentage DECIMAL(5,2) DEFAULT 19, -- IVA Colombia
    tax_amount DECIMAL(15,2) DEFAULT 0,
    total_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
    currency VARCHAR(3) DEFAULT 'COP',
    
    -- Información adicional
    client_notes TEXT,
    internal_notes TEXT,
    terms_and_conditions TEXT,
    
    -- Configuración
    auto_expire BOOLEAN DEFAULT TRUE,
    email_notifications BOOLEAN DEFAULT TRUE,
    
    -- Referencias
    parent_quotation_id UUID REFERENCES quotations(id), -- Para revisiones
    version INTEGER DEFAULT 1
);

-- Items/servicios dentro de cada cotización
CREATE TABLE quotation_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    quotation_id UUID NOT NULL REFERENCES quotations(id) ON DELETE CASCADE,
    service_id UUID NOT NULL REFERENCES services(id),
    
    -- Detalles del servicio
    service_name VARCHAR(255) NOT NULL, -- Snapshot del nombre
    service_description TEXT,
    quantity INTEGER NOT NULL DEFAULT 1,
    unit_price DECIMAL(15,2) NOT NULL,
    total_price DECIMAL(15,2) NOT NULL,
    
    -- Campos específicos según el tipo de servicio
    scaffold_type_id UUID REFERENCES scaffold_types(id),
    scheduled_date DATE,
    location TEXT,
    duration_hours INTEGER,
    participants_count INTEGER, -- Para cursos
    
    -- Configuraciones adicionales
    observations TEXT,
    requirements TEXT,
    
    -- Orden en la cotización
    sort_order INTEGER DEFAULT 0,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- 5. FACTURAS
-- =====================================================

-- Tabla principal de facturas
CREATE TABLE invoices (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    invoice_number VARCHAR(50) UNIQUE NOT NULL,
    quotation_id UUID NOT NULL REFERENCES quotations(id),
    client_id UUID NOT NULL REFERENCES clients(id),
    advisor_id UUID NOT NULL REFERENCES users(id),
    
    -- Fechas
    issue_date DATE NOT NULL,
    due_date DATE NOT NULL,
    paid_date DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Información financiera
    subtotal DECIMAL(15,2) NOT NULL,
    discount_amount DECIMAL(15,2) DEFAULT 0,
    tax_percentage DECIMAL(5,2) NOT NULL,
    tax_amount DECIMAL(15,2) NOT NULL,
    total_amount DECIMAL(15,2) NOT NULL,
    paid_amount DECIMAL(15,2) DEFAULT 0,
    balance_due DECIMAL(15,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'COP',
    
    -- Estado y términos
    status VARCHAR(30) NOT NULL DEFAULT 'pending',
    -- pending, sent, viewed, partial_paid, paid, overdue, cancelled
    payment_terms INTEGER NOT NULL DEFAULT 30, -- días
    payment_method VARCHAR(50),
    
    -- Información adicional
    notes TEXT,
    internal_notes TEXT,
    late_fee_percentage DECIMAL(5,2) DEFAULT 0,
    
    -- Configuración
    auto_reminders BOOLEAN DEFAULT TRUE,
    reminder_days_before INTEGER DEFAULT 3
);

-- Items de factura (copia de los items de cotización)
CREATE TABLE invoice_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    invoice_id UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    quotation_item_id UUID REFERENCES quotation_items(id),
    
    -- Snapshot de la información al momento de facturar
    service_name VARCHAR(255) NOT NULL,
    service_description TEXT,
    quantity INTEGER NOT NULL,
    unit_price DECIMAL(15,2) NOT NULL,
    total_price DECIMAL(15,2) NOT NULL,
    
    -- Información específica
    scheduled_date DATE,
    location TEXT,
    observations TEXT,
    
    sort_order INTEGER DEFAULT 0
);

-- Pagos recibidos
CREATE TABLE invoice_payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    invoice_id UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    payment_date DATE NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    reference_number VARCHAR(100),
    notes TEXT,
    created_by UUID NOT NULL REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- 6. ARCHIVOS Y DOCUMENTOS
-- =====================================================

-- Almacenamiento de archivos PDF y documentos
CREATE TABLE documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_type VARCHAR(50) NOT NULL, -- quotation, invoice, contract
    entity_id UUID NOT NULL,
    document_type VARCHAR(50) NOT NULL, -- pdf, contract, attachment
    
    -- Información del archivo
    filename VARCHAR(255) NOT NULL,
    original_filename VARCHAR(255),
    file_size BIGINT,
    mime_type VARCHAR(100),
    file_path TEXT NOT NULL, -- Ruta en el storage
    file_url TEXT, -- URL pública si aplica
    
    -- Metadatos
    title VARCHAR(255),
    description TEXT,
    version INTEGER DEFAULT 1,
    language VARCHAR(10) DEFAULT 'es',
    
    -- Estado
    status VARCHAR(20) DEFAULT 'active', -- active, archived, deleted
    is_public BOOLEAN DEFAULT FALSE,
    
    -- Auditoría
    uploaded_by UUID NOT NULL REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    accessed_at TIMESTAMP WITH TIME ZONE
);

-- Configuración de templates de documentos
CREATE TABLE document_templates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL, -- quotation_pdf, invoice_pdf, contract
    template_data JSONB, -- Configuración del template
    is_default BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    created_by UUID NOT NULL REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- 7. AUDITORÍA Y LOGS
-- =====================================================

-- Log de actividades del sistema
CREATE TABLE activity_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id UUID NOT NULL,
    details JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Historial de cambios de estado
CREATE TABLE status_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_type VARCHAR(50) NOT NULL, -- quotation, invoice
    entity_id UUID NOT NULL,
    old_status VARCHAR(30),
    new_status VARCHAR(30) NOT NULL,
    changed_by UUID REFERENCES users(id),
    reason TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Notificaciones del sistema
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type VARCHAR(50) NOT NULL, -- email, system, sms
    title VARCHAR(255) NOT NULL,
    message TEXT,
    entity_type VARCHAR(50),
    entity_id UUID,
    
    -- Estado
    status VARCHAR(20) DEFAULT 'pending', -- pending, sent, read, failed
    sent_at TIMESTAMP WITH TIME ZONE,
    read_at TIMESTAMP WITH TIME ZONE,
    
    -- Configuración
    priority VARCHAR(20) DEFAULT 'normal', -- low, normal, high, urgent
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- 8. CONFIGURACIÓN DEL SISTEMA
-- =====================================================

-- Configuraciones generales
CREATE TABLE system_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    data_type VARCHAR(20) DEFAULT 'string', -- string, number, boolean, json
    description TEXT,
    is_public BOOLEAN DEFAULT FALSE, -- Si es visible para usuarios no admin
    updated_by UUID REFERENCES users(id),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Numeración automática
CREATE TABLE number_sequences (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sequence_type VARCHAR(50) UNIQUE NOT NULL, -- quotation, invoice
    prefix VARCHAR(20) NOT NULL,
    current_number INTEGER NOT NULL DEFAULT 1,
    year INTEGER,
    reset_yearly BOOLEAN DEFAULT TRUE,
    format VARCHAR(100), -- COT-{YYYY}-{000000}
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- 9. ÍNDICES PARA OPTIMIZACIÓN
-- =====================================================

-- Índices principales
CREATE INDEX idx_quotations_advisor_status ON quotations(advisor_id, status);
CREATE INDEX idx_quotations_client_created ON quotations(client_id, created_at);
CREATE INDEX idx_quotations_number ON quotations(quotation_number);
CREATE INDEX idx_quotations_valid_until ON quotations(valid_until);

CREATE INDEX idx_invoices_client_status ON invoices(client_id, status);
CREATE INDEX idx_invoices_due_date ON invoices(due_date);
CREATE INDEX idx_invoices_number ON invoices(invoice_number);

CREATE INDEX idx_clients_company ON clients(company_name);
CREATE INDEX idx_clients_email ON clients(contact_email);

CREATE INDEX idx_documents_entity ON documents(entity_type, entity_id);
CREATE INDEX idx_activity_logs_user_created ON activity_logs(user_id, created_at);

-- =====================================================
-- 10. TRIGGERS Y FUNCIONES
-- =====================================================

-- Función para actualizar updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers para updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_clients_updated_at BEFORE UPDATE ON clients
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_quotations_updated_at BEFORE UPDATE ON quotations
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_invoices_updated_at BEFORE UPDATE ON invoices
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Función para generar números de cotización
CREATE OR REPLACE FUNCTION generate_quotation_number()
RETURNS TRIGGER AS $$
DECLARE
    current_year INTEGER := EXTRACT(YEAR FROM NOW());
    sequence_record RECORD;
    new_number INTEGER;
    formatted_number VARCHAR(50);
BEGIN
    -- Obtener o crear secuencia para cotizaciones
    SELECT * INTO sequence_record 
    FROM number_sequences 
    WHERE sequence_type = 'quotation' AND year = current_year;
    
    IF NOT FOUND THEN
        INSERT INTO number_sequences (sequence_type, prefix, current_number, year, format)
        VALUES ('quotation', 'COT', 1, current_year, 'COT-{YYYY}-{000000}')
        RETURNING * INTO sequence_record;
        new_number := 1;
    ELSE
        new_number := sequence_record.current_number + 1;
        UPDATE number_sequences 
        SET current_number = new_number 
        WHERE id = sequence_record.id;
    END IF;
    
    -- Formatear número
    formatted_number := REPLACE(
        REPLACE(sequence_record.format, '{YYYY}', current_year::TEXT),
        '{000000}', LPAD(new_number::TEXT, 6, '0')
    );
    
    NEW.quotation_number := formatted_number;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Trigger para generar número de cotización automáticamente
CREATE TRIGGER generate_quotation_number_trigger
    BEFORE INSERT ON quotations
    FOR EACH ROW EXECUTE FUNCTION generate_quotation_number();

-- Función similar para facturas
CREATE OR REPLACE FUNCTION generate_invoice_number()
RETURNS TRIGGER AS $$
DECLARE
    current_year INTEGER := EXTRACT(YEAR FROM NOW());
    sequence_record RECORD;
    new_number INTEGER;
    formatted_number VARCHAR(50);
BEGIN
    SELECT * INTO sequence_record 
    FROM number_sequences 
    WHERE sequence_type = 'invoice' AND year = current_year;
    
    IF NOT FOUND THEN
        INSERT INTO number_sequences (sequence_type, prefix, current_number, year, format)
        VALUES ('invoice', 'FAC', 1, current_year, 'FAC-{YYYY}-{000000}')
        RETURNING * INTO sequence_record;
        new_number := 1;
    ELSE
        new_number := sequence_record.current_number + 1;
        UPDATE number_sequences 
        SET current_number = new_number 
        WHERE id = sequence_record.id;
    END IF;
    
    formatted_number := REPLACE(
        REPLACE(sequence_record.format, '{YYYY}', current_year::TEXT),
        '{000000}', LPAD(new_number::TEXT, 6, '0')
    );
    
    NEW.invoice_number := formatted_number;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER generate_invoice_number_trigger
    BEFORE INSERT ON invoices
    FOR EACH ROW EXECUTE FUNCTION generate_invoice_number();

-- =====================================================
-- 11. DATOS INICIALES
-- =====================================================

-- Insertar tipos de andamios por defecto
INSERT INTO scaffold_types (name, description, base_inspection_price, complexity_factor) VALUES
('Andamio Estructural', 'Andamio fijo para construcción', 150000, 1.0),
('Andamio Colgante', 'Andamio suspendido para fachadas', 200000, 1.5),
('Andamio Multidireccional', 'Sistema modular avanzado', 180000, 1.2),
('Andamio Tubular', 'Sistema tradicional con tubos y abrazaderas', 120000, 0.8),
('Andamio Móvil', 'Torre móvil con ruedas', 100000, 0.9);

-- Insertar servicios por defecto
INSERT INTO services (service_code, name, description, service_type, base_price, unit) VALUES
('CURSO-ASI', 'Curso de Seguridad Industrial', 'Capacitación en seguridad industrial básica', 'curso', 80000, 'persona'),
('CURSO-ALT', 'Curso de Trabajo en Alturas', 'Certificación para trabajo en alturas', 'curso', 120000, 'persona'),
('INSP-AND', 'Inspección de Andamios', 'Inspección técnica de andamios instalados', 'inspeccion', 150000, 'andamio'),
('INSP-LIB', 'Inspección y Liberación de Andamios', 'Inspección completa con certificación de liberación', 'inspeccion-liberacion', 250000, 'andamio');

-- Configuraciones iniciales del sistema
INSERT INTO system_settings (setting_key, setting_value, data_type, description, is_public) VALUES
('company_name', 'TecnoSeguridad Pro', 'string', 'Nombre de la empresa', true),
('default_tax_rate', '19', 'number', 'Tasa de IVA por defecto (%)', true),
('default_payment_terms', '30', 'number', 'Términos de pago por defecto (días)', true),
('quotation_validity_days', '30', 'number', 'Validez por defecto de cotizaciones (días)', true),
('auto_expire_quotations', 'true', 'boolean', 'Expirar cotizaciones automáticamente', false),
('email_notifications_enabled', 'true', 'boolean', 'Notificaciones por email habilitadas', false);

-- =====================================================
-- COMENTARIOS ADICIONALES
-- =====================================================

/*
CARACTERÍSTICAS PRINCIPALES DEL ESQUEMA:

1. ESCALABILIDAD:
   - Uso de UUIDs para todas las claves primarias
   - Índices optimizados para consultas frecuentes
   - Estructura preparada para multi-tenant si fuera necesario

2. AUDITORÍA COMPLETA:
   - Logs de actividades detallados
   - Historial de cambios de estado
   - Timestamps en todas las tablas críticas

3. FLEXIBILIDAD:
   - Precios configurables por cliente y volumen
   - Templates de documentos personalizables
   - Configuraciones del sistema modificables

4. INTEGRIDAD:
   - Foreign keys con restricciones apropiadas
   - Triggers para mantener consistencia
   - Validaciones a nivel de base de datos

5. FUNCIONALIDADES AVANZADAS:
   - Numeración automática con formato personalizable
   - Versionado de cotizaciones
   - Sistema de notificaciones integrado
   - Manejo de archivos y documentos

6. SOPORTE PARA LA APLICACIÓN:
   - Estructura que coincide exactamente con los tipos TypeScript
   - Campos para todos los datos mostrados en la UI
   - Soporte completo para el flujo cotización -> factura

PRÓXIMOS PASOS RECOMENDADOS:
- Implementar Row Level Security (RLS) para multi-tenancy
- Agregar backup automático y políticas de retención
- Considerar particionado para tablas de logs si el volumen es alto
- Implementar API REST con autenticación JWT
*/