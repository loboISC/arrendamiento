import { useState } from 'react';
import { Plus, Package, Search, Filter, AlertTriangle, BarChart3, MapPin, Grid3X3, Eye, Edit, Trash2 } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Alert, AlertDescription } from './ui/alert';
import { ProductForm } from './ProductForm';
import { ProductDetails } from './ProductDetails';
import { CategoryManagement } from './CategoryManagement';
import { LocationManagement } from './LocationManagement';
import { StockMovements } from './StockMovements';
import { InventoryReports } from './InventoryReports';
import { Product, ProductCategory, Location } from '../types/rental';

interface InventoryManagementProps {
  products: Product[];
  categories: ProductCategory[];
  locations: Location[];
  onBack: () => void;
}

export function InventoryManagement({ 
  products: initialProducts, 
  categories: initialCategories, 
  locations: initialLocations,
  onBack 
}: InventoryManagementProps) {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [products, setProducts] = useState(initialProducts);
  const [categories, setCategories] = useState(initialCategories);
  const [locations, setLocations] = useState(initialLocations);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedLocation, setSelectedLocation] = useState<string>('all');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isProductFormOpen, setIsProductFormOpen] = useState(false);
  const [isProductDetailsOpen, setIsProductDetailsOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Filtrar productos
  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.brand.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || product.categoryId === selectedCategory;
    // En un sistema real, filtrarías por ubicación basado en el stock por ubicación
    return matchesSearch && matchesCategory;
  });

  // Estadísticas del inventario
  const totalProducts = products.length;
  const totalStock = products.reduce((sum, product) => sum + product.totalStock, 0);
  const lowStockProducts = products.filter(product => product.availableStock <= 5);
  const outOfStockProducts = products.filter(product => product.availableStock === 0);
  const totalValue = products.reduce((sum, product) => sum + (product.salePrice * product.totalStock), 0);

  const handleCreateProduct = (productData: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newProduct: Product = {
      ...productData,
      id: `PROD-${String(Date.now()).slice(-6)}`,
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0]
    };
    setProducts([...products, newProduct]);
    setIsProductFormOpen(false);
  };

  const handleUpdateProduct = (productData: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (!editingProduct) return;
    
    const updatedProduct: Product = {
      ...productData,
      id: editingProduct.id,
      createdAt: editingProduct.createdAt,
      updatedAt: new Date().toISOString().split('T')[0]
    };
    
    setProducts(products.map(p => p.id === editingProduct.id ? updatedProduct : p));
    setEditingProduct(null);
    setIsProductFormOpen(false);
  };

  const handleDeleteProduct = (productId: string) => {
    if (confirm('¿Estás seguro de que deseas eliminar este producto?')) {
      setProducts(products.filter(p => p.id !== productId));
    }
  };

  const handleViewProduct = (product: Product) => {
    setSelectedProduct(product);
    setIsProductDetailsOpen(true);
  };

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    setIsProductFormOpen(true);
  };

  const getStockStatusColor = (product: Product) => {
    if (product.availableStock === 0) return 'bg-red-500';
    if (product.availableStock <= 5) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const getStockStatusText = (product: Product) => {
    if (product.availableStock === 0) return 'Sin stock';
    if (product.availableStock <= 5) return 'Stock bajo';
    return 'En stock';
  };

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Gestión de Inventario</h1>
          <p className="text-slate-600 mt-2">Administra productos, categorías, ubicaciones y stock</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={onBack}>
            Volver al Sistema
          </Button>
          <Button 
            onClick={() => {
              setEditingProduct(null);
              setIsProductFormOpen(true);
            }}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nuevo Producto
          </Button>
        </div>
      </div>

      {/* Alertas de stock */}
      {lowStockProducts.length > 0 && (
        <Alert className="mb-6 border-yellow-200 bg-yellow-50">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Tienes {lowStockProducts.length} productos con stock bajo y {outOfStockProducts.length} productos sin stock.
          </AlertDescription>
        </Alert>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="dashboard" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            Dashboard
          </TabsTrigger>
          <TabsTrigger value="products" className="flex items-center gap-2">
            <Package className="w-4 h-4" />
            Productos
          </TabsTrigger>
          <TabsTrigger value="categories" className="flex items-center gap-2">
            <Grid3X3 className="w-4 h-4" />
            Categorías
          </TabsTrigger>
          <TabsTrigger value="locations" className="flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            Ubicaciones
          </TabsTrigger>
          <TabsTrigger value="movements" className="flex items-center gap-2">
            <Package className="w-4 h-4" />
            Movimientos
          </TabsTrigger>
          <TabsTrigger value="reports" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            Reportes
          </TabsTrigger>
        </TabsList>

        {/* Dashboard */}
        <TabsContent value="dashboard" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-600">Total Productos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-slate-900">{totalProducts}</div>
                <p className="text-sm text-slate-500 mt-1">Productos registrados</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-600">Stock Total</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-slate-900">{totalStock.toLocaleString()}</div>
                <p className="text-sm text-slate-500 mt-1">Unidades en inventario</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-600">Valor Total</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-slate-900">${totalValue.toLocaleString()}</div>
                <p className="text-sm text-slate-500 mt-1">Valor del inventario</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-600">Alertas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-red-600">{lowStockProducts.length}</div>
                <p className="text-sm text-slate-500 mt-1">Productos con stock bajo</p>
              </CardContent>
            </Card>
          </div>

          {/* Productos con stock bajo */}
          {lowStockProducts.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Productos que Requieren Atención</CardTitle>
                <CardDescription>Productos con stock bajo o agotado</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {lowStockProducts.slice(0, 5).map(product => (
                    <div key={product.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className={`w-3 h-3 rounded-full ${getStockStatusColor(product)}`} />
                        <div>
                          <p className="font-medium">{product.name}</p>
                          <p className="text-sm text-slate-500">{product.sku}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">{product.availableStock} disponibles</p>
                        <p className="text-sm text-slate-500">{getStockStatusText(product)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Productos */}
        <TabsContent value="products" className="space-y-6">
          {/* Filtros */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                    <Input
                      placeholder="Buscar productos por nombre, SKU o marca..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Todas las categorías" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas las categorías</SelectItem>
                    {categories.map(category => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Todas las ubicaciones" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas las ubicaciones</SelectItem>
                    {locations.map(location => (
                      <SelectItem key={location.id} value={location.id}>
                        {location.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Lista de productos */}
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredProducts.map(product => (
              <Card key={product.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-900 mb-1">{product.name}</h3>
                      <p className="text-sm text-slate-500 mb-2">{product.sku}</p>
                      <Badge variant="secondary" className="text-xs">
                        {product.categoryName}
                      </Badge>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${getStockStatusColor(product)}`} />
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Stock Total:</span>
                      <span className="font-medium">{product.totalStock}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Disponible:</span>
                      <span className="font-medium">{product.availableStock}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Precio Venta:</span>
                      <span className="font-medium">${product.salePrice.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Estado:</span>
                      <Badge 
                        variant={product.status === 'active' ? 'default' : 'secondary'}
                        className="text-xs"
                      >
                        {product.status === 'active' ? 'Activo' : 'Inactivo'}
                      </Badge>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleViewProduct(product)}
                      className="flex-1"
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      Ver
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEditProduct(product)}
                      className="flex-1"
                    >
                      <Edit className="w-4 h-4 mr-1" />
                      Editar
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDeleteProduct(product.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <Card>
              <CardContent className="py-12 text-center">
                <Package className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                <p className="text-slate-500">No se encontraron productos que coincidan con los filtros</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Categorías */}
        <TabsContent value="categories">
          <CategoryManagement 
            categories={categories}
            onUpdateCategories={setCategories}
          />
        </TabsContent>

        {/* Ubicaciones */}
        <TabsContent value="locations">
          <LocationManagement 
            locations={locations}
            onUpdateLocations={setLocations}
          />
        </TabsContent>

        {/* Movimientos */}
        <TabsContent value="movements">
          <StockMovements 
            products={products}
            onUpdateProducts={setProducts}
          />
        </TabsContent>

        {/* Reportes */}
        <TabsContent value="reports">
          <InventoryReports 
            products={products}
            categories={categories}
            locations={locations}
          />
        </TabsContent>
      </Tabs>

      {/* Formulario de producto */}
      <Dialog open={isProductFormOpen} onOpenChange={setIsProductFormOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingProduct ? 'Editar Producto' : 'Nuevo Producto'}
            </DialogTitle>
            <DialogDescription>
              {editingProduct 
                ? 'Modifica la información del producto' 
                : 'Completa la información para crear un nuevo producto'
              }
            </DialogDescription>
          </DialogHeader>
          <ProductForm
            product={editingProduct}
            categories={categories}
            onSubmit={editingProduct ? handleUpdateProduct : handleCreateProduct}
            onCancel={() => {
              setIsProductFormOpen(false);
              setEditingProduct(null);
            }}
          />
        </DialogContent>
      </Dialog>

      {/* Detalles del producto */}
      <Dialog open={isProductDetailsOpen} onOpenChange={setIsProductDetailsOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Detalles del Producto</DialogTitle>
          </DialogHeader>
          {selectedProduct && (
            <ProductDetails
              product={selectedProduct}
              categories={categories}
              onEdit={() => {
                setIsProductDetailsOpen(false);
                handleEditProduct(selectedProduct);
              }}
              onClose={() => setIsProductDetailsOpen(false)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}