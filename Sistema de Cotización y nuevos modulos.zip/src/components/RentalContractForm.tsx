import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Separator } from './ui/separator';
import { Badge } from './ui/badge';
import { Checkbox } from './ui/checkbox';
import { Calendar, CalendarCheck, Shield, FileText, DollarSign, AlertTriangle, CheckCircle } from 'lucide-react';
import { RentalContract, GuaranteeInfo, ContractTerms, RentalItem, ClientInfo, AdvisorInfo } from '../types/rental';

interface RentalContractFormProps {
  rentalItems: RentalItem[];
  clientInfo: ClientInfo;
  advisorInfo: AdvisorInfo;
  quotationNumber: string;
  onSubmit: (contract: Omit<RentalContract, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onBack: () => void;
}

export function RentalContractForm({
  rentalItems,
  clientInfo,
  advisorInfo,
  quotationNumber,
  onSubmit,
  onBack
}: RentalContractFormProps) {
  // Estado del formulario del contrato
  const [contractData, setContractData] = useState({
    contractNumber: `CON-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`,
    startDate: new Date().toISOString().split('T')[0],
    endDate: '',
    signedDate: new Date().toISOString().split('T')[0]
  });

  // Estado de la garantía
  const [guaranteeInfo, setGuaranteeInfo] = useState<GuaranteeInfo>({
    type: 'monetary',
    amount: 0,
    status: 'pending'
  });

  // Estado de términos y condiciones
  const [terms, setTerms] = useState<ContractTerms>({
    deliveryTerms: 'Entrega en ubicación del cliente dentro de las siguientes 24 horas hábiles.',
    returnTerms: 'Devolución del equipo en las mismas condiciones de entrega, limpio y funcional.',
    damagePolicy: 'El cliente es responsable de cualquier daño o pérdida del equipo durante el período de renta.',
    lateReturnPenalty: 10,
    maintenanceResponsibility: 'El proveedor se hace cargo del mantenimiento preventivo. El cliente notifica cualquier fallo.',
    specialConditions: []
  });

  const [newSpecialCondition, setNewSpecialCondition] = useState('');

  // Calcular totales
  const totalAmount = rentalItems.reduce((sum, item) => sum + item.totalRate + item.deliveryCost, 0);
  const guaranteeAmount = Math.round(totalAmount * 0.2); // 20% del valor total

  // Establecer monto de garantía automáticamente
  useEffect(() => {
    setGuaranteeInfo(prev => ({
      ...prev,
      amount: guaranteeAmount
    }));
  }, [guaranteeAmount]);

  // Calcular fecha de finalización basada en los items
  useEffect(() => {
    if (rentalItems.length > 0) {
      const maxEndDate = rentalItems.reduce((latest, item) => {
        return item.endDate > latest ? item.endDate : latest;
      }, rentalItems[0].endDate);
      
      setContractData(prev => ({
        ...prev,
        endDate: maxEndDate
      }));
    }
  }, [rentalItems]);

  const handleContractChange = (field: string, value: any) => {
    setContractData(prev => ({ ...prev, [field]: value }));
  };

  const handleGuaranteeChange = (field: string, value: any) => {
    setGuaranteeInfo(prev => ({ ...prev, [field]: value }));
  };

  const handleTermsChange = (field: string, value: any) => {
    setTerms(prev => ({ ...prev, [field]: value }));
  };

  const handleAddSpecialCondition = () => {
    if (newSpecialCondition.trim()) {
      setTerms(prev => ({
        ...prev,
        specialConditions: [...prev.specialConditions, newSpecialCondition.trim()]
      }));
      setNewSpecialCondition('');
    }
  };

  const handleRemoveSpecialCondition = (index: number) => {
    setTerms(prev => ({
      ...prev,
      specialConditions: prev.specialConditions.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validaciones
    if (!contractData.startDate || !contractData.endDate) {
      alert('Por favor completa todas las fechas requeridas');
      return;
    }

    if (!guaranteeInfo.type || guaranteeInfo.amount <= 0) {
      alert('Por favor configura correctamente la información de garantía');
      return;
    }

    const contract: Omit<RentalContract, 'id' | 'createdAt' | 'updatedAt'> = {
      quotationNumber,
      contractNumber: contractData.contractNumber,
      clientId: `CLI-${clientInfo.taxId || Date.now()}`,
      clientInfo,
      advisorInfo,
      rentalItems,
      startDate: contractData.startDate,
      endDate: contractData.endDate,
      signedDate: contractData.signedDate,
      guaranteeInfo,
      terms,
      status: 'draft',
      totalAmount,
      paidAmount: 0,
      pendingAmount: totalAmount
    };

    onSubmit(contract);
  };

  const getGuaranteeTypeText = (type: string) => {
    switch (type) {
      case 'monetary': return 'Garantía Monetaria';
      case 'check': return 'Cheque de Garantía';
      case 'bank_letter': return 'Carta Bancaria';
      case 'insurance': return 'Póliza de Seguro';
      default: return type;
    }
  };

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl text-slate-900">Contrato de Arrendamiento</h1>
          <p className="text-slate-600 mt-2">Complete la información del contrato y gestión de garantías</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={onBack}>
            Atrás
          </Button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Información del contrato */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Información del Contrato
            </CardTitle>
            <CardDescription>Datos principales del contrato de arrendamiento</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="contractNumber">Número de Contrato</Label>
                <Input
                  id="contractNumber"
                  value={contractData.contractNumber}
                  onChange={(e) => handleContractChange('contractNumber', e.target.value)}
                  className="font-mono"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="quotationRef">Cotización de Referencia</Label>
                <Input
                  id="quotationRef"
                  value={quotationNumber}
                  disabled
                  className="font-mono bg-slate-50"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="signedDate">Fecha de Firma</Label>
                <Input
                  id="signedDate"
                  type="date"
                  value={contractData.signedDate}
                  onChange={(e) => handleContractChange('signedDate', e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="startDate" className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  Fecha de Inicio de Renta
                </Label>
                <Input
                  id="startDate"
                  type="date"
                  value={contractData.startDate}
                  onChange={(e) => handleContractChange('startDate', e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="endDate" className="flex items-center gap-2">
                  <CalendarCheck className="w-4 h-4" />
                  Fecha de Finalización
                </Label>
                <Input
                  id="endDate"
                  type="date"
                  value={contractData.endDate}
                  onChange={(e) => handleContractChange('endDate', e.target.value)}
                  required
                />
              </div>
            </div>

            {/* Resumen financiero */}
            <div className="bg-slate-50 p-4 rounded-lg">
              <h4 className="font-medium text-slate-900 mb-3 flex items-center gap-2">
                <DollarSign className="w-4 h-4" />
                Resumen Financiero
              </h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <p className="text-sm text-slate-600">Valor Total del Contrato</p>
                  <p className="text-lg font-semibold text-slate-900">${totalAmount.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600">Garantía Requerida</p>
                  <p className="text-lg font-semibold text-orange-600">${guaranteeAmount.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600">Duración</p>
                  <p className="text-lg font-semibold text-blue-600">
                    {Math.ceil((new Date(contractData.endDate).getTime() - new Date(contractData.startDate).getTime()) / (1000 * 60 * 60 * 24))} días
                  </p>
                </div>
                <div>
                  <p className="text-sm text-slate-600">Equipos</p>
                  <p className="text-lg font-semibold text-slate-900">{rentalItems.length} items</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Gestión de garantías */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Gestión de Garantías
            </CardTitle>
            <CardDescription>Configure el tipo y monto de la garantía requerida</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="guaranteeType">Tipo de Garantía</Label>
                <Select 
                  value={guaranteeInfo.type} 
                  onValueChange={(value: any) => handleGuaranteeChange('type', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="monetary">Garantía Monetaria</SelectItem>
                    <SelectItem value="check">Cheque de Garantía</SelectItem>
                    <SelectItem value="bank_letter">Carta Bancaria</SelectItem>
                    <SelectItem value="insurance">Póliza de Seguro</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="guaranteeAmount">Monto de Garantía</Label>
                <Input
                  id="guaranteeAmount"
                  type="number"
                  value={guaranteeInfo.amount}
                  onChange={(e) => handleGuaranteeChange('amount', Number(e.target.value))}
                  required
                />
              </div>
            </div>

            {/* Campos específicos según tipo de garantía */}
            {guaranteeInfo.type === 'monetary' && (
              <div className="space-y-2">
                <Label htmlFor="cashAmount">Monto en Efectivo</Label>
                <Input
                  id="cashAmount"
                  type="number"
                  value={guaranteeInfo.cashAmount || guaranteeInfo.amount}
                  onChange={(e) => handleGuaranteeChange('cashAmount', Number(e.target.value))}
                />
              </div>
            )}

            {guaranteeInfo.type === 'check' && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="checkNumber">Número de Cheque</Label>
                  <Input
                    id="checkNumber"
                    value={guaranteeInfo.checkNumber || ''}
                    onChange={(e) => handleGuaranteeChange('checkNumber', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="checkBank">Banco</Label>
                  <Input
                    id="checkBank"
                    value={guaranteeInfo.checkBank || ''}
                    onChange={(e) => handleGuaranteeChange('checkBank', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="checkDate">Fecha del Cheque</Label>
                  <Input
                    id="checkDate"
                    type="date"
                    value={guaranteeInfo.checkDate || ''}
                    onChange={(e) => handleGuaranteeChange('checkDate', e.target.value)}
                  />
                </div>
              </div>
            )}

            {guaranteeInfo.type === 'bank_letter' && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="bankName">Banco</Label>
                  <Input
                    id="bankName"
                    value={guaranteeInfo.bankName || ''}
                    onChange={(e) => handleGuaranteeChange('bankName', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="letterNumber">Número de Carta</Label>
                  <Input
                    id="letterNumber"
                    value={guaranteeInfo.letterNumber || ''}
                    onChange={(e) => handleGuaranteeChange('letterNumber', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="expirationDate">Fecha de Vencimiento</Label>
                  <Input
                    id="expirationDate"
                    type="date"
                    value={guaranteeInfo.expirationDate || ''}
                    onChange={(e) => handleGuaranteeChange('expirationDate', e.target.value)}
                  />
                </div>
              </div>
            )}

            {guaranteeInfo.type === 'insurance' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="insuranceCompany">Compañía de Seguros</Label>
                  <Input
                    id="insuranceCompany"
                    value={guaranteeInfo.insuranceCompany || ''}
                    onChange={(e) => handleGuaranteeChange('insuranceCompany', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="policyNumber">Número de Póliza</Label>
                  <Input
                    id="policyNumber"
                    value={guaranteeInfo.policyNumber || ''}
                    onChange={(e) => handleGuaranteeChange('policyNumber', e.target.value)}
                  />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="guaranteeNotes">Notas de Garantía</Label>
              <Textarea
                id="guaranteeNotes"
                value={guaranteeInfo.notes || ''}
                onChange={(e) => handleGuaranteeChange('notes', e.target.value)}
                placeholder="Observaciones adicionales sobre la garantía..."
                rows={2}
              />
            </div>

            {/* Estado de la garantía */}
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-orange-600 border-orange-300">
                <AlertTriangle className="w-3 h-3 mr-1" />
                {guaranteeInfo.status === 'pending' ? 'Pendiente de Recepción' : 
                 guaranteeInfo.status === 'received' ? 'Recibida' :
                 guaranteeInfo.status === 'returned' ? 'Devuelta' : 'Ejecutada'}
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Términos y condiciones */}
        <Card>
          <CardHeader>
            <CardTitle>Términos y Condiciones</CardTitle>
            <CardDescription>Configure los términos específicos del contrato</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="deliveryTerms">Términos de Entrega</Label>
                <Textarea
                  id="deliveryTerms"
                  value={terms.deliveryTerms}
                  onChange={(e) => handleTermsChange('deliveryTerms', e.target.value)}
                  rows={2}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="returnTerms">Términos de Devolución</Label>
                <Textarea
                  id="returnTerms"
                  value={terms.returnTerms}
                  onChange={(e) => handleTermsChange('returnTerms', e.target.value)}
                  rows={2}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="damagePolicy">Política de Daños</Label>
                <Textarea
                  id="damagePolicy"
                  value={terms.damagePolicy}
                  onChange={(e) => handleTermsChange('damagePolicy', e.target.value)}
                  rows={2}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="lateReturnPenalty">Penalidad por Retraso (%)</Label>
                  <Input
                    id="lateReturnPenalty"
                    type="number"
                    value={terms.lateReturnPenalty}
                    onChange={(e) => handleTermsChange('lateReturnPenalty', Number(e.target.value))}
                    min="0"
                    max="100"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="maintenanceResponsibility">Responsabilidad de Mantenimiento</Label>
                  <Textarea
                    id="maintenanceResponsibility"
                    value={terms.maintenanceResponsibility}
                    onChange={(e) => handleTermsChange('maintenanceResponsibility', e.target.value)}
                    rows={2}
                  />
                </div>
              </div>

              {/* Condiciones especiales */}
              <div className="space-y-3">
                <Label>Condiciones Especiales</Label>
                <div className="flex gap-2">
                  <Input
                    value={newSpecialCondition}
                    onChange={(e) => setNewSpecialCondition(e.target.value)}
                    placeholder="Agregar condición especial..."
                    className="flex-1"
                  />
                  <Button 
                    type="button" 
                    onClick={handleAddSpecialCondition}
                    size="sm"
                  >
                    Agregar
                  </Button>
                </div>
                
                {terms.specialConditions.length > 0 && (
                  <div className="space-y-2">
                    {terms.specialConditions.map((condition, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                        <span className="text-sm">{condition}</span>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveSpecialCondition(index)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          Eliminar
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Resumen de equipos */}
        <Card>
          <CardHeader>
            <CardTitle>Equipos Incluidos en el Contrato</CardTitle>
            <CardDescription>Listado de todos los equipos que forman parte de este contrato</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {rentalItems.map((item, index) => (
                <div key={item.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div className="flex-1">
                    <h4 className="font-medium text-slate-900">{item.product.name}</h4>
                    <p className="text-sm text-slate-500">
                      Cantidad: {item.quantity} | Período: {item.rentalDuration} {item.rentalPeriod}
                    </p>
                    <p className="text-sm text-slate-500">
                      Desde {item.startDate} hasta {item.endDate}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-slate-900">${item.totalRate.toLocaleString()}</p>
                    {item.deliveryCost > 0 && (
                      <p className="text-sm text-slate-500">+ ${item.deliveryCost.toLocaleString()} envío</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Separator />

        {/* Botones de acción */}
        <div className="flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={onBack}>
            Atrás
          </Button>
          <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
            <CheckCircle className="w-4 h-4 mr-2" />
            Generar Contrato
          </Button>
        </div>
      </form>
    </div>
  );
}