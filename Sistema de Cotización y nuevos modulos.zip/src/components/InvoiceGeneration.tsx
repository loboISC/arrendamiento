import { useState } from 'react';
import { ArrowLeft, ArrowRight, Download, Save, Calculator, CreditCard, Calendar, FileText, DollarSign } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { QuotationItem, ClientInfo, AdvisorInfo, InvoiceInfo } from '../types/quotation';

interface InvoiceGenerationProps {
  quotationItems: QuotationItem[];
  clientInfo: ClientInfo;
  quotationNumber: string;
  advisor: AdvisorInfo;
  onGenerateInvoice: (invoiceInfo: InvoiceInfo) => void;
  onBack: () => void;
  onSavePDF: () => void;
  onSaveToSystem: () => void;
}

export function InvoiceGeneration({ 
  quotationItems, 
  clientInfo, 
  quotationNumber,
  advisor,
  onGenerateInvoice, 
  onBack,
  onSavePDF,
  onSaveToSystem
}: InvoiceGenerationProps) {
  const [invoiceData, setInvoiceData] = useState<Partial<InvoiceInfo>>({
    invoiceNumber: `FAC-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`,
    issueDate: new Date().toISOString().split('T')[0],
    dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    paymentTerms: '30',
    paymentMethod: 'transferencia',
    taxRate: 19,
    currency: 'COP'
  });

  const calculateSubtotal = () => {
    return quotationItems.reduce((total, item) => total + (item.totalPrice || 0), 0);
  };

  const calculateTax = () => {
    return calculateSubtotal() * (invoiceData.taxRate || 0) / 100;
  };

  const calculateTotal = () => {
    return calculateSubtotal() + calculateTax();
  };

  const handleInputChange = (field: keyof InvoiceInfo, value: string | number) => {
    setInvoiceData(prev => ({ ...prev, [field]: value }));
  };

  const handleGenerateInvoice = () => {
    const invoice: InvoiceInfo = {
      invoiceNumber: invoiceData.invoiceNumber!,
      issueDate: invoiceData.issueDate!,
      dueDate: invoiceData.dueDate!,
      paymentTerms: invoiceData.paymentTerms!,
      paymentMethod: invoiceData.paymentMethod!,
      notes: invoiceData.notes,
      taxRate: invoiceData.taxRate!,
      subtotal: calculateSubtotal(),
      taxAmount: calculateTax(),
      total: calculateTotal(),
      currency: invoiceData.currency!
    };
    onGenerateInvoice(invoice);
  };

  const isFormValid = invoiceData.invoiceNumber && invoiceData.issueDate && 
                     invoiceData.dueDate && invoiceData.paymentTerms && 
                     invoiceData.paymentMethod && invoiceData.taxRate !== undefined;

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-semibold text-slate-800 mb-2">Generar Factura</h1>
            <p className="text-slate-600">
              Convierte tu cotización aprobada en una factura oficial.
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <Button variant="outline" onClick={onSavePDF} className="text-blue-600">
              <Download className="w-4 h-4 mr-2" />
              Guardar PDF
            </Button>
            <Button variant="outline" onClick={onSaveToSystem} className="text-green-600">
              <Save className="w-4 h-4 mr-2" />
              Guardar en Sistema
            </Button>
          </div>
        </div>

        {/* Reference Info */}
        <Card className="mb-6 bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <p className="text-blue-600 mb-1">Cotización Base</p>
                <p className="font-mono font-medium text-blue-800">{quotationNumber}</p>
              </div>
              <div>
                <p className="text-blue-600 mb-1">Cliente</p>
                <p className="font-medium text-blue-800">{clientInfo.company}</p>
              </div>
              <div>
                <p className="text-blue-600 mb-1">Servicios</p>
                <p className="font-medium text-blue-800">{quotationItems.length} item(s)</p>
              </div>
              <div>
                <p className="text-blue-600 mb-1">Subtotal</p>
                <p className="font-medium text-blue-800">${calculateSubtotal().toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Progress Indicator */}
      <div className="flex items-center justify-center mb-8">
        <div className="flex items-center space-x-4">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center text-sm font-medium">✓</div>
            <span className="ml-2 text-green-600 font-medium">Cotización</span>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-400" />
          <div className="flex items-center">
            <div className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center text-sm font-medium">✓</div>
            <span className="ml-2 text-green-600 font-medium">Aprobada</span>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-400" />
          <div className="flex items-center">
            <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-medium">4</div>
            <span className="ml-2 text-blue-600 font-medium">Facturación</span>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Invoice Details */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="w-5 h-5 mr-2" />
                Detalles de la Factura
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="invoiceNumber">Número de Factura *</Label>
                  <Input
                    id="invoiceNumber"
                    value={invoiceData.invoiceNumber}
                    onChange={(e) => handleInputChange('invoiceNumber', e.target.value)}
                    placeholder="FAC-2024-XXXXXX"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="issueDate" className="flex items-center">
                    <Calendar className="w-4 h-4 mr-2" />
                    Fecha de Emisión *
                  </Label>
                  <Input
                    id="issueDate"
                    type="date"
                    value={invoiceData.issueDate}
                    onChange={(e) => handleInputChange('issueDate', e.target.value)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="dueDate">Fecha de Vencimiento *</Label>
                  <Input
                    id="dueDate"
                    type="date"
                    value={invoiceData.dueDate}
                    onChange={(e) => handleInputChange('dueDate', e.target.value)}
                    min={invoiceData.issueDate}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="paymentTerms">Términos de Pago *</Label>
                  <Select 
                    value={invoiceData.paymentTerms} 
                    onValueChange={(value) => handleInputChange('paymentTerms', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar términos" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="15">15 días</SelectItem>
                      <SelectItem value="30">30 días</SelectItem>
                      <SelectItem value="45">45 días</SelectItem>
                      <SelectItem value="60">60 días</SelectItem>
                      <SelectItem value="inmediato">Pago inmediato</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="paymentMethod" className="flex items-center">
                    <CreditCard className="w-4 h-4 mr-2" />
                    Método de Pago *
                  </Label>
                  <Select 
                    value={invoiceData.paymentMethod} 
                    onValueChange={(value) => handleInputChange('paymentMethod', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar método" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="transferencia">Transferencia Bancaria</SelectItem>
                      <SelectItem value="cheque">Cheque</SelectItem>
                      <SelectItem value="efectivo">Efectivo</SelectItem>
                      <SelectItem value="tarjeta">Tarjeta de Crédito</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="taxRate" className="flex items-center">
                    <Calculator className="w-4 h-4 mr-2" />
                    Tasa de IVA (%) *
                  </Label>
                  <Input
                    id="taxRate"
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={invoiceData.taxRate}
                    onChange={(e) => handleInputChange('taxRate', parseFloat(e.target.value) || 0)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Notas Adicionales</Label>
                <Textarea
                  id="notes"
                  value={invoiceData.notes || ''}
                  onChange={(e) => handleInputChange('notes', e.target.value)}
                  placeholder="Términos y condiciones, instrucciones especiales..."
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Items Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Servicios a Facturar</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {quotationItems.map((item, index) => (
                  <div key={item.id} className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                    <div className="flex-1">
                      <h4 className="font-medium">{item.serviceName}</h4>
                      <p className="text-sm text-slate-600">
                        Cantidad: {item.quantity} • Fecha: {new Date(item.date).toLocaleDateString('es-ES')}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">${(item.totalPrice || 0).toLocaleString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Invoice Calculations */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <DollarSign className="w-5 h-5 mr-2" />
                Cálculos de Factura
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-slate-600">Subtotal:</span>
                  <span className="font-medium">${calculateSubtotal().toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">IVA ({invoiceData.taxRate}%):</span>
                  <span className="font-medium">${calculateTax().toLocaleString()}</span>
                </div>
                <div className="border-t pt-3">
                  <div className="flex justify-between">
                    <span className="font-semibold">Total:</span>
                    <span className="font-bold text-xl">${calculateTotal().toLocaleString()}</span>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t">
                <Button
                  onClick={handleGenerateInvoice}
                  disabled={!isFormValid}
                  className="w-full bg-green-600 hover:bg-green-700 text-white py-3"
                  size="lg"
                >
                  <FileText className="w-4 h-4 mr-2" />
                  Generar Factura
                </Button>

                {!isFormValid && (
                  <p className="text-sm text-red-500 text-center mt-2">
                    Completa todos los campos obligatorios (*)
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Client Info */}
          <Card>
            <CardHeader>
              <CardTitle>Información de Facturación</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <p className="text-slate-600 text-sm">Cliente</p>
                <p className="font-medium">{clientInfo.company}</p>
              </div>
              <div>
                <p className="text-slate-600 text-sm">Contacto</p>
                <p className="font-medium">{clientInfo.name}</p>
              </div>
              <div>
                <p className="text-slate-600 text-sm">Email</p>
                <p className="font-medium text-blue-600">{clientInfo.email}</p>
              </div>
              {clientInfo.taxId && (
                <div>
                  <p className="text-slate-600 text-sm">NIT</p>
                  <p className="font-medium">{clientInfo.taxId}</p>
                </div>
              )}
              {clientInfo.address && (
                <div>
                  <p className="text-slate-600 text-sm">Dirección</p>
                  <p className="font-medium">{clientInfo.address}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-between mt-8">
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Volver a Cotización
        </Button>
      </div>
    </div>
  );
}