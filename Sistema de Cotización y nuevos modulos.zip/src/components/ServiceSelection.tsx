import { GraduationCap, Search, CheckCircle, ShoppingCart, ArrowRight, Clock, Target, FileText } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Service } from '../types/quotation';

interface ServiceSelectionProps {
  onServiceSelect: (service: Service) => void;
  quotationItemsCount: number;
  onGoToSummary: () => void;
}

export function ServiceSelection({ onServiceSelect, quotationItemsCount, onGoToSummary }: ServiceSelectionProps) {
  const services: Service[] = [
    {
      id: 'curso',
      name: 'Cursos de Capacitación',
      description: 'Capacitación especializada en seguridad industrial y uso de andamios',
      icon: 'graduation-cap',
      type: 'curso'
    },
    {
      id: 'inspeccion',
      name: 'Inspección de Andamios',
      description: 'Inspección técnica y certificación de seguridad de andamios',
      icon: 'search',
      type: 'inspeccion'
    },
    {
      id: 'inspeccion-liberacion',
      name: 'Inspección y Liberación de Andamios',
      description: 'Inspección completa con certificación y liberación para uso',
      icon: 'check-circle',
      type: 'inspeccion-liberacion'
    }
  ];

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'graduation-cap':
        return <GraduationCap className="w-12 h-12 text-blue-600" />;
      case 'search':
        return <Search className="w-12 h-12 text-blue-600" />;
      case 'check-circle':
        return <CheckCircle className="w-12 h-12 text-blue-600" />;
      default:
        return <GraduationCap className="w-12 h-12 text-blue-600" />;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-semibold text-slate-800 mb-2">Crear Nueva Cotización</h1>
            <p className="text-slate-600">
              Selecciona los servicios que deseas incluir en la cotización para tu cliente.
            </p>
          </div>
          
          {quotationItemsCount > 0 && (
            <Button 
              onClick={onGoToSummary}
              className="bg-orange-500 hover:bg-orange-600 text-white"
            >
              <ShoppingCart className="w-4 h-4 mr-2" />
              Revisar cotización ({quotationItemsCount})
            </Button>
          )}
        </div>
        
        {/* Quick stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-4 flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <Target className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-blue-600">Tiempo promedio</p>
                <p className="font-medium text-blue-800">5-10 min por cotización</p>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-green-50 border-green-200">
            <CardContent className="p-4 flex items-center space-x-3">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <Clock className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-green-600">Validez estándar</p>
                <p className="font-medium text-green-800">30 días calendario</p>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-purple-50 border-purple-200">
            <CardContent className="p-4 flex items-center space-x-3">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <FileText className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-purple-600">Servicios disponibles</p>
                <p className="font-medium text-purple-800">{services.length} tipos</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Progress Indicator */}
      <div className="flex items-center justify-center mb-8">
        <div className="flex items-center space-x-4">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-medium">1</div>
            <span className="ml-2 text-blue-600 font-medium">Selección de Servicios</span>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-400" />
          <div className="flex items-center">
            <div className="w-8 h-8 bg-slate-200 text-slate-400 rounded-full flex items-center justify-center text-sm font-medium">2</div>
            <span className="ml-2 text-slate-400">Configuración</span>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-400" />
          <div className="flex items-center">
            <div className="w-8 h-8 bg-slate-200 text-slate-400 rounded-full flex items-center justify-center text-sm font-medium">3</div>
            <span className="ml-2 text-slate-400">Generar Cotización</span>
          </div>
        </div>
      </div>

      {/* Service Cards */}
      <div className="grid md:grid-cols-3 gap-6 mb-8">
        {services.map((service) => (
          <Card 
            key={service.id}
            className="cursor-pointer transition-all duration-200 hover:shadow-lg hover:scale-105 border-2 hover:border-blue-200 bg-white"
            onClick={() => onServiceSelect(service)}
          >
            <CardContent className="p-6 text-center">
              <div className="mb-4 flex justify-center">
                {getIcon(service.icon)}
              </div>
              <h3 className="text-lg font-medium text-slate-800 mb-3">
                {service.name}
              </h3>
              <p className="text-slate-600 mb-6 text-sm leading-relaxed">
                {service.description}
              </p>
              <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                Configurar Servicio
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Help Section */}
      <Card className="bg-slate-50 border-slate-200">
        <CardContent className="p-6">
          <div className="text-center">
            <h3 className="font-medium text-slate-800 mb-2">¿Necesitas ayuda con la cotización?</h3>
            <p className="text-slate-600 mb-4 text-sm">
              Consulta el manual interno o contacta al equipo técnico para información específica sobre servicios.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button variant="outline" size="sm" className="text-slate-600">
                📋 Manual de Cotizaciones
              </Button>
              <Button variant="outline" size="sm" className="text-slate-600">
                💬 Chat Interno
              </Button>
              <Button variant="outline" size="sm" className="text-slate-600">
                📞 Ext. 101 - Soporte Técnico
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}