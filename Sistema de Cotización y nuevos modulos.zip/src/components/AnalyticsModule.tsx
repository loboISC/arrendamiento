import { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ComposedChart } from 'recharts';
import { TrendingUp, TrendingDown, DollarSign, Users, Package, Calendar, ArrowUp, ArrowDown, Target, Award, AlertCircle } from 'lucide-react';
import { AnalyticsPeriod, SalesData, TrendAnalysis } from '../types/rental';

interface AnalyticsModuleProps {
  onBack: () => void;
}

export function AnalyticsModule({ onBack }: AnalyticsModuleProps) {
  // Estados para filtros
  const [selectedPeriod, setSelectedPeriod] = useState<'week' | 'month' | 'quarter' | 'semester' | 'year'>('month');
  const [selectedYear, setSelectedYear] = useState('2024');

  // Datos mock para análisis
  const mockSalesData = useMemo(() => {
    const generateMonthlyData = () => {
      const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
      return months.map((month, index) => ({
        period: month,
        totalRevenue: Math.random() * 50000000 + 20000000,
        rentalRevenue: Math.random() * 30000000 + 15000000,
        salesRevenue: Math.random() * 15000000 + 5000000,
        serviceRevenue: Math.random() * 5000000 + 2000000,
        totalTransactions: Math.floor(Math.random() * 100 + 50),
        newCustomers: Math.floor(Math.random() * 20 + 5),
        utilizationRate: Math.random() * 30 + 60,
        customerSatisfaction: Math.random() * 1 + 4
      }));
    };

    const generateWeeklyData = () => {
      return Array.from({ length: 12 }, (_, index) => ({
        period: `S${index + 1}`,
        totalRevenue: Math.random() * 12000000 + 5000000,
        rentalRevenue: Math.random() * 8000000 + 3000000,
        salesRevenue: Math.random() * 3000000 + 1000000,
        serviceRevenue: Math.random() * 1000000 + 500000,
        totalTransactions: Math.floor(Math.random() * 25 + 10),
        newCustomers: Math.floor(Math.random() * 5 + 1),
        utilizationRate: Math.random() * 30 + 60,
        customerSatisfaction: Math.random() * 1 + 4
      }));
    };

    const generateQuarterlyData = () => {
      return ['Q1', 'Q2', 'Q3', 'Q4'].map(quarter => ({
        period: quarter,
        totalRevenue: Math.random() * 150000000 + 60000000,
        rentalRevenue: Math.random() * 90000000 + 40000000,
        salesRevenue: Math.random() * 45000000 + 15000000,
        serviceRevenue: Math.random() * 15000000 + 5000000,
        totalTransactions: Math.floor(Math.random() * 300 + 150),
        newCustomers: Math.floor(Math.random() * 60 + 15),
        utilizationRate: Math.random() * 30 + 60,
        customerSatisfaction: Math.random() * 1 + 4
      }));
    };

    const generateYearlyData = () => {
      return ['2021', '2022', '2023', '2024'].map(year => ({
        period: year,
        totalRevenue: Math.random() * 600000000 + 200000000,
        rentalRevenue: Math.random() * 360000000 + 120000000,
        salesRevenue: Math.random() * 180000000 + 60000000,
        serviceRevenue: Math.random() * 60000000 + 20000000,
        totalTransactions: Math.floor(Math.random() * 1200 + 500),
        newCustomers: Math.floor(Math.random() * 240 + 60),
        utilizationRate: Math.random() * 30 + 60,
        customerSatisfaction: Math.random() * 1 + 4
      }));
    };

    switch (selectedPeriod) {
      case 'week': return generateWeeklyData();
      case 'month': return generateMonthlyData();
      case 'quarter': return generateQuarterlyData();
      case 'semester': return generateQuarterlyData().slice(0, 2);
      case 'year': return generateYearlyData();
      default: return generateMonthlyData();
    }
  }, [selectedPeriod]);

  // Datos para gráficas específicas
  const categoryData = [
    { name: 'Andamios', value: 35, revenue: 180000000, color: '#3B82F6' },
    { name: 'Herramientas Eléctricas', value: 25, revenue: 120000000, color: '#10B981' },
    { name: 'Maquinaria Pesada', value: 20, revenue: 250000000, color: '#F59E0B' },
    { name: 'Equipos de Seguridad', value: 15, revenue: 80000000, color: '#EF4444' },
    { name: 'Herramientas Manuales', value: 5, revenue: 30000000, color: '#8B5CF6' }
  ];

  const topProducts = [
    { name: 'Andamio Estructural Modular', rentals: 145, revenue: 45000000, utilization: 85 },
    { name: 'Excavadora Hidráulica', rentals: 89, revenue: 120000000, utilization: 92 },
    { name: 'Grúa Torre Móvil', rentals: 67, revenue: 98000000, utilization: 78 },
    { name: 'Taladro Percutor Profesional', rentals: 234, revenue: 28000000, utilization: 65 },
    { name: 'Generador Eléctrico Diésel', rentals: 156, revenue: 67000000, utilization: 73 }
  ];

  const kpiData = {
    monthlyRecurringRevenue: 85000000,
    customerLifetimeValue: 12500000,
    averageOrderValue: 1850000,
    inventoryTurnover: 6.2,
    equipmentUtilization: 78.5,
    onTimeDeliveryRate: 94.2,
    customerSatisfactionScore: 4.3,
    netPromoterScore: 67,
    customerRetentionRate: 89.5,
    daysInOutstandingReceivables: 28,
    collectionEfficiency: 96.8,
    badDebtRate: 2.1
  };

  // Calcular métricas de crecimiento
  const currentPeriodData = mockSalesData[mockSalesData.length - 1];
  const previousPeriodData = mockSalesData[mockSalesData.length - 2];
  
  const revenueGrowth = previousPeriodData ? 
    ((currentPeriodData.totalRevenue - previousPeriodData.totalRevenue) / previousPeriodData.totalRevenue) * 100 : 0;
  
  const transactionGrowth = previousPeriodData ? 
    ((currentPeriodData.totalTransactions - previousPeriodData.totalTransactions) / previousPeriodData.totalTransactions) * 100 : 0;

  // Utilidades
  const formatCurrency = (value: number) => {
    if (value >= 1000000) {
      return `$${(value / 1000000).toFixed(1)}M`;
    }
    return `$${value.toLocaleString()}`;
  };

  const formatPercentage = (value: number) => {
    return `${value.toFixed(1)}%`;
  };

  const getGrowthIcon = (growth: number) => {
    if (growth > 0) return <ArrowUp className="w-4 h-4 text-green-600" />;
    if (growth < 0) return <ArrowDown className="w-4 h-4 text-red-600" />;
    return <TrendingUp className="w-4 h-4 text-slate-400" />;
  };

  const getGrowthColor = (growth: number) => {
    if (growth > 0) return 'text-green-600';
    if (growth < 0) return 'text-red-600';
    return 'text-slate-500';
  };

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl text-slate-900">Análisis y Métricas</h1>
          <p className="text-slate-600 mt-2">Dashboard de análisis de ventas, tendencias y KPIs</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={onBack}>
            Volver al Sistema
          </Button>
        </div>
      </div>

      {/* Filtros de período */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-slate-500" />
              <span className="text-sm text-slate-600">Período de análisis:</span>
            </div>
            <Select value={selectedPeriod} onValueChange={(value: any) => setSelectedPeriod(value)}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="week">Semanal</SelectItem>
                <SelectItem value="month">Mensual</SelectItem>
                <SelectItem value="quarter">Trimestral</SelectItem>
                <SelectItem value="semester">Semestral</SelectItem>
                <SelectItem value="year">Anual</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedYear} onValueChange={setSelectedYear}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="2024">2024</SelectItem>
                <SelectItem value="2023">2023</SelectItem>
                <SelectItem value="2022">2022</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Resumen</TabsTrigger>
          <TabsTrigger value="revenue">Ingresos</TabsTrigger>
          <TabsTrigger value="products">Productos</TabsTrigger>
          <TabsTrigger value="customers">Clientes</TabsTrigger>
          <TabsTrigger value="kpis">KPIs</TabsTrigger>
        </TabsList>

        {/* Pestaña Resumen */}
        <TabsContent value="overview" className="space-y-6">
          {/* Métricas principales */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-slate-600 flex items-center gap-2">
                  <DollarSign className="w-4 h-4" />
                  Ingresos Totales
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-slate-900">
                  {formatCurrency(currentPeriodData.totalRevenue)}
                </div>
                <div className={`flex items-center gap-1 mt-1 ${getGrowthColor(revenueGrowth)}`}>
                  {getGrowthIcon(revenueGrowth)}
                  <span className="text-sm">{formatPercentage(Math.abs(revenueGrowth))} vs período anterior</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-slate-600 flex items-center gap-2">
                  <Package className="w-4 h-4" />
                  Transacciones
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-slate-900">{currentPeriodData.totalTransactions}</div>
                <div className={`flex items-center gap-1 mt-1 ${getGrowthColor(transactionGrowth)}`}>
                  {getGrowthIcon(transactionGrowth)}
                  <span className="text-sm">{formatPercentage(Math.abs(transactionGrowth))} vs período anterior</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-slate-600 flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  Nuevos Clientes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-blue-600">{currentPeriodData.newCustomers}</div>
                <p className="text-sm text-slate-500 mt-1">En este período</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-slate-600 flex items-center gap-2">
                  <Target className="w-4 h-4" />
                  Utilización
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-green-600">{formatPercentage(currentPeriodData.utilizationRate)}</div>
                <p className="text-sm text-slate-500 mt-1">Promedio de equipos</p>
              </CardContent>
            </Card>
          </div>

          {/* Gráfico de tendencias */}
          <Card>
            <CardHeader>
              <CardTitle>Tendencia de Ingresos</CardTitle>
              <CardDescription>Evolución de ingresos por tipo de servicio</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <ComposedChart data={mockSalesData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="period" />
                  <YAxis tickFormatter={(value) => formatCurrency(value)} />
                  <Tooltip formatter={(value: any) => formatCurrency(value)} />
                  <Legend />
                  <Area 
                    type="monotone" 
                    dataKey="totalRevenue" 
                    fill="#3B82F6" 
                    fillOpacity={0.3}
                    stroke="#3B82F6"
                    name="Total"
                  />
                  <Bar dataKey="rentalRevenue" fill="#10B981" name="Renta" />
                  <Bar dataKey="salesRevenue" fill="#F59E0B" name="Venta" />
                  <Line type="monotone" dataKey="serviceRevenue" stroke="#EF4444" name="Servicios" />
                </ComposedChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Distribución por categoría */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Distribución por Categoría</CardTitle>
                <CardDescription>Participación de ingresos por tipo de equipo</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, value }) => `${name}: ${value}%`}
                    >
                      {categoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Top Productos por Ingresos</CardTitle>
                <CardDescription>Productos con mayor facturación</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {topProducts.slice(0, 5).map((product, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                      <div className="flex-1">
                        <h4 className="font-medium text-slate-900">{product.name}</h4>
                        <p className="text-sm text-slate-500">{product.rentals} rentas</p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-green-600">{formatCurrency(product.revenue)}</p>
                        <p className="text-sm text-slate-500">{formatPercentage(product.utilization)} utilización</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Pestaña Ingresos */}
        <TabsContent value="revenue" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-slate-600">Renta</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl text-green-600">{formatCurrency(currentPeriodData.rentalRevenue)}</div>
                <p className="text-sm text-slate-500 mt-1">
                  {formatPercentage((currentPeriodData.rentalRevenue / currentPeriodData.totalRevenue) * 100)} del total
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-slate-600">Venta</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl text-blue-600">{formatCurrency(currentPeriodData.salesRevenue)}</div>
                <p className="text-sm text-slate-500 mt-1">
                  {formatPercentage((currentPeriodData.salesRevenue / currentPeriodData.totalRevenue) * 100)} del total
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-slate-600">Servicios</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl text-orange-600">{formatCurrency(currentPeriodData.serviceRevenue)}</div>
                <p className="text-sm text-slate-500 mt-1">
                  {formatPercentage((currentPeriodData.serviceRevenue / currentPeriodData.totalRevenue) * 100)} del total
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Análisis de Ingresos por Línea de Negocio</CardTitle>
              <CardDescription>Comparación detallada de fuentes de ingresos</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={mockSalesData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="period" />
                  <YAxis tickFormatter={(value) => formatCurrency(value)} />
                  <Tooltip formatter={(value: any) => formatCurrency(value)} />
                  <Legend />
                  <Bar dataKey="rentalRevenue" stackId="a" fill="#10B981" name="Renta" />
                  <Bar dataKey="salesRevenue" stackId="a" fill="#3B82F6" name="Venta" />
                  <Bar dataKey="serviceRevenue" stackId="a" fill="#F59E0B" name="Servicios" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Pestaña Productos */}
        <TabsContent value="products" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Performance de Productos</CardTitle>
              <CardDescription>Análisis detallado por categoría de producto</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-4">Ingresos por Categoría</h4>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={categoryData} layout="horizontal">
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" tickFormatter={(value) => formatCurrency(value)} />
                      <YAxis dataKey="name" type="category" width={120} />
                      <Tooltip formatter={(value: any) => formatCurrency(value)} />
                      <Bar dataKey="revenue" fill="#3B82F6" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                <div>
                  <h4 className="font-medium mb-4">Top Productos</h4>
                  <div className="space-y-3">
                    {topProducts.map((product, index) => (
                      <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-semibold ${index === 0 ? 'bg-yellow-500' : index === 1 ? 'bg-gray-400' : 'bg-orange-500'}`}>
                            {index + 1}
                          </div>
                          <div>
                            <p className="font-medium text-sm">{product.name}</p>
                            <p className="text-xs text-slate-500">{product.rentals} rentas totales</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-sm">{formatCurrency(product.revenue)}</p>
                          <Badge variant="secondary" className="text-xs">
                            {formatPercentage(product.utilization)}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Pestaña Clientes */}
        <TabsContent value="customers" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-slate-600">Nuevos Clientes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-blue-600">{currentPeriodData.newCustomers}</div>
                <p className="text-sm text-slate-500 mt-1">En este período</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-slate-600">Satisfacción</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-green-600 flex items-center">
                  {currentPeriodData.customerSatisfaction.toFixed(1)}
                  <Award className="w-6 h-6 ml-2" />
                </div>
                <p className="text-sm text-slate-500 mt-1">Promedio sobre 5.0</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-slate-600">Retención</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-purple-600">{formatPercentage(kpiData.customerRetentionRate)}</div>
                <p className="text-sm text-slate-500 mt-1">Tasa de retención</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-slate-600">Valor Promedio</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-orange-600">{formatCurrency(kpiData.averageOrderValue)}</div>
                <p className="text-sm text-slate-500 mt-1">Por transacción</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Evolución de Satisfacción del Cliente</CardTitle>
              <CardDescription>Tendencia de la calificación promedio</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={mockSalesData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="period" />
                  <YAxis domain={[3.5, 5]} />
                  <Tooltip />
                  <Line 
                    type="monotone" 
                    dataKey="customerSatisfaction" 
                    stroke="#10B981" 
                    strokeWidth={3}
                    name="Satisfacción"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Pestaña KPIs */}
        <TabsContent value="kpis" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* KPIs Financieros */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">KPIs Financieros</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Ingresos Recurrentes Mensuales</span>
                  <span className="font-semibold">{formatCurrency(kpiData.monthlyRecurringRevenue)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Valor de Vida del Cliente</span>
                  <span className="font-semibold">{formatCurrency(kpiData.customerLifetimeValue)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Valor Promedio de Orden</span>
                  <span className="font-semibold">{formatCurrency(kpiData.averageOrderValue)}</span>
                </div>
              </CardContent>
            </Card>

            {/* KPIs Operacionales */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">KPIs Operacionales</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Rotación de Inventario</span>
                  <span className="font-semibold">{kpiData.inventoryTurnover}x</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Utilización de Equipos</span>
                  <span className="font-semibold">{formatPercentage(kpiData.equipmentUtilization)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Entregas a Tiempo</span>
                  <span className="font-semibold">{formatPercentage(kpiData.onTimeDeliveryRate)}</span>
                </div>
              </CardContent>
            </Card>

            {/* KPIs de Servicio */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">KPIs de Servicio</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Satisfacción del Cliente</span>
                  <div className="flex items-center gap-1">
                    <span className="font-semibold">{kpiData.customerSatisfactionScore}</span>
                    <Award className="w-4 h-4 text-yellow-500" />
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Net Promoter Score</span>
                  <span className="font-semibold">{kpiData.netPromoterScore}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Retención de Clientes</span>
                  <span className="font-semibold">{formatPercentage(kpiData.customerRetentionRate)}</span>
                </div>
              </CardContent>
            </Card>

            {/* KPIs de Cobranza */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">KPIs de Cobranza</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Días Cartera Pendiente</span>
                  <span className="font-semibold">{kpiData.daysInOutstandingReceivables} días</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Eficiencia de Cobranza</span>
                  <span className="font-semibold">{formatPercentage(kpiData.collectionEfficiency)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Tasa de Cartera Vencida</span>
                  <div className="flex items-center gap-1">
                    <span className="font-semibold">{formatPercentage(kpiData.badDebtRate)}</span>
                    {kpiData.badDebtRate > 5 && <AlertCircle className="w-4 h-4 text-red-500" />}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Alertas y Recomendaciones */}
          <Card>
            <CardHeader>
              <CardTitle>Alertas y Recomendaciones</CardTitle>
              <CardDescription>Indicadores que requieren atención</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {kpiData.equipmentUtilization < 80 && (
                  <div className="flex items-center gap-3 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <AlertCircle className="w-5 h-5 text-yellow-600" />
                    <div>
                      <p className="font-medium text-yellow-800">Utilización de Equipos Baja</p>
                      <p className="text-sm text-yellow-700">
                        La utilización actual ({formatPercentage(kpiData.equipmentUtilization)}) está por debajo del objetivo (80%).
                        Considera estrategias de marketing o revisión de precios.
                      </p>
                    </div>
                  </div>
                )}
                
                {kpiData.customerSatisfactionScore < 4.0 && (
                  <div className="flex items-center gap-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                    <AlertCircle className="w-5 h-5 text-red-600" />
                    <div>
                      <p className="font-medium text-red-800">Satisfacción del Cliente Baja</p>
                      <p className="text-sm text-red-700">
                        La satisfacción promedio ({kpiData.customerSatisfactionScore}) requiere mejora inmediata.
                        Revisa los procesos de servicio al cliente.
                      </p>
                    </div>
                  </div>
                )}

                {kpiData.onTimeDeliveryRate > 95 && (
                  <div className="flex items-center gap-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                    <TrendingUp className="w-5 h-5 text-green-600" />
                    <div>
                      <p className="font-medium text-green-800">Excelente Desempeño en Entregas</p>
                      <p className="text-sm text-green-700">
                        La tasa de entregas a tiempo ({formatPercentage(kpiData.onTimeDeliveryRate)}) está por encima del objetivo.
                        ¡Mantén este excelente nivel de servicio!
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}