import { useState, useMemo } from 'react';
import { Search, Filter, MapPin, Package, ShoppingCart, Calendar, ArrowLeft, ArrowRight, Star, Truck, Info, Image, Eye, Heart } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Checkbox } from './ui/checkbox';
import { Slider } from './ui/slider';
import { QuotationType, Product, ProductCategory, Location, InventoryFilter } from '../types/rental';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ProductSelectionProps {
  quotationType: QuotationType;
  products: Product[];
  categories: ProductCategory[];
  locations: Location[];
  onProductSelect: (product: Product) => void;
  onBack: () => void;
  selectedLocation?: Location;
  onLocationChange: (location: Location) => void;
}

export function ProductSelection({
  quotationType,
  products,
  categories,
  locations,
  onProductSelect,
  onBack,
  selectedLocation,
  onLocationChange
}: ProductSelectionProps) {
  const [filters, setFilters] = useState<InventoryFilter>({
    availability: 'available',
    searchTerm: '',
    priceRange: { min: 0, max: 10000000 }
  });

  const [showFilters, setShowFilters] = useState(false);
  const [postalCode, setPostalCode] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Filtrar productos según criterios
  const filteredProducts = useMemo(() => {
    return products.filter(product => {
      // Filtro de búsqueda
      if (filters.searchTerm) {
        const searchLower = filters.searchTerm.toLowerCase();
        if (!product.name.toLowerCase().includes(searchLower) &&
            !product.description.toLowerCase().includes(searchLower) &&
            !product.sku.toLowerCase().includes(searchLower) &&
            !product.brand.toLowerCase().includes(searchLower)) {
          return false;
        }
      }

      // Filtro de categoría
      if (filters.categoryId && product.categoryId !== filters.categoryId) {
        return false;
      }

      // Filtro de disponibilidad
      if (filters.availability === 'available' && product.availableStock <= 0) {
        return false;
      }

      // Filtro de rango de precio
      const price = quotationType === 'sale' ? product.salePrice : product.dailyRentalRate;
      if (price < filters.priceRange!.min || price > filters.priceRange!.max) {
        return false;
      }

      return true;
    });
  }, [products, filters, quotationType]);

  const getPrice = (product: Product) => {
    switch (quotationType) {
      case 'sale':
        return {
          amount: product.salePrice,
          label: 'Precio de venta',
          period: '',
          color: 'text-green-600'
        };
      case 'rental':
        return {
          amount: product.dailyRentalRate,
          label: 'Desde',
          period: '/día',
          color: 'text-blue-600'
        };
      default:
        return { amount: 0, label: '', period: '', color: 'text-slate-600' };
    }
  };

  const handleLocationSearch = () => {
    // Simular búsqueda por código postal
    const mockLocation = locations.find(loc => 
      loc.postalCode.includes(postalCode) || 
      loc.city.toLowerCase().includes(postalCode.toLowerCase())
    );
    
    if (mockLocation) {
      onLocationChange(mockLocation);
    }
  };

  const getAvailabilityColor = (stock: number) => {
    if (stock === 0) return 'bg-red-500';
    if (stock <= 5) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const getConditionBadge = (condition: string) => {
    const variants = {
      'new': { label: 'Nuevo', className: 'bg-green-100 text-green-800' },
      'good': { label: 'Bueno', className: 'bg-blue-100 text-blue-800' },
      'fair': { label: 'Regular', className: 'bg-yellow-100 text-yellow-800' }
    };
    return variants[condition as keyof typeof variants] || variants.good;
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-semibold text-slate-800 mb-2">
              Catálogo de Productos para {quotationType === 'sale' ? 'Venta' : 'Renta'}
            </h1>
            <p className="text-slate-600">
              Explora nuestro catálogo y selecciona los productos que necesitas.
            </p>
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center space-x-2">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('grid')}
            >
              <Package className="w-4 h-4 mr-2" />
              Grid
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('list')}
            >
              Lista
            </Button>
          </div>
        </div>

        {/* Progress */}
        <div className="flex items-center justify-center mb-6">
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center text-sm font-medium">✓</div>
              <span className="ml-2 text-green-600 font-medium">Tipo</span>
            </div>
            <ArrowRight className="w-4 h-4 text-slate-400" />
            <div className="flex items-center">
              <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-medium">2</div>
              <span className="ml-2 text-blue-600 font-medium">Productos</span>
            </div>
            <ArrowRight className="w-4 h-4 text-slate-400" />
            <div className="flex items-center">
              <div className="w-8 h-8 bg-slate-300 text-slate-500 rounded-full flex items-center justify-center text-sm font-medium">3</div>
              <span className="ml-2 text-slate-500">Configuración</span>
            </div>
          </div>
        </div>

        {/* Search Bar */}
        <div className="max-w-md mx-auto mb-6">
          <div className="relative">
            <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" />
            <Input
              placeholder="Buscar productos, marcas o códigos..."
              value={filters.searchTerm}
              onChange={(e) => setFilters(prev => ({ ...prev, searchTerm: e.target.value }))}
              className="pl-10 pr-4 py-3"
            />
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-4 gap-8">
        {/* Sidebar con filtros y ubicación */}
        <div className="lg:col-span-1 space-y-6">
          {/* Búsqueda por ubicación */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <MapPin className="w-5 h-5 mr-2" />
                Ubicación
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex space-x-2">
                <Input
                  placeholder="Código postal o ciudad"
                  value={postalCode}
                  onChange={(e) => setPostalCode(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleLocationSearch()}
                />
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleLocationSearch}
                >
                  <Search className="w-4 h-4" />
                </Button>
              </div>
              
              {selectedLocation && (
                <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                  <h4 className="font-medium text-blue-800">{selectedLocation.name}</h4>
                  <p className="text-sm text-blue-600">{selectedLocation.city}, {selectedLocation.state}</p>
                  <p className="text-xs text-blue-600 mt-1">{selectedLocation.address}</p>
                </div>
              )}

              {/* Quick Location Buttons */}
              <div className="space-y-2">
                <p className="text-sm text-slate-600">Ubicaciones populares:</p>
                {locations.slice(0, 3).map(location => (
                  <Button
                    key={location.id}
                    variant="outline"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => onLocationChange(location)}
                  >
                    <MapPin className="w-3 h-3 mr-2" />
                    {location.city}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Filtros */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center justify-between">
                <span className="flex items-center">
                  <Filter className="w-5 h-5 mr-2" />
                  Filtros
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowFilters(!showFilters)}
                >
                  {showFilters ? 'Ocultar' : 'Mostrar'}
                </Button>
              </CardTitle>
            </CardHeader>
            
            {showFilters && (
              <CardContent className="space-y-4">
                {/* Categoría */}
                <div>
                  <label className="text-sm text-slate-600 mb-2 block">Categoría</label>
                  <Select 
                    value={filters.categoryId || ''} 
                    onValueChange={(value) => setFilters(prev => ({ ...prev, categoryId: value || undefined }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Todas las categorías" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Todas las categorías</SelectItem>
                      {categories.map(category => (
                        <SelectItem key={category.id} value={category.id}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Disponibilidad */}
                <div>
                  <label className="text-sm text-slate-600 mb-2 block">Disponibilidad</label>
                  <Select 
                    value={filters.availability || 'all'} 
                    onValueChange={(value) => setFilters(prev => ({ ...prev, availability: value as any }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="available">Disponibles</SelectItem>
                      <SelectItem value="rented">En renta</SelectItem>
                      <SelectItem value="maintenance">En mantenimiento</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Rango de precio */}
                <div>
                  <label className="text-sm text-slate-600 mb-2 block">
                    Precio ({quotationType === 'sale' ? 'venta' : 'renta diaria'})
                  </label>
                  <div className="space-y-2">
                    <Slider
                      value={[filters.priceRange?.min || 0, filters.priceRange?.max || 10000000]}
                      onValueChange={([min, max]) => setFilters(prev => ({ 
                        ...prev, 
                        priceRange: { min, max } 
                      }))}
                      max={10000000}
                      step={10000}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-slate-500">
                      <span>${(filters.priceRange?.min || 0).toLocaleString()}</span>
                      <span>${(filters.priceRange?.max || 10000000).toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            )}
          </Card>

          {/* Resumen de filtros */}
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <Package className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                <p className="font-medium text-slate-800">{filteredProducts.length}</p>
                <p className="text-sm text-slate-600">productos encontrados</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Lista de productos */}
        <div className="lg:col-span-3">
          {filteredProducts.length === 0 ? (
            <Card className="text-center py-12">
              <CardContent>
                <Package className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <h3 className="text-lg text-slate-600 mb-2">No se encontraron productos</h3>
                <p className="text-slate-500">Intenta ajustar los filtros de búsqueda</p>
                <Button 
                  variant="outline" 
                  className="mt-4"
                  onClick={() => setFilters({ availability: 'available', searchTerm: '', priceRange: { min: 0, max: 10000000 } })}
                >
                  Limpiar filtros
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className={`grid gap-6 ${viewMode === 'grid' ? 'md:grid-cols-2 xl:grid-cols-3' : 'grid-cols-1'}`}>
              {filteredProducts.map((product) => {
                const priceInfo = getPrice(product);
                const isAvailable = product.availableStock > 0;
                const conditionBadge = getConditionBadge(product.condition);
                
                return (
                  <Card 
                    key={product.id} 
                    className={`cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-2 group ${
                      !isAvailable ? 'opacity-60' : ''
                    }`}
                    onClick={() => isAvailable && onProductSelect(product)}
                  >
                    <CardHeader className="p-0">
                      {/* Imagen del producto */}
                      <div className={`${viewMode === 'grid' ? 'aspect-video' : 'aspect-[2/1]'} bg-slate-100 rounded-t-lg overflow-hidden relative`}>
                        {product.images.length > 0 ? (
                          <ImageWithFallback
                            src={product.images[0]}
                            alt={product.name}
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-slate-100 to-slate-200">
                            <Image className="w-12 h-12 text-slate-400" />
                          </div>
                        )}
                        
                        {/* Overlay con acciones rápidas */}
                        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
                          <div className="flex space-x-2">
                            <Button size="sm" variant="secondary" className="bg-white hover:bg-slate-100">
                              <Eye className="w-4 h-4 mr-1" />
                              Ver detalles
                            </Button>
                          </div>
                        </div>
                        
                        {/* Badges */}
                        <div className="absolute top-3 left-3 flex flex-col space-y-1">
                          <Badge className={conditionBadge.className}>
                            {conditionBadge.label}
                          </Badge>
                          {product.brand && (
                            <Badge variant="outline" className="bg-white text-xs">
                              {product.brand}
                            </Badge>
                          )}
                        </div>
                        
                        <div className="absolute top-3 right-3">
                          <div className="flex items-center space-x-1">
                            <div className={`w-2 h-2 rounded-full ${getAvailabilityColor(product.availableStock)}`}></div>
                            <Badge className={isAvailable ? "bg-blue-500 text-white" : "bg-red-500 text-white"}>
                              {isAvailable ? `${product.availableStock} disponibles` : 'Sin stock'}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="p-4">
                      {/* Información básica */}
                      <div className="mb-4">
                        <div className="flex items-start justify-between mb-2">
                          <h3 className="font-medium text-slate-800 line-clamp-2 flex-1">
                            {product.name}
                          </h3>
                        </div>
                        
                        <p className="text-sm text-slate-600 line-clamp-2 mb-3">
                          {product.description}
                        </p>
                        
                        <div className="flex items-center justify-between text-xs text-slate-500 mb-3">
                          <span>SKU: {product.sku}</span>
                          <span className="font-medium">{product.categoryName}</span>
                        </div>
                      </div>

                      {/* Precio destacado */}
                      <div className="mb-4 p-3 bg-slate-50 rounded-lg">
                        <div className="flex items-baseline justify-between">
                          <div>
                            <span className="text-sm text-slate-600">{priceInfo.label}</span>
                            <div className="flex items-baseline space-x-1">
                              <span className={`text-xl font-semibold ${priceInfo.color}`}>
                                ${priceInfo.amount.toLocaleString()}
                              </span>
                              <span className="text-sm text-slate-600">{priceInfo.period}</span>
                            </div>
                          </div>
                          
                          {quotationType === 'rental' && (
                            <div className="text-right">
                              <div className="text-xs text-slate-500">Semanal:</div>
                              <div className="font-medium text-sm">${product.weeklyRentalRate.toLocaleString()}</div>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Especificaciones destacadas */}
                      {product.specifications && Object.keys(product.specifications).length > 0 && (
                        <div className="mb-4">
                          <div className="grid grid-cols-2 gap-2">
                            {Object.entries(product.specifications).slice(0, 4).map(([key, value]) => (
                              <div key={key} className="text-xs">
                                <span className="text-slate-500">{key}:</span>
                                <p className="font-medium text-slate-700 truncate">{value}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Botón de acción */}
                      <Button 
                        className={`w-full ${isAvailable 
                          ? quotationType === 'sale' 
                            ? 'bg-green-600 hover:bg-green-700' 
                            : 'bg-blue-600 hover:bg-blue-700'
                          : 'bg-slate-400 cursor-not-allowed'
                        } text-white group-hover:shadow-md transition-all`}
                        disabled={!isAvailable}
                        onClick={(e) => {
                          e.stopPropagation();
                          if (isAvailable) onProductSelect(product);
                        }}
                      >
                        {quotationType === 'sale' ? (
                          <>
                            <ShoppingCart className="w-4 h-4 mr-2" />
                            Agregar a Venta
                          </>
                        ) : (
                          <>
                            <Calendar className="w-4 h-4 mr-2" />
                            Agregar a Renta
                          </>
                        )}
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Navigation */}
      <div className="flex justify-between mt-8">
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Volver al Tipo
        </Button>
        
        {filteredProducts.length > 0 && (
          <div className="text-sm text-slate-500 flex items-center">
            <Info className="w-4 h-4 mr-2" />
            Mostrando {filteredProducts.length} de {products.length} productos
          </div>
        )}
      </div>
    </div>
  );
}