import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { Edit, User, Building, Phone, Mail, MapPin, CreditCard, Calendar, Star, FileText, History } from 'lucide-react';
import { Customer, CustomerTransaction } from '../types/rental';

interface CustomerDetailsProps {
  customer: Customer;
  transactions: CustomerTransaction[];
  onEdit: () => void;
  onClose: () => void;
}

export function CustomerDetails({ 
  customer, 
  transactions, 
  onEdit, 
  onClose 
}: CustomerDetailsProps) {
  
  // Utilidades
  const getSegmentText = (segment: string) => {
    switch (segment) {
      case 'individual': return 'Individual';
      case 'small_business': return 'Pequeña Empresa';
      case 'medium_business': return 'Mediana Empresa';
      case 'enterprise': return 'Gran Empresa';
      case 'government': return 'Gobierno';
      default: return segment;
    }
  };

  const getSegmentColor = (segment: string) => {
    switch (segment) {
      case 'individual': return 'bg-gray-100 text-gray-800';
      case 'small_business': return 'bg-blue-100 text-blue-800';
      case 'medium_business': return 'bg-green-100 text-green-800';
      case 'enterprise': return 'bg-purple-100 text-purple-800';
      case 'government': return 'bg-indigo-100 text-indigo-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'inactive': return 'bg-gray-100 text-gray-800';
      case 'blacklisted': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPaymentMethodText = (method: string) => {
    switch (method) {
      case 'cash': return 'Efectivo';
      case 'transfer': return 'Transferencia';
      case 'check': return 'Cheque';
      case 'credit': return 'Crédito';
      default: return method;
    }
  };

  const getRatingColor = (rating: number) => {
    if (rating >= 4.5) return 'text-green-600';
    if (rating >= 3.5) return 'text-yellow-600';
    return 'text-red-600';
  };

  // Calcular estadísticas de transacciones
  const transactionStats = {
    total: transactions.length,
    completed: transactions.filter(t => t.status === 'completed').length,
    totalAmount: transactions.reduce((sum, t) => sum + t.amount, 0),
    lastTransaction: transactions.length > 0 ? 
      transactions.sort((a, b) => new Date(b.transactionDate).getTime() - new Date(a.transactionDate).getTime())[0] : null
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h2 className="text-2xl text-slate-900">{customer.personalInfo.name}</h2>
            <Badge className={getStatusColor(customer.status)}>
              {customer.status === 'active' ? 'Activo' : 
               customer.status === 'inactive' ? 'Inactivo' : 'Lista Negra'}
            </Badge>
          </div>
          <p className="text-slate-600 mb-3">{customer.personalInfo.company}</p>
          <div className="flex flex-wrap gap-2">
            <Badge className={getSegmentColor(customer.segment)}>
              {getSegmentText(customer.segment)}
            </Badge>
            <Badge variant="outline" className="flex items-center gap-1">
              <Star className={`w-3 h-3 fill-current ${getRatingColor(customer.rating.score)}`} />
              {customer.rating.score} / 5.0
            </Badge>
          </div>
        </div>
        <div className="flex gap-2">
          <Button onClick={onEdit} className="bg-blue-600 hover:bg-blue-700">
            <Edit className="w-4 h-4 mr-2" />
            Editar
          </Button>
          <Button variant="outline" onClick={onClose}>
            Cerrar
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <User className="w-4 h-4" />
            General
          </TabsTrigger>
          <TabsTrigger value="financial" className="flex items-center gap-2">
            <CreditCard className="w-4 h-4" />
            Financiero
          </TabsTrigger>
          <TabsTrigger value="transactions" className="flex items-center gap-2">
            <History className="w-4 h-4" />
            Transacciones
          </TabsTrigger>
          <TabsTrigger value="rating" className="flex items-center gap-2">
            <Star className="w-4 h-4" />
            Calificación
          </TabsTrigger>
        </TabsList>

        {/* Pestaña General */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Información de contacto */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5" />
                  Información de Contacto
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Building className="w-4 h-4 text-slate-400" />
                    <div>
                      <p className="text-sm text-slate-600">Empresa</p>
                      <p className="font-medium">{customer.personalInfo.company || 'No especificada'}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <Phone className="w-4 h-4 text-slate-400" />
                    <div>
                      <p className="text-sm text-slate-600">Teléfono Principal</p>
                      <p className="font-medium">{customer.personalInfo.phone}</p>
                    </div>
                  </div>

                  {customer.alternativePhone && (
                    <div className="flex items-center gap-3">
                      <Phone className="w-4 h-4 text-slate-400" />
                      <div>
                        <p className="text-sm text-slate-600">Teléfono Alternativo</p>
                        <p className="font-medium">{customer.alternativePhone}</p>
                      </div>
                    </div>
                  )}
                  
                  <div className="flex items-center gap-3">
                    <Mail className="w-4 h-4 text-slate-400" />
                    <div>
                      <p className="text-sm text-slate-600">Email</p>
                      <p className="font-medium">{customer.personalInfo.email}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <MapPin className="w-4 h-4 text-slate-400 mt-1" />
                    <div>
                      <p className="text-sm text-slate-600">Dirección</p>
                      <p className="font-medium">{customer.personalInfo.address || 'No especificada'}</p>
                    </div>
                  </div>

                  {customer.contactPerson && (
                    <div className="flex items-center gap-3">
                      <User className="w-4 h-4 text-slate-400" />
                      <div>
                        <p className="text-sm text-slate-600">Persona de Contacto</p>
                        <p className="font-medium">{customer.contactPerson}</p>
                      </div>
                    </div>
                  )}
                </div>

                <Separator />

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-slate-600">NIT/Cédula:</p>
                    <p className="font-medium">{customer.personalInfo.taxId || 'No especificado'}</p>
                  </div>
                  {customer.website && (
                    <div>
                      <p className="text-slate-600">Sitio Web:</p>
                      <p className="font-medium">{customer.website}</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Estadísticas generales */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Estadísticas del Cliente
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-slate-50 rounded-lg">
                    <div className="text-2xl text-blue-600 mb-1">{customer.totalTransactions}</div>
                    <p className="text-sm text-slate-600">Transacciones</p>
                  </div>
                  <div className="text-center p-3 bg-slate-50 rounded-lg">
                    <div className="text-2xl text-green-600 mb-1">${(customer.totalSpent / 1000000).toFixed(1)}M</div>
                    <p className="text-sm text-slate-600">Facturado</p>
                  </div>
                </div>

                <Separator />

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Registro:</span>
                    <span className="font-medium">{new Date(customer.registrationDate).toLocaleDateString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Última Actividad:</span>
                    <span className="font-medium">{new Date(customer.lastActivityDate).toLocaleDateString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Segmento:</span>
                    <Badge className={getSegmentColor(customer.segment)}>
                      {getSegmentText(customer.segment)}
                    </Badge>
                  </div>
                </div>

                {customer.notes && (
                  <>
                    <Separator />
                    <div>
                      <p className="text-sm text-slate-600 mb-2">Notas:</p>
                      <p className="text-sm bg-slate-50 p-3 rounded-lg">{customer.notes}</p>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Pestaña Financiera */}
        <TabsContent value="financial" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Información crediticia */}
            <Card>
              <CardHeader>
                <CardTitle>Información Crediticia</CardTitle>
                <CardDescription>Estado de crédito y condiciones de pago</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-slate-600">Límite de Crédito</p>
                    <p className="text-2xl font-semibold text-blue-600">${customer.creditLimit.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Deuda Actual</p>
                    <p className="text-2xl font-semibold text-orange-600">${customer.currentDebt.toLocaleString()}</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-sm text-slate-600">Disponible</p>
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>Crédito Disponible:</span>
                      <span className="font-medium">${(customer.creditLimit - customer.currentDebt).toLocaleString()}</span>
                    </div>
                    <Progress 
                      value={((customer.creditLimit - customer.currentDebt) / customer.creditLimit) * 100} 
                      className="h-2" 
                    />
                  </div>
                </div>

                <Separator />

                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-slate-600">Términos de Pago:</span>
                    <span className="font-medium">{customer.paymentTerms} días</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-slate-600">Método Preferido:</span>
                    <span className="font-medium">{getPaymentMethodText(customer.paymentMethod)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Resumen de transacciones */}
            <Card>
              <CardHeader>
                <CardTitle>Resumen de Actividad</CardTitle>
                <CardDescription>Estadísticas de transacciones</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-slate-50 rounded-lg">
                    <div className="text-2xl text-slate-900 mb-1">{transactionStats.total}</div>
                    <p className="text-sm text-slate-600">Total Transacciones</p>
                  </div>
                  <div className="text-center p-3 bg-slate-50 rounded-lg">
                    <div className="text-2xl text-green-600 mb-1">{transactionStats.completed}</div>
                    <p className="text-sm text-slate-600">Completadas</p>
                  </div>
                </div>

                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-3xl text-blue-600 mb-1">${transactionStats.totalAmount.toLocaleString()}</div>
                  <p className="text-sm text-slate-600">Volumen Total de Transacciones</p>
                </div>

                {transactionStats.lastTransaction && (
                  <>
                    <Separator />
                    <div>
                      <p className="text-sm text-slate-600 mb-2">Última Transacción:</p>
                      <div className="bg-slate-50 p-3 rounded-lg">
                        <p className="font-medium">{transactionStats.lastTransaction.description}</p>
                        <p className="text-sm text-slate-500">{new Date(transactionStats.lastTransaction.transactionDate).toLocaleDateString()}</p>
                        <p className="text-sm font-medium text-green-600">${transactionStats.lastTransaction.amount.toLocaleString()}</p>
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Pestaña Transacciones */}
        <TabsContent value="transactions" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Historial de Transacciones</CardTitle>
              <CardDescription>Todas las transacciones del cliente</CardDescription>
            </CardHeader>
            <CardContent>
              {transactions.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Referencia</TableHead>
                      <TableHead>Descripción</TableHead>
                      <TableHead>Monto</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead>Fecha</TableHead>
                      <TableHead>Asesor</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactions.map(transaction => (
                      <TableRow key={transaction.id}>
                        <TableCell>
                          <Badge variant={transaction.type === 'payment' ? 'default' : 'secondary'}>
                            {transaction.type === 'rental' ? 'Renta' :
                             transaction.type === 'sale' ? 'Venta' :
                             transaction.type === 'payment' ? 'Pago' : 
                             transaction.type === 'service' ? 'Servicio' : transaction.type}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-mono text-sm">{transaction.referenceNumber}</TableCell>
                        <TableCell>{transaction.description}</TableCell>
                        <TableCell className="font-medium">${transaction.amount.toLocaleString()}</TableCell>
                        <TableCell>
                          <Badge variant={transaction.status === 'completed' ? 'default' : 'secondary'}>
                            {transaction.status === 'completed' ? 'Completada' : transaction.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{new Date(transaction.transactionDate).toLocaleDateString()}</TableCell>
                        <TableCell>{transaction.advisorName}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-8">
                  <History className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-500">No hay transacciones registradas</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Pestaña Calificación */}
        <TabsContent value="rating" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Calificación del Cliente</CardTitle>
              <CardDescription>Evaluación detallada del desempeño</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Star className={`w-8 h-8 fill-current ${getRatingColor(customer.rating.score)}`} />
                  <span className="text-3xl font-semibold">{customer.rating.score}</span>
                  <span className="text-lg text-slate-500">/ 5.0</span>
                </div>
                <p className="text-slate-600">Calificación General</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Confiabilidad de Pago</span>
                      <span className="text-sm">{customer.rating.paymentReliability}/5</span>
                    </div>
                    <Progress value={(customer.rating.paymentReliability / 5) * 100} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Calidad de Comunicación</span>
                      <span className="text-sm">{customer.rating.communicationQuality}/5</span>
                    </div>
                    <Progress value={(customer.rating.communicationQuality / 5) * 100} className="h-2" />
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Cuidado de Equipos</span>
                      <span className="text-sm">{customer.rating.equipmentCare}/5</span>
                    </div>
                    <Progress value={(customer.rating.equipmentCare / 5) * 100} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Satisfacción General</span>
                      <span className="text-sm">{customer.rating.overallSatisfaction}/5</span>
                    </div>
                    <Progress value={(customer.rating.overallSatisfaction / 5) * 100} className="h-2" />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-3">
                <div>
                  <p className="text-sm font-medium text-slate-600">Última Evaluación:</p>
                  <p>{new Date(customer.rating.lastReviewDate).toLocaleDateString()}</p>
                </div>
                
                {customer.rating.reviewNotes && (
                  <div>
                    <p className="text-sm font-medium text-slate-600 mb-2">Notas de Evaluación:</p>
                    <p className="text-sm bg-slate-50 p-3 rounded-lg">{customer.rating.reviewNotes}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}