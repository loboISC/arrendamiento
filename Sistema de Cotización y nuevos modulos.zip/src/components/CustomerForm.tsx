import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Separator } from './ui/separator';
import { Customer } from '../types/rental';

interface CustomerFormProps {
  customer?: Customer | null;
  onSubmit: (customerData: Omit<Customer, 'id' | 'registrationDate' | 'lastActivityDate' | 'totalTransactions' | 'totalSpent'>) => void;
  onCancel: () => void;
}

export function CustomerForm({ customer, onSubmit, onCancel }: CustomerFormProps) {
  const [formData, setFormData] = useState({
    // Información personal
    name: '',
    company: '',
    phone: '',
    email: '',
    address: '',
    taxId: '',
    alternativePhone: '',
    contactPerson: '',
    website: '',
    
    // Clasificación
    segment: 'individual' as const,
    
    // Información financiera
    creditLimit: 0,
    currentDebt: 0,
    paymentTerms: 30,
    paymentMethod: 'transfer' as const,
    
    // Calificación
    score: 5,
    paymentReliability: 5,
    communicationQuality: 5,
    equipmentCare: 5,
    overallSatisfaction: 5,
    lastReviewDate: new Date().toISOString().split('T')[0],
    reviewNotes: '',
    
    // Estado
    status: 'active' as const,
    notes: ''
  });

  // Cargar datos del cliente en edición
  useEffect(() => {
    if (customer) {
      setFormData({
        name: customer.personalInfo.name,
        company: customer.personalInfo.company,
        phone: customer.personalInfo.phone,
        email: customer.personalInfo.email,
        address: customer.personalInfo.address,
        taxId: customer.personalInfo.taxId,
        alternativePhone: customer.alternativePhone || '',
        contactPerson: customer.contactPerson || '',
        website: customer.website || '',
        segment: customer.segment,
        creditLimit: customer.creditLimit,
        currentDebt: customer.currentDebt,
        paymentTerms: customer.paymentTerms,
        paymentMethod: customer.paymentMethod,
        score: customer.rating.score,
        paymentReliability: customer.rating.paymentReliability,
        communicationQuality: customer.rating.communicationQuality,
        equipmentCare: customer.rating.equipmentCare,
        overallSatisfaction: customer.rating.overallSatisfaction,
        lastReviewDate: customer.rating.lastReviewDate,
        reviewNotes: customer.rating.reviewNotes,
        status: customer.status,
        notes: customer.notes
      });
    }
  }, [customer]);

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validaciones básicas
    if (!formData.name.trim() || !formData.email.trim()) {
      alert('Por favor completa los campos obligatorios (Nombre y Email)');
      return;
    }

    // Preparar datos para envío
    const customerData: Omit<Customer, 'id' | 'registrationDate' | 'lastActivityDate' | 'totalTransactions' | 'totalSpent'> = {
      personalInfo: {
        name: formData.name.trim(),
        company: formData.company.trim(),
        phone: formData.phone.trim(),
        email: formData.email.trim(),
        address: formData.address.trim(),
        taxId: formData.taxId.trim()
      },
      rating: {
        score: formData.score,
        paymentReliability: formData.paymentReliability,
        communicationQuality: formData.communicationQuality,
        equipmentCare: formData.equipmentCare,
        overallSatisfaction: formData.overallSatisfaction,
        lastReviewDate: formData.lastReviewDate,
        reviewNotes: formData.reviewNotes.trim()
      },
      segment: formData.segment,
      alternativePhone: formData.alternativePhone.trim() || undefined,
      contactPerson: formData.contactPerson.trim() || undefined,
      website: formData.website.trim() || undefined,
      creditLimit: formData.creditLimit,
      currentDebt: formData.currentDebt,
      paymentTerms: formData.paymentTerms,
      paymentMethod: formData.paymentMethod,
      status: formData.status,
      notes: formData.notes.trim()
    };

    onSubmit(customerData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Información personal */}
      <Card>
        <CardHeader>
          <CardTitle>Información Personal</CardTitle>
          <CardDescription>Datos de identificación y contacto del cliente</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nombre Completo *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                placeholder="Ej: Juan Carlos Rodríguez"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="company">Empresa</Label>
              <Input
                id="company"
                value={formData.company}
                onChange={(e) => handleInputChange('company', e.target.value)}
                placeholder="Ej: Constructora ABC S.A.S."
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="phone">Teléfono Principal *</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                placeholder="+57 300 123 4567"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="alternativePhone">Teléfono Alternativo</Label>
              <Input
                id="alternativePhone"
                value={formData.alternativePhone}
                onChange={(e) => handleInputChange('alternativePhone', e.target.value)}
                placeholder="+57 310 987 6543"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="contactPerson">Persona de Contacto</Label>
              <Input
                id="contactPerson"
                value={formData.contactPerson}
                onChange={(e) => handleInputChange('contactPerson', e.target.value)}
                placeholder="Ej: María González (Gerente)"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                placeholder="contacto@empresa.com"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="website">Sitio Web</Label>
              <Input
                id="website"
                value={formData.website}
                onChange={(e) => handleInputChange('website', e.target.value)}
                placeholder="https://www.empresa.com"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="address">Dirección</Label>
              <Textarea
                id="address"
                value={formData.address}
                onChange={(e) => handleInputChange('address', e.target.value)}
                placeholder="Dirección completa..."
                rows={2}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="taxId">NIT / Cédula</Label>
              <Input
                id="taxId"
                value={formData.taxId}
                onChange={(e) => handleInputChange('taxId', e.target.value)}
                placeholder="900123456-1"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Clasificación del cliente */}
      <Card>
        <CardHeader>
          <CardTitle>Clasificación del Cliente</CardTitle>
          <CardDescription>Segmentación y categorización</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="segment">Segmento</Label>
              <Select 
                value={formData.segment} 
                onValueChange={(value: any) => handleInputChange('segment', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="individual">Individual</SelectItem>
                  <SelectItem value="small_business">Pequeña Empresa</SelectItem>
                  <SelectItem value="medium_business">Mediana Empresa</SelectItem>
                  <SelectItem value="enterprise">Gran Empresa</SelectItem>
                  <SelectItem value="government">Gobierno</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Estado</Label>
              <Select 
                value={formData.status} 
                onValueChange={(value: any) => handleInputChange('status', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Activo</SelectItem>
                  <SelectItem value="inactive">Inactivo</SelectItem>
                  <SelectItem value="blacklisted">Lista Negra</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Información financiera */}
      <Card>
        <CardHeader>
          <CardTitle>Información Financiera</CardTitle>
          <CardDescription>Configuración de crédito y términos de pago</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="creditLimit">Límite de Crédito ($)</Label>
              <Input
                id="creditLimit"
                type="number"
                value={formData.creditLimit}
                onChange={(e) => handleInputChange('creditLimit', Number(e.target.value))}
                placeholder="0"
                min="0"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="currentDebt">Deuda Actual ($)</Label>
              <Input
                id="currentDebt"
                type="number"
                value={formData.currentDebt}
                onChange={(e) => handleInputChange('currentDebt', Number(e.target.value))}
                placeholder="0"
                min="0"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="paymentTerms">Términos de Pago (días)</Label>
              <Input
                id="paymentTerms"
                type="number"
                value={formData.paymentTerms}
                onChange={(e) => handleInputChange('paymentTerms', Number(e.target.value))}
                placeholder="30"
                min="0"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="paymentMethod">Método de Pago Preferido</Label>
              <Select 
                value={formData.paymentMethod} 
                onValueChange={(value: any) => handleInputChange('paymentMethod', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Efectivo</SelectItem>
                  <SelectItem value="transfer">Transferencia</SelectItem>
                  <SelectItem value="check">Cheque</SelectItem>
                  <SelectItem value="credit">Crédito</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Calificación del cliente */}
      <Card>
        <CardHeader>
          <CardTitle>Calificación del Cliente</CardTitle>
          <CardDescription>Evaluación del desempeño y confiabilidad</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="score">Calificación General (1-5)</Label>
              <Input
                id="score"
                type="number"
                value={formData.score}
                onChange={(e) => handleInputChange('score', Number(e.target.value))}
                min="1"
                max="5"
                step="0.1"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="paymentReliability">Confiabilidad de Pago (1-5)</Label>
              <Input
                id="paymentReliability"
                type="number"
                value={formData.paymentReliability}
                onChange={(e) => handleInputChange('paymentReliability', Number(e.target.value))}
                min="1"
                max="5"
                step="1"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="communicationQuality">Calidad de Comunicación (1-5)</Label>
              <Input
                id="communicationQuality"
                type="number"
                value={formData.communicationQuality}
                onChange={(e) => handleInputChange('communicationQuality', Number(e.target.value))}
                min="1"
                max="5"
                step="1"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="equipmentCare">Cuidado de Equipos (1-5)</Label>
              <Input
                id="equipmentCare"
                type="number"
                value={formData.equipmentCare}
                onChange={(e) => handleInputChange('equipmentCare', Number(e.target.value))}
                min="1"
                max="5"
                step="1"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="overallSatisfaction">Satisfacción General (1-5)</Label>
              <Input
                id="overallSatisfaction"
                type="number"
                value={formData.overallSatisfaction}
                onChange={(e) => handleInputChange('overallSatisfaction', Number(e.target.value))}
                min="1"
                max="5"
                step="1"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lastReviewDate">Fecha de Última Evaluación</Label>
              <Input
                id="lastReviewDate"
                type="date"
                value={formData.lastReviewDate}
                onChange={(e) => handleInputChange('lastReviewDate', e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="reviewNotes">Notas de Evaluación</Label>
            <Textarea
              id="reviewNotes"
              value={formData.reviewNotes}
              onChange={(e) => handleInputChange('reviewNotes', e.target.value)}
              placeholder="Observaciones sobre el desempeño del cliente..."
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      {/* Notas adicionales */}
      <Card>
        <CardHeader>
          <CardTitle>Notas Adicionales</CardTitle>
          <CardDescription>Información adicional y observaciones</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Label htmlFor="notes">Notas Generales</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => handleInputChange('notes', e.target.value)}
              placeholder="Observaciones generales, preferencias, restricciones, etc..."
              rows={4}
            />
          </div>
        </CardContent>
      </Card>

      <Separator />

      {/* Botones de acción */}
      <div className="flex justify-end gap-3">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancelar
        </Button>
        <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
          {customer ? 'Actualizar Cliente' : 'Crear Cliente'}
        </Button>
      </div>
    </form>
  );
}