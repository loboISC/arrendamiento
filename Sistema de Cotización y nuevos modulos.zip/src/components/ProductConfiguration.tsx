import { useState } from 'react';
import { ArrowLeft, ArrowRight, Plus, Minus, Calendar, Clock, MapPin, Truck, Package, Info, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Checkbox } from './ui/checkbox';
import { DatePicker } from './ui/calendar';
import { QuotationType, Product, RentalPeriod, Accessory, RentalItem, SaleItem } from '../types/rental';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ProductConfigurationProps {
  quotationType: QuotationType;
  product: Product;
  accessories: Accessory[];
  onAddItem: (item: RentalItem | SaleItem) => void;
  onBack: () => void;
}

export function ProductConfiguration({
  quotationType,
  product,
  accessories,
  onAddItem,
  onBack
}: ProductConfigurationProps) {
  const [quantity, setQuantity] = useState(1);
  const [rentalPeriod, setRentalPeriod] = useState<RentalPeriod>('daily');
  const [rentalDuration, setRentalDuration] = useState(1);
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());
  const [requiresDelivery, setRequiresDelivery] = useState(false);
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [deliveryInstructions, setDeliveryInstructions] = useState('');
  const [observations, setObservations] = useState('');
  const [selectedAccessories, setSelectedAccessories] = useState<string[]>([]);

  // Calcular fecha de fin automáticamente
  const calculateEndDate = () => {
    const start = new Date(startDate);
    let days = 0;
    
    switch (rentalPeriod) {
      case 'daily':
        days = rentalDuration;
        break;
      case 'weekly':
        days = rentalDuration * 7;
        break;
      case 'monthly':
        days = rentalDuration * 30;
        break;
      case 'yearly':
        days = rentalDuration * 365;
        break;
    }
    
    const end = new Date(start);
    end.setDate(start.getDate() + days);
    setEndDate(end);
  };

  useState(() => {
    calculateEndDate();
  }, [rentalPeriod, rentalDuration, startDate]);

  const getRentalRate = () => {
    switch (rentalPeriod) {
      case 'daily':
        return product.dailyRentalRate;
      case 'weekly':
        return product.weeklyRentalRate;
      case 'monthly':
        return product.monthlyRentalRate;
      case 'yearly':
        return product.yearlyRentalRate;
      default:
        return product.dailyRentalRate;
    }
  };

  const calculateTotal = () => {
    if (quotationType === 'sale') {
      return product.salePrice * quantity;
    } else {
      const rate = getRentalRate();
      const accessoryCost = selectedAccessories.reduce((total, accessoryId) => {
        const accessory = accessories.find(acc => acc.id === accessoryId);
        return total + (accessory?.additionalCost || 0);
      }, 0);
      
      return (rate * rentalDuration + accessoryCost) * quantity;
    }
  };

  const getPeriodLabel = () => {
    switch (rentalPeriod) {
      case 'daily':
        return rentalDuration === 1 ? 'día' : 'días';
      case 'weekly':
        return rentalDuration === 1 ? 'semana' : 'semanas';
      case 'monthly':
        return rentalDuration === 1 ? 'mes' : 'meses';
      case 'yearly':
        return rentalDuration === 1 ? 'año' : 'años';
      default:
        return 'días';
    }
  };

  const handleAccessoryToggle = (accessoryId: string) => {
    setSelectedAccessories(prev => 
      prev.includes(accessoryId) 
        ? prev.filter(id => id !== accessoryId)
        : [...prev, accessoryId]
    );
  };

  const handleAddToQuotation = () => {
    const baseItem = {
      id: `${Date.now()}-${Math.random()}`,
      productId: product.id,
      product: product,
      quantity,
      deliveryAddress,
      deliveryInstructions,
      requiresDelivery,
      deliveryCost: requiresDelivery ? 50000 : 0, // Costo simulado
      observations
    };

    if (quotationType === 'sale') {
      const saleItem: SaleItem = {
        ...baseItem,
        unitPrice: product.salePrice,
        totalPrice: calculateTotal(),
        discount: 0
      };
      onAddItem(saleItem);
    } else {
      const rentalItem: RentalItem = {
        ...baseItem,
        rentalPeriod,
        rentalDuration,
        unitRate: getRentalRate(),
        totalRate: calculateTotal(),
        startDate: startDate.toISOString().split('T')[0],
        endDate: endDate.toISOString().split('T')[0],
        accessories: selectedAccessories.map(accessoryId => {
          const accessory = accessories.find(acc => acc.id === accessoryId)!;
          return {
            accessoryId,
            accessory,
            quantity: 1,
            totalCost: accessory.additionalCost
          };
        })
      };
      onAddItem(rentalItem);
    }
  };

  const isFormValid = quantity > 0 && quantity <= product.availableStock;

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-slate-800 mb-2">
          Configurar Producto
        </h1>
        <p className="text-slate-600">
          Define las especificaciones y detalles para {quotationType === 'sale' ? 'la venta' : 'la renta'}.
        </p>

        {/* Progress */}
        <div className="flex items-center justify-center mt-6 mb-6">
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center text-sm font-medium">✓</div>
              <span className="ml-2 text-green-600 font-medium">Tipo</span>
            </div>
            <ArrowRight className="w-4 h-4 text-slate-400" />
            <div className="flex items-center">
              <div className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center text-sm font-medium">✓</div>
              <span className="ml-2 text-green-600 font-medium">Productos</span>
            </div>
            <ArrowRight className="w-4 h-4 text-slate-400" />
            <div className="flex items-center">
              <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-medium">3</div>
              <span className="ml-2 text-blue-600 font-medium">Configuración</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Información del producto */}
        <div className="lg:col-span-1">
          <Card className="sticky top-4">
            <CardHeader>
              <CardTitle className="text-lg">Producto Seleccionado</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Imagen */}
              <div className="aspect-square bg-slate-100 rounded-lg overflow-hidden">
                {product.images.length > 0 ? (
                  <ImageWithFallback
                    src={product.images[0]}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Package className="w-12 h-12 text-slate-400" />
                  </div>
                )}
              </div>

              {/* Detalles */}
              <div>
                <h3 className="font-medium text-slate-800 mb-2">{product.name}</h3>
                <p className="text-sm text-slate-600 mb-3">{product.description}</p>
                
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-slate-500">SKU:</span>
                    <p className="font-medium">{product.sku}</p>
                  </div>
                  <div>
                    <span className="text-slate-500">Marca:</span>
                    <p className="font-medium">{product.brand}</p>
                  </div>
                  <div>
                    <span className="text-slate-500">Stock:</span>
                    <p className="font-medium text-green-600">{product.availableStock} disponibles</p>
                  </div>
                  <div>
                    <span className="text-slate-500">Estado:</span>
                    <Badge variant="outline" className="text-xs">
                      {product.condition === 'new' ? 'Nuevo' : 'Usado'}
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Precio base */}
              <div className="bg-slate-50 p-4 rounded-lg">
                <h4 className="text-sm text-slate-600 mb-2">
                  {quotationType === 'sale' ? 'Precio de venta' : 'Tarifas de renta'}
                </h4>
                
                {quotationType === 'sale' ? (
                  <p className="text-xl font-semibold text-slate-800">
                    ${product.salePrice.toLocaleString()}
                  </p>
                ) : (
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span>Diario:</span>
                      <span className="font-medium">${product.dailyRentalRate.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Semanal:</span>
                      <span className="font-medium">${product.weeklyRentalRate.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Mensual:</span>
                      <span className="font-medium">${product.monthlyRentalRate.toLocaleString()}</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Total calculado */}
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h4 className="text-sm text-blue-700 mb-2">Total estimado</h4>
                <p className="text-2xl font-semibold text-blue-800">
                  ${calculateTotal().toLocaleString()}
                </p>
                {quotationType === 'rental' && (
                  <p className="text-xs text-blue-600 mt-1">
                    Por {rentalDuration} {getPeriodLabel()} × {quantity} unidad(es)
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Configuración */}
        <div className="lg:col-span-2 space-y-6">
          {/* Cantidad */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Package className="w-5 h-5 mr-2" />
                Cantidad
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4">
                <Label htmlFor="quantity">Cantidad requerida:</Label>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    disabled={quantity <= 1}
                  >
                    <Minus className="w-4 h-4" />
                  </Button>
                  <Input
                    id="quantity"
                    type="number"
                    min="1"
                    max={product.availableStock}
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, Math.min(product.availableStock, parseInt(e.target.value) || 1)))}
                    className="w-20 text-center"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setQuantity(Math.min(product.availableStock, quantity + 1))}
                    disabled={quantity >= product.availableStock}
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <span className="text-sm text-slate-600">
                  de {product.availableStock} disponibles
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Configuración de renta (solo para renta) */}
          {quotationType === 'rental' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="w-5 h-5 mr-2" />
                  Período de Renta
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="period">Tipo de período</Label>
                    <Select value={rentalPeriod} onValueChange={(value) => setRentalPeriod(value as RentalPeriod)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="daily">Diario</SelectItem>
                        <SelectItem value="weekly">Semanal</SelectItem>
                        <SelectItem value="monthly">Mensual</SelectItem>
                        <SelectItem value="yearly">Anual</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="duration">Duración ({getPeriodLabel()})</Label>
                    <Input
                      id="duration"
                      type="number"
                      min="1"
                      value={rentalDuration}
                      onChange={(e) => setRentalDuration(Math.max(1, parseInt(e.target.value) || 1))}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="startDate">Fecha de inicio</Label>
                    <Input
                      id="startDate"
                      type="date"
                      value={startDate.toISOString().split('T')[0]}
                      onChange={(e) => setStartDate(new Date(e.target.value))}
                      min={new Date().toISOString().split('T')[0]}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="endDate">Fecha de fin (calculada)</Label>
                    <Input
                      id="endDate"
                      type="date"
                      value={endDate.toISOString().split('T')[0]}
                      readOnly
                      className="bg-slate-50"
                    />
                  </div>
                </div>

                <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-200">
                  <div className="flex items-start space-x-2">
                    <Clock className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                    <div className="text-sm">
                      <p className="text-yellow-800 font-medium">Duración total: {rentalDuration} {getPeriodLabel()}</p>
                      <p className="text-yellow-700">
                        Desde {startDate.toLocaleDateString('es-ES')} hasta {endDate.toLocaleDateString('es-ES')}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Accesorios (si los hay) */}
          {accessories.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Accesorios de Complemento</CardTitle>
                <p className="text-sm text-slate-600">
                  Selecciona los accesorios que necesitas para este producto
                </p>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {accessories.map((accessory) => (
                    <div key={accessory.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Checkbox
                          checked={selectedAccessories.includes(accessory.id)}
                          onCheckedChange={() => handleAccessoryToggle(accessory.id)}
                        />
                        <div className="flex-1">
                          <h4 className="font-medium text-slate-800">{accessory.name}</h4>
                          <p className="text-sm text-slate-600">{accessory.description}</p>
                          {accessory.isRequired && (
                            <Badge variant="outline" className="mt-1 text-xs">
                              Requerido
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-slate-800">
                          ${accessory.additionalCost.toLocaleString()}
                        </p>
                        <p className="text-xs text-slate-600">adicional</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Entrega */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Truck className="w-5 h-5 mr-2" />
                Entrega
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  checked={requiresDelivery}
                  onCheckedChange={setRequiresDelivery}
                />
                <Label htmlFor="delivery">
                  {quotationType === 'sale' 
                    ? 'Requiere entrega en ubicación específica' 
                    : 'Requiere entrega y recogida en obra'
                  }
                </Label>
              </div>

              {requiresDelivery && (
                <div className="space-y-4 pl-6 border-l-2 border-blue-200">
                  <div className="space-y-2">
                    <Label htmlFor="address">Dirección de entrega</Label>
                    <Textarea
                      id="address"
                      value={deliveryAddress}
                      onChange={(e) => setDeliveryAddress(e.target.value)}
                      placeholder="Dirección completa donde se requiere la entrega..."
                      rows={2}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="instructions">Instrucciones especiales</Label>
                    <Textarea
                      id="instructions"
                      value={deliveryInstructions}
                      onChange={(e) => setDeliveryInstructions(e.target.value)}
                      placeholder="Horarios, contacto en obra, acceso especial..."
                      rows={2}
                    />
                  </div>

                  <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                    <div className="flex items-center space-x-2">
                      <Info className="w-4 h-4 text-blue-600" />
                      <span className="text-sm text-blue-700">
                        Costo adicional de entrega: $50,000
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Observaciones */}
          <Card>
            <CardHeader>
              <CardTitle>Observaciones</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={observations}
                onChange={(e) => setObservations(e.target.value)}
                placeholder="Comentarios adicionales, requisitos especiales, condiciones..."
                rows={3}
              />
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex justify-between mt-8">
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Volver a Productos
        </Button>
        
        <Button
          onClick={handleAddToQuotation}
          disabled={!isFormValid}
          className={`${quotationType === 'sale' ? 'bg-green-600 hover:bg-green-700' : 'bg-blue-600 hover:bg-blue-700'} text-white`}
        >
          Agregar a Cotización
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>

      {!isFormValid && (
        <div className="flex items-center justify-center mt-4">
          <div className="flex items-center space-x-2 text-red-600">
            <AlertCircle className="w-4 h-4" />
            <span className="text-sm">
              Verifica la cantidad seleccionada
            </span>
          </div>
        </div>
      )}
    </div>
  );
}