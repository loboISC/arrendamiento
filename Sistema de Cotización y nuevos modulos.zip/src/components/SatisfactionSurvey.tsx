import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Separator } from './ui/separator';
import { Checkbox } from './ui/checkbox';
import { Star, MessageSquare, ThumbsUp, ThumbsDown } from 'lucide-react';
import { Customer, CustomerSatisfactionSurvey } from '../types/rental';

interface SatisfactionSurveyProps {
  customer?: Customer | null;
  onSubmit: (survey: Omit<CustomerSatisfactionSurvey, 'id'>) => void;
  onCancel: () => void;
}

export function SatisfactionSurvey({ customer, onSubmit, onCancel }: SatisfactionSurveyProps) {
  const [surveyData, setSurveyData] = useState({
    customerId: customer?.id || '',
    transactionId: '',
    
    // Calificaciones (1-5)
    productQuality: 5,
    serviceQuality: 5,
    deliveryExperience: 5,
    advisorPerformance: 5,
    overallSatisfaction: 5,
    
    // Comentarios
    positiveComments: '',
    improvementSuggestions: '',
    
    // Recomendación
    wouldRecommend: true,
    
    // Metadata
    responseMethod: 'in_person' as const
  });

  const handleInputChange = (field: string, value: any) => {
    setSurveyData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validaciones básicas
    if (!surveyData.customerId) {
      alert('Por favor selecciona un cliente');
      return;
    }

    const survey: Omit<CustomerSatisfactionSurvey, 'id'> = {
      ...surveyData,
      surveyDate: new Date().toISOString().split('T')[0]
    };

    onSubmit(survey);
  };

  // Componente para calificación con estrellas
  const StarRating = ({ 
    value, 
    onChange, 
    label 
  }: { 
    value: number; 
    onChange: (value: number) => void; 
    label: string;
  }) => (
    <div className="space-y-2">
      <Label>{label}</Label>
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onChange(star)}
            className={`p-1 rounded transition-colors ${
              star <= value 
                ? 'text-yellow-500 hover:text-yellow-600' 
                : 'text-slate-300 hover:text-slate-400'
            }`}
          >
            <Star className={`w-6 h-6 ${star <= value ? 'fill-current' : ''}`} />
          </button>
        ))}
        <span className="ml-2 text-sm text-slate-600">({value}/5)</span>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Información básica */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="w-5 h-5" />
              Información de la Encuesta
            </CardTitle>
            <CardDescription>Datos básicos de la encuesta de satisfacción</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {customer ? (
                <div className="space-y-2">
                  <Label>Cliente</Label>
                  <div className="p-3 bg-slate-50 rounded-lg">
                    <p className="font-medium">{customer.personalInfo.name}</p>
                    <p className="text-sm text-slate-500">{customer.personalInfo.company}</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <Label htmlFor="customerId">ID del Cliente</Label>
                  <Input
                    id="customerId"
                    value={surveyData.customerId}
                    onChange={(e) => handleInputChange('customerId', e.target.value)}
                    placeholder="CUST-001"
                    required
                  />
                </div>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="transactionId">Transacción Relacionada (Opcional)</Label>
                <Input
                  id="transactionId"
                  value={surveyData.transactionId}
                  onChange={(e) => handleInputChange('transactionId', e.target.value)}
                  placeholder="CON-2024-001234"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="responseMethod">Método de Respuesta</Label>
              <Select 
                value={surveyData.responseMethod} 
                onValueChange={(value: any) => handleInputChange('responseMethod', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="phone">Teléfono</SelectItem>
                  <SelectItem value="email">Email</SelectItem>
                  <SelectItem value="in_person">Presencial</SelectItem>
                  <SelectItem value="online">En Línea</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Calificaciones */}
        <Card>
          <CardHeader>
            <CardTitle>Calificaciones de Satisfacción</CardTitle>
            <CardDescription>Evalúa cada aspecto del servicio (1 = Muy Malo, 5 = Excelente)</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <StarRating
                label="Calidad del Producto/Equipo"
                value={surveyData.productQuality}
                onChange={(value) => handleInputChange('productQuality', value)}
              />
              
              <StarRating
                label="Calidad del Servicio"
                value={surveyData.serviceQuality}
                onChange={(value) => handleInputChange('serviceQuality', value)}
              />
              
              <StarRating
                label="Experiencia de Entrega"
                value={surveyData.deliveryExperience}
                onChange={(value) => handleInputChange('deliveryExperience', value)}
              />
              
              <StarRating
                label="Desempeño del Asesor"
                value={surveyData.advisorPerformance}
                onChange={(value) => handleInputChange('advisorPerformance', value)}
              />
            </div>

            <Separator />

            <div className="text-center">
              <StarRating
                label="Satisfacción General"
                value={surveyData.overallSatisfaction}
                onChange={(value) => handleInputChange('overallSatisfaction', value)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Comentarios */}
        <Card>
          <CardHeader>
            <CardTitle>Comentarios y Sugerencias</CardTitle>
            <CardDescription>Retroalimentación detallada del cliente</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="positiveComments" className="flex items-center gap-2">
                <ThumbsUp className="w-4 h-4 text-green-600" />
                Aspectos Positivos
              </Label>
              <Textarea
                id="positiveComments"
                value={surveyData.positiveComments}
                onChange={(e) => handleInputChange('positiveComments', e.target.value)}
                placeholder="¿Qué fue lo que más le gustó del servicio?"
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="improvementSuggestions" className="flex items-center gap-2">
                <ThumbsDown className="w-4 h-4 text-orange-600" />
                Sugerencias de Mejora
              </Label>
              <Textarea
                id="improvementSuggestions"
                value={surveyData.improvementSuggestions}
                onChange={(e) => handleInputChange('improvementSuggestions', e.target.value)}
                placeholder="¿Qué aspectos considera que podríamos mejorar?"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        {/* Recomendación */}
        <Card>
          <CardHeader>
            <CardTitle>Recomendación</CardTitle>
            <CardDescription>Disposición a recomendar nuestros servicios</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="wouldRecommend"
                checked={surveyData.wouldRecommend}
                onCheckedChange={(checked) => handleInputChange('wouldRecommend', checked)}
              />
              <Label htmlFor="wouldRecommend" className="text-base">
                ¿Recomendaría nuestros servicios a otras personas?
              </Label>
            </div>
          </CardContent>
        </Card>

        {/* Resumen de calificaciones */}
        <Card className="bg-slate-50">
          <CardHeader>
            <CardTitle>Resumen de Calificaciones</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-semibold text-blue-600">
                  {surveyData.productQuality}
                </div>
                <div className="text-sm text-slate-600">Producto</div>
              </div>
              <div>
                <div className="text-2xl font-semibold text-green-600">
                  {surveyData.serviceQuality}
                </div>
                <div className="text-sm text-slate-600">Servicio</div>
              </div>
              <div>
                <div className="text-2xl font-semibold text-purple-600">
                  {surveyData.deliveryExperience}
                </div>
                <div className="text-sm text-slate-600">Entrega</div>
              </div>
              <div>
                <div className="text-2xl font-semibold text-orange-600">
                  {surveyData.advisorPerformance}
                </div>
                <div className="text-sm text-slate-600">Asesor</div>
              </div>
              <div>
                <div className="text-2xl font-semibold text-yellow-600 flex items-center justify-center gap-1">
                  <Star className="w-6 h-6 fill-current" />
                  {surveyData.overallSatisfaction}
                </div>
                <div className="text-sm text-slate-600">General</div>
              </div>
              <div>
                <div className="text-2xl font-semibold text-slate-600">
                  {(
                    (surveyData.productQuality + 
                     surveyData.serviceQuality + 
                     surveyData.deliveryExperience + 
                     surveyData.advisorPerformance + 
                     surveyData.overallSatisfaction) / 5
                  ).toFixed(1)}
                </div>
                <div className="text-sm text-slate-600">Promedio</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Separator />

        {/* Botones de acción */}
        <div className="flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancelar
          </Button>
          <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
            <MessageSquare className="w-4 h-4 mr-2" />
            Guardar Encuesta
          </Button>
        </div>
      </form>
    </div>
  );
}