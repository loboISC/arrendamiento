import { useState, useMemo } from 'react';
import { Plus, Package, Search, Filter, AlertTriangle, BarChart3, Edit, Trash2, Eye, Archive, Settings, Building, Wrench } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Alert, AlertDescription } from './ui/alert';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Separator } from './ui/separator';
import { ScaffoldingProductForm } from './ScaffoldingProductForm';
import { ScaffoldingProductDetails } from './ScaffoldingProductDetails';
import { ImageWithFallback } from './figma/ImageWithFallback';

// Tipos específicos para andamios
export interface ScaffoldingCategory {
  id: string;
  name: string;
  description: string;
  parentId?: string;
  isSubcategory: boolean;
}

export interface ScaffoldingProduct {
  id: string;
  sku: string;
  name: string;
  description: string;
  categoryId: string;
  categoryName: string;
  subcategoryId?: string;
  subcategoryName?: string;
  brand: string;
  model: string;
  specifications: Record<string, any>;
  images: string[];
  
  // Precios específicos para andamios
  salePrice: number;
  dailyRentalRate: number;
  weeklyRentalRate: number;
  monthlyRentalRate: number;
  yearlyRentalRate: number;
  
  // Inventario
  totalStock: number;
  availableStock: number;
  rentedStock: number;
  reservedStock: number;
  maintenanceStock: number;
  
  // Estado
  status: 'active' | 'inactive' | 'discontinued';
  condition: 'new' | 'good' | 'fair' | 'maintenance' | 'damaged';
  
  // Metadatos específicos
  weight: number;
  dimensions: {
    length: number;
    width: number;
    height: number;
  };
  material: string;
  loadCapacity: number;
  certifications: string[];
  
  // Control de fechas
  createdAt: string;
  updatedAt: string;
}

interface ScaffoldingInventoryManagementProps {
  onBack: () => void;
}

export function ScaffoldingInventoryManagement({ onBack }: ScaffoldingInventoryManagementProps) {
  // Categorías predefinidas para andamios
  const scaffoldingCategories: ScaffoldingCategory[] = [
    { id: 'CAT-MARCO', name: 'Andamio Marco y Cruceta', description: 'Sistemas de andamio con marcos y crucetas', isSubcategory: false },
    { id: 'CAT-MULTI', name: 'Multidireccional', description: 'Sistemas de andamio multidireccional modular', isSubcategory: false },
    { id: 'CAT-TEMPLETE', name: 'Templetes', description: 'Sistemas de templetes y soporte', isSubcategory: false },
    { id: 'CAT-ACC', name: 'Accesorios', description: 'Accesorios para sistemas de andamio', isSubcategory: false },
    // Subcategorías de accesorios
    { id: 'SUB-RUEDAS', name: 'Ruedas', description: 'Ruedas y sistemas de movilidad', parentId: 'CAT-ACC', isSubcategory: true },
    { id: 'SUB-ESCALERAS', name: 'Escaleras', description: 'Escaleras y sistemas de acceso', parentId: 'CAT-ACC', isSubcategory: true },
    { id: 'SUB-PLATAFORMA', name: 'Plataforma', description: 'Plataformas de trabajo y accesorios', parentId: 'CAT-ACC', isSubcategory: true }
  ];

  // Productos de ejemplo con datos reales
  const [products, setProducts] = useState<ScaffoldingProduct[]>([
    {
      id: 'SCAF-001',
      sku: 'AND-MAR-001',
      name: 'Marco de Andamio 2.00 x 1.20m',
      description: 'Marco de andamio galvanizado de alta resistencia con soldaduras certificadas',
      categoryId: 'CAT-MARCO',
      categoryName: 'Andamio Marco y Cruceta',
      brand: 'ProScaffold',
      model: 'PS-MAR-2012',
      specifications: {
        'Altura': '2.00m',
        'Ancho': '1.20m',
        'Espesor tubo': '2.5mm',
        'Diámetro tubo': '48mm',
        'Certificación': 'EN-12811'
      },
      images: ['https://images.unsplash.com/photo-1699625809637-31c6f327ac96?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjBzY2FmZm9sZGluZyUyMGVxdWlwbWVudHxlbnwxfHx8fDE3NTYxNTkxMjR8MA&ixlib=rb-4.1.0&q=80&w=1080'],
      salePrice: 85000,
      dailyRentalRate: 2500,
      weeklyRentalRate: 15000,
      monthlyRentalRate: 50000,
      yearlyRentalRate: 500000,
      totalStock: 150,
      availableStock: 98,
      rentedStock: 45,
      reservedStock: 5,
      maintenanceStock: 2,
      status: 'active',
      condition: 'good',
      weight: 18.5,
      dimensions: { length: 2.0, width: 1.2, height: 0.15 },
      material: 'Acero galvanizado',
      loadCapacity: 200,
      certifications: ['EN-12811', 'CE'],
      createdAt: '2024-01-15',
      updatedAt: '2024-01-20'
    },
    {
      id: 'SCAF-002',
      sku: 'AND-CRU-001',
      name: 'Cruceta Diagonal 2.00m',
      description: 'Cruceta diagonal para marcos de andamio, fabricada en acero galvanizado',
      categoryId: 'CAT-MARCO',
      categoryName: 'Andamio Marco y Cruceta',
      brand: 'ProScaffold',
      model: 'PS-CRU-200',
      specifications: {
        'Longitud': '2.00m',
        'Espesor tubo': '2.0mm',
        'Diámetro tubo': '25mm',
        'Conexiones': 'Tipo gancho'
      },
      images: ['https://images.unsplash.com/photo-1699625809637-31c6f327ac96?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjBzY2FmZm9sZGluZyUyMGVxdWlwbWVudHxlbnwxfHx8fDE3NTYxNTkxMjR8MA&ixlib=rb-4.1.0&q=80&w=1080'],
      salePrice: 35000,
      dailyRentalRate: 1200,
      weeklyRentalRate: 7000,
      monthlyRentalRate: 22000,
      yearlyRentalRate: 220000,
      totalStock: 200,
      availableStock: 156,
      rentedStock: 38,
      reservedStock: 4,
      maintenanceStock: 2,
      status: 'active',
      condition: 'good',
      weight: 8.2,
      dimensions: { length: 2.0, width: 0.05, height: 0.05 },
      material: 'Acero galvanizado',
      loadCapacity: 150,
      certifications: ['EN-12811'],
      createdAt: '2024-01-15',
      updatedAt: '2024-01-20'
    },
    {
      id: 'SCAF-003',
      sku: 'AND-MUL-001',
      name: 'Roseta Multidireccional 8 Conexiones',
      description: 'Roseta multidireccional con 8 conexiones para sistema modular avanzado',
      categoryId: 'CAT-MULTI',
      categoryName: 'Multidireccional',
      brand: 'MultiSystem',
      model: 'MS-ROS-8',
      specifications: {
        'Conexiones': '8 unidades',
        'Ángulos': '45° graduación',
        'Diámetro tubo': '48mm',
        'Sistema': 'Ringlock'
      },
      images: ['https://images.unsplash.com/photo-1699625809637-31c6f327ac96?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjBzY2FmZm9sZGluZyUyMGVxdWlwbWVudHxlbnwxfHx8fDE3NTYxNTkxMjR8MA&ixlib=rb-4.1.0&q=80&w=1080'],
      salePrice: 125000,
      dailyRentalRate: 4500,
      weeklyRentalRate: 25000,
      monthlyRentalRate: 85000,
      yearlyRentalRate: 850000,
      totalStock: 80,
      availableStock: 45,
      rentedStock: 30,
      reservedStock: 3,
      maintenanceStock: 2,
      status: 'active',
      condition: 'new',
      weight: 12.5,
      dimensions: { length: 0.15, width: 0.15, height: 0.20 },
      material: 'Acero al carbono galvanizado',
      loadCapacity: 300,
      certifications: ['EN-12811', 'CE', 'ISO-9001'],
      createdAt: '2024-01-10',
      updatedAt: '2024-01-18'
    },
    {
      id: 'SCAF-004',
      sku: 'RUE-GIR-001',
      name: 'Rueda Giratoria con Freno 150mm',
      description: 'Rueda giratoria de alta resistencia con sistema de freno para andamios móviles',
      categoryId: 'CAT-ACC',
      categoryName: 'Accesorios',
      subcategoryId: 'SUB-RUEDAS',
      subcategoryName: 'Ruedas',
      brand: 'WheelPro',
      model: 'WP-GIR-150',
      specifications: {
        'Diámetro': '150mm',
        'Capacidad carga': '200kg',
        'Material rueda': 'Poliuretano',
        'Freno': 'Sistema dual'
      },
      images: ['https://images.unsplash.com/photo-1699625809637-31c6f327ac96?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjBzY2FmZm9sZGluZyUyMGVxdWlwbWVudHxlbnwxfHx8fDE3NTYxNTkxMjR8MA&ixlib=rb-4.1.0&q=80&w=1080'],
      salePrice: 45000,
      dailyRentalRate: 1500,
      weeklyRentalRate: 8500,
      monthlyRentalRate: 28000,
      yearlyRentalRate: 280000,
      totalStock: 120,
      availableStock: 89,
      rentedStock: 25,
      reservedStock: 4,
      maintenanceStock: 2,
      status: 'active',
      condition: 'good',
      weight: 3.2,
      dimensions: { length: 0.15, width: 0.15, height: 0.20 },
      material: 'Acero y poliuretano',
      loadCapacity: 200,
      certifications: ['CE'],
      createdAt: '2024-01-12',
      updatedAt: '2024-01-19'
    },
    {
      id: 'SCAF-005',
      sku: 'ESC-ACC-001',
      name: 'Escalera de Acceso 1.50m',
      description: 'Escalera de acceso interna para andamios con sistema antideslizante',
      categoryId: 'CAT-ACC',
      categoryName: 'Accesorios',
      subcategoryId: 'SUB-ESCALERAS',
      subcategoryName: 'Escaleras',
      brand: 'AccessPro',
      model: 'AP-ESC-150',
      specifications: {
        'Altura': '1.50m',
        'Ancho': '0.40m',
        'Peldaños': '6 unidades',
        'Antideslizante': 'Sí'
      },
      images: ['https://images.unsplash.com/photo-1699625809637-31c6f327ac96?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjBzY2FmZm9sZGluZyUyMGVxdWlwbWVudHxlbnwxfHx8fDE3NTYxNTkxMjR8MA&ixlib=rb-4.1.0&q=80&w=1080'],
      salePrice: 180000,
      dailyRentalRate: 6000,
      weeklyRentalRate: 35000,
      monthlyRentalRate: 120000,
      yearlyRentalRate: 1200000,
      totalStock: 35,
      availableStock: 22,
      rentedStock: 10,
      reservedStock: 2,
      maintenanceStock: 1,
      status: 'active',
      condition: 'good',
      weight: 15.8,
      dimensions: { length: 1.5, width: 0.4, height: 0.1 },
      material: 'Acero galvanizado',
      loadCapacity: 250,
      certifications: ['EN-12811', 'CE'],
      createdAt: '2024-01-08',
      updatedAt: '2024-01-17'
    },
    {
      id: 'SCAF-006',
      sku: 'PLA-TRA-001',
      name: 'Plataforma de Trabajo 3.00m',
      description: 'Plataforma de trabajo de aluminio con superficie antideslizante y ganchos de seguridad',
      categoryId: 'CAT-ACC',
      categoryName: 'Accesorios',
      subcategoryId: 'SUB-PLATAFORMA',
      subcategoryName: 'Plataforma',
      brand: 'PlatformPro',
      model: 'PP-TRA-300',
      specifications: {
        'Longitud': '3.00m',
        'Ancho': '0.50m',
        'Material': 'Aluminio',
        'Carga máxima': '300kg/m²'
      },
      images: ['https://images.unsplash.com/photo-1699625809637-31c6f327ac96?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjBzY2FmZm9sZGluZyUyMGVxdWlwbWVudHxlbnwxfHx8fDE3NTYxNTkxMjR8MA&ixlib=rb-4.1.0&q=80&w=1080'],
      salePrice: 320000,
      dailyRentalRate: 12000,
      weeklyRentalRate: 70000,
      monthlyRentalRate: 240000,
      yearlyRentalRate: 2400000,
      totalStock: 45,
      availableStock: 28,
      rentedStock: 15,
      reservedStock: 1,
      maintenanceStock: 1,
      status: 'active',
      condition: 'new',
      weight: 22.5,
      dimensions: { length: 3.0, width: 0.5, height: 0.05 },
      material: 'Aluminio anodizado',
      loadCapacity: 300,
      certifications: ['EN-12811', 'CE', 'ISO-9001'],
      createdAt: '2024-01-05',
      updatedAt: '2024-01-16'
    }
  ]);

  // Estados del componente
  const [activeTab, setActiveTab] = useState('dashboard');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedSubcategory, setSelectedSubcategory] = useState<string>('all');
  const [selectedCondition, setSelectedCondition] = useState<string>('all');
  const [selectedProduct, setSelectedProduct] = useState<ScaffoldingProduct | null>(null);
  const [isProductFormOpen, setIsProductFormOpen] = useState(false);
  const [isProductDetailsOpen, setIsProductDetailsOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<ScaffoldingProduct | null>(null);

  // Productos filtrados
  const filteredProducts = useMemo(() => {
    return products.filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           product.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           product.brand.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesCategory = selectedCategory === 'all' || product.categoryId === selectedCategory;
      const matchesSubcategory = selectedSubcategory === 'all' || product.subcategoryId === selectedSubcategory;
      const matchesCondition = selectedCondition === 'all' || product.condition === selectedCondition;
      
      return matchesSearch && matchesCategory && matchesSubcategory && matchesCondition;
    });
  }, [products, searchTerm, selectedCategory, selectedSubcategory, selectedCondition]);

  // Subcategorías disponibles basadas en la categoría seleccionada
  const availableSubcategories = useMemo(() => {
    if (selectedCategory === 'all' || selectedCategory !== 'CAT-ACC') return [];
    return scaffoldingCategories.filter(cat => 
      cat.isSubcategory && cat.parentId === selectedCategory
    );
  }, [selectedCategory]);

  // Estadísticas del inventario
  const stats = useMemo(() => {
    const totalProducts = products.length;
    const totalStock = products.reduce((sum, product) => sum + product.totalStock, 0);
    const rentedStock = products.reduce((sum, product) => sum + product.rentedStock, 0);
    const availableStock = products.reduce((sum, product) => sum + product.availableStock, 0);
    const lowStockProducts = products.filter(product => product.availableStock <= 10);
    const outOfStockProducts = products.filter(product => product.availableStock === 0);
    const totalValue = products.reduce((sum, product) => sum + (product.salePrice * product.totalStock), 0);
    const rentalValue = products.reduce((sum, product) => sum + (product.monthlyRentalRate * product.rentedStock), 0);

    return {
      totalProducts,
      totalStock,
      rentedStock,
      availableStock,
      lowStockProducts,
      outOfStockProducts,
      totalValue,
      rentalValue
    };
  }, [products]);

  // Handlers CRUD
  const handleCreateProduct = (productData: Omit<ScaffoldingProduct, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newProduct: ScaffoldingProduct = {
      ...productData,
      id: `SCAF-${String(Date.now()).slice(-6)}`,
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0]
    };
    setProducts([...products, newProduct]);
    setIsProductFormOpen(false);
  };

  const handleUpdateProduct = (productData: Omit<ScaffoldingProduct, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (!editingProduct) return;
    
    const updatedProduct: ScaffoldingProduct = {
      ...productData,
      id: editingProduct.id,
      createdAt: editingProduct.createdAt,
      updatedAt: new Date().toISOString().split('T')[0]
    };
    
    setProducts(products.map(p => p.id === editingProduct.id ? updatedProduct : p));
    setEditingProduct(null);
    setIsProductFormOpen(false);
  };

  const handleDeleteProduct = (productId: string) => {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    const confirmMessage = `¿Estás seguro de que deseas eliminar "${product.name}"?\n\nEsta acción no se puede deshacer.`;
    
    if (confirm(confirmMessage)) {
      setProducts(products.filter(p => p.id !== productId));
    }
  };

  const handleViewProduct = (product: ScaffoldingProduct) => {
    setSelectedProduct(product);
    setIsProductDetailsOpen(true);
  };

  const handleEditProduct = (product: ScaffoldingProduct) => {
    setEditingProduct(product);
    setIsProductFormOpen(true);
  };

  // Utilidades
  const getStockStatusColor = (product: ScaffoldingProduct) => {
    if (product.availableStock === 0) return 'bg-red-500';
    if (product.availableStock <= 10) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const getStockStatusText = (product: ScaffoldingProduct) => {
    if (product.availableStock === 0) return 'Sin stock';
    if (product.availableStock <= 10) return 'Stock bajo';
    return 'En stock';
  };

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl text-slate-900">Gestión de Inventario - Andamios</h1>
          <p className="text-slate-600 mt-2">Administra el inventario especializado de sistemas de andamiaje</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={onBack}>
            Volver al Sistema
          </Button>
          <Button 
            onClick={() => {
              setEditingProduct(null);
              setIsProductFormOpen(true);
            }}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nuevo Producto
          </Button>
        </div>
      </div>

      {/* Alertas de stock */}
      {stats.lowStockProducts.length > 0 && (
        <Alert className="mb-6 border-yellow-200 bg-yellow-50">
          <AlertTriangle className="h-4 w-4 text-yellow-600" />
          <AlertDescription>
            <strong>Atención:</strong> Tienes {stats.lowStockProducts.length} productos de andamio con stock bajo 
            y {stats.outOfStockProducts.length} productos sin stock disponible.
          </AlertDescription>
        </Alert>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="dashboard" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            Dashboard
          </TabsTrigger>
          <TabsTrigger value="products" className="flex items-center gap-2">
            <Package className="w-4 h-4" />
            Productos
          </TabsTrigger>
          <TabsTrigger value="categories" className="flex items-center gap-2">
            <Building className="w-4 h-4" />
            Categorías
          </TabsTrigger>
          <TabsTrigger value="maintenance" className="flex items-center gap-2">
            <Wrench className="w-4 h-4" />
            Mantenimiento
          </TabsTrigger>
        </TabsList>

        {/* Dashboard */}
        <TabsContent value="dashboard" className="space-y-6">
          {/* Estadísticas principales */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-slate-600">Total Productos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-slate-900">{stats.totalProducts}</div>
                <p className="text-sm text-slate-500 mt-1">Productos de andamio</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-slate-600">Stock Total</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-slate-900">{stats.totalStock.toLocaleString()}</div>
                <p className="text-sm text-slate-500 mt-1">Unidades en inventario</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-slate-600">En Renta</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-blue-600">{stats.rentedStock.toLocaleString()}</div>
                <p className="text-sm text-slate-500 mt-1">Unidades rentadas</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-slate-600">Valor Inventario</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-green-600">${(stats.totalValue / 1000000).toFixed(1)}M</div>
                <p className="text-sm text-slate-500 mt-1">Valor total del inventario</p>
              </CardContent>
            </Card>
          </div>

          {/* Resumen por categorías */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Distribución por Categoría</CardTitle>
                <CardDescription>Stock disponible por tipo de producto</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {scaffoldingCategories.filter(cat => !cat.isSubcategory).map(category => {
                  const categoryProducts = products.filter(p => p.categoryId === category.id);
                  const categoryStock = categoryProducts.reduce((sum, p) => sum + p.availableStock, 0);
                  const totalCategoryStock = categoryProducts.reduce((sum, p) => sum + p.totalStock, 0);
                  const percentage = totalCategoryStock > 0 ? (categoryStock / totalCategoryStock) * 100 : 0;
                  
                  return (
                    <div key={category.id} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">{category.name}</span>
                        <span className="text-sm text-slate-500">{categoryStock}/{totalCategoryStock}</span>
                      </div>
                      <div className="w-full bg-slate-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full transition-all" 
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            {/* Productos que requieren atención */}
            <Card>
              <CardHeader>
                <CardTitle>Productos que Requieren Atención</CardTitle>
                <CardDescription>Productos con stock bajo o en mantenimiento</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {stats.lowStockProducts.slice(0, 5).map(product => (
                    <div key={product.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className={`w-3 h-3 rounded-full ${getStockStatusColor(product)}`} />
                        <div>
                          <p className="font-medium">{product.name}</p>
                          <p className="text-sm text-slate-500">{product.sku}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">{product.availableStock} disponibles</p>
                        <p className="text-sm text-slate-500">{getStockStatusText(product)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Productos */}
        <TabsContent value="products" className="space-y-6">
          {/* Filtros */}
          <Card>
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                <div className="lg:col-span-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                    <Input
                      placeholder="Buscar por nombre, SKU o marca..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                
                <Select value={selectedCategory} onValueChange={(value) => {
                  setSelectedCategory(value);
                  setSelectedSubcategory('all');
                }}>
                  <SelectTrigger>
                    <SelectValue placeholder="Categoría" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas las categorías</SelectItem>
                    {scaffoldingCategories.filter(cat => !cat.isSubcategory).map(category => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {availableSubcategories.length > 0 && (
                  <Select value={selectedSubcategory} onValueChange={setSelectedSubcategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="Subcategoría" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas las subcategorías</SelectItem>
                      {availableSubcategories.map(subcategory => (
                        <SelectItem key={subcategory.id} value={subcategory.id}>
                          {subcategory.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}

                <Select value={selectedCondition} onValueChange={setSelectedCondition}>
                  <SelectTrigger>
                    <SelectValue placeholder="Condición" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas las condiciones</SelectItem>
                    <SelectItem value="new">Nuevo</SelectItem>
                    <SelectItem value="good">Bueno</SelectItem>
                    <SelectItem value="fair">Regular</SelectItem>
                    <SelectItem value="maintenance">Mantenimiento</SelectItem>
                    <SelectItem value="damaged">Dañado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Lista de productos */}
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredProducts.map(product => (
              <Card key={product.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  {/* Imagen del producto */}
                  {product.images.length > 0 && (
                    <div className="mb-4">
                      <ImageWithFallback
                        src={product.images[0]}
                        alt={product.name}
                        className="w-full h-48 object-cover rounded-lg"
                      />
                    </div>
                  )}

                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-slate-900 mb-1">{product.name}</h3>
                      <p className="text-sm text-slate-500 mb-2">{product.sku}</p>
                      <div className="flex gap-2 mb-2">
                        <Badge variant="secondary" className="text-xs">
                          {product.categoryName}
                        </Badge>
                        {product.subcategoryName && (
                          <Badge variant="outline" className="text-xs">
                            {product.subcategoryName}
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${getStockStatusColor(product)}`} />
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Stock Total:</span>
                      <span>{product.totalStock}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Disponible:</span>
                      <span className="text-green-600">{product.availableStock}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">En Renta:</span>
                      <span className="text-blue-600">{product.rentedStock}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Precio Venta:</span>
                      <span>${product.salePrice.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Renta Mensual:</span>
                      <span>${product.monthlyRentalRate.toLocaleString()}</span>
                    </div>
                  </div>

                  <Separator className="my-4" />

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleViewProduct(product)}
                      className="flex-1"
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      Ver
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEditProduct(product)}
                      className="flex-1"
                    >
                      <Edit className="w-4 h-4 mr-1" />
                      Editar
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDeleteProduct(product.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <Card>
              <CardContent className="py-12 text-center">
                <Package className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-slate-500 mb-2">No se encontraron productos</h3>
                <p className="text-slate-400">Intenta ajustar los filtros de búsqueda</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Categorías */}
        <TabsContent value="categories" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Gestión de Categorías</CardTitle>
              <CardDescription>Categorías y subcategorías especializadas para andamios</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {scaffoldingCategories.filter(cat => !cat.isSubcategory).map(category => {
                  const subcategories = scaffoldingCategories.filter(sub => sub.parentId === category.id);
                  const categoryProducts = products.filter(p => p.categoryId === category.id);
                  
                  return (
                    <div key={category.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h4 className="text-slate-900">{category.name}</h4>
                          <p className="text-sm text-slate-500">{category.description}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-slate-600">{categoryProducts.length} productos</p>
                          <p className="text-xs text-slate-500">
                            {categoryProducts.reduce((sum, p) => sum + p.totalStock, 0)} unidades
                          </p>
                        </div>
                      </div>
                      
                      {subcategories.length > 0 && (
                        <div className="ml-4 space-y-2">
                          <h5 className="text-sm text-slate-700">Subcategorías:</h5>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                            {subcategories.map(subcategory => {
                              const subProducts = products.filter(p => p.subcategoryId === subcategory.id);
                              return (
                                <div key={subcategory.id} className="bg-slate-50 rounded p-3">
                                  <h6 className="text-sm text-slate-900">{subcategory.name}</h6>
                                  <p className="text-xs text-slate-500">{subcategory.description}</p>
                                  <p className="text-xs text-slate-600 mt-1">
                                    {subProducts.length} productos
                                  </p>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Mantenimiento */}
        <TabsContent value="maintenance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Control de Mantenimiento</CardTitle>
              <CardDescription>Gestión de mantenimiento preventivo y correctivo</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Producto</TableHead>
                    <TableHead>SKU</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>En Mantenimiento</TableHead>
                    <TableHead>Condición</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {products.filter(p => p.maintenanceStock > 0 || p.condition === 'maintenance').map(product => (
                    <TableRow key={product.id}>
                      <TableCell>{product.name}</TableCell>
                      <TableCell className="font-mono text-sm">{product.sku}</TableCell>
                      <TableCell>
                        <Badge variant={product.status === 'active' ? 'default' : 'secondary'}>
                          {product.status === 'active' ? 'Activo' : 'Inactivo'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-orange-600">
                        {product.maintenanceStock} unidades
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant={product.condition === 'new' ? 'default' : 
                                  product.condition === 'good' ? 'secondary' : 'destructive'}
                        >
                          {product.condition === 'new' ? 'Nuevo' :
                           product.condition === 'good' ? 'Bueno' :
                           product.condition === 'fair' ? 'Regular' :
                           product.condition === 'maintenance' ? 'Mantenimiento' : 'Dañado'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Settings className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              
              {products.filter(p => p.maintenanceStock > 0 || p.condition === 'maintenance').length === 0 && (
                <div className="text-center py-8">
                  <Wrench className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-500">No hay productos en mantenimiento</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Formulario de producto */}
      <Dialog open={isProductFormOpen} onOpenChange={setIsProductFormOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingProduct ? 'Editar Producto de Andamio' : 'Nuevo Producto de Andamio'}
            </DialogTitle>
            <DialogDescription>
              {editingProduct 
                ? 'Modifica la información del producto de andamio'
                : 'Completa la información para crear un nuevo producto de andamio'
              }
            </DialogDescription>
          </DialogHeader>
          <ScaffoldingProductForm
            product={editingProduct}
            categories={scaffoldingCategories}
            onSubmit={editingProduct ? handleUpdateProduct : handleCreateProduct}
            onCancel={() => {
              setIsProductFormOpen(false);
              setEditingProduct(null);
            }}
          />
        </DialogContent>
      </Dialog>

      {/* Detalles del producto */}
      <Dialog open={isProductDetailsOpen} onOpenChange={setIsProductDetailsOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Detalles del Producto</DialogTitle>
          </DialogHeader>
          {selectedProduct && (
            <ScaffoldingProductDetails
              product={selectedProduct}
              categories={scaffoldingCategories}
              onEdit={() => {
                setIsProductDetailsOpen(false);
                handleEditProduct(selectedProduct);
              }}
              onClose={() => setIsProductDetailsOpen(false)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}