import { useState } from 'react';
import { ArrowLeft, ArrowRight, Calendar, MapPin, Users, Building2 } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Service, QuotationItem } from '../types/quotation';

interface ServiceConfigurationProps {
  service: Service;
  onAddToQuotation: (item: QuotationItem) => void;
  onBack: () => void;
}

export function ServiceConfiguration({ service, onAddToQuotation, onBack }: ServiceConfigurationProps) {
  const [quantity, setQuantity] = useState<number>(1);
  const [scaffoldType, setScaffoldType] = useState<string>('');
  const [date, setDate] = useState<string>('');
  const [location, setLocation] = useState<string>('');
  const [observations, setObservations] = useState<string>('');

  const handleSubmit = () => {
    const item: QuotationItem = {
      id: Date.now().toString(),
      serviceId: service.id,
      serviceName: service.name,
      serviceType: service.type,
      quantity,
      scaffoldType: service.type !== 'curso' ? scaffoldType : undefined,
      date,
      location,
      observations
    };
    onAddToQuotation(item);
  };

  const isFormValid = quantity > 0 && date && location && 
    (service.type === 'curso' || scaffoldType);

  const getQuantityLabel = () => {
    switch (service.type) {
      case 'curso':
        return 'Número de participantes';
      case 'inspeccion':
      case 'inspeccion-liberacion':
        return 'Número de andamios';
      default:
        return 'Cantidad';
    }
  };

  const getQuantityIcon = () => {
    switch (service.type) {
      case 'curso':
        return <Users className="w-4 h-4" />;
      case 'inspeccion':
      case 'inspeccion-liberacion':
        return <Building2 className="w-4 h-4" />;
      default:
        return <Users className="w-4 h-4" />;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      {/* Header */}
      <div className="text-center mb-8">
        <Button 
          variant="ghost" 
          onClick={onBack}
          className="absolute left-4 top-8 text-slate-600 hover:text-slate-800"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Volver
        </Button>
        
        <h1 className="text-2xl font-bold text-slate-800 mb-2">
          Configura tu cotización
        </h1>
        <p className="text-slate-600">
          {service.name}
        </p>
      </div>

      {/* Progress Indicator */}
      <div className="flex items-center justify-center mb-8">
        <div className="flex items-center space-x-4">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center text-sm font-medium">✓</div>
            <span className="ml-2 text-green-600 font-medium">Selección de Servicio</span>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-400" />
          <div className="flex items-center">
            <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-medium">2</div>
            <span className="ml-2 text-blue-600 font-medium">Configuración</span>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-400" />
          <div className="flex items-center">
            <div className="w-8 h-8 bg-slate-200 text-slate-400 rounded-full flex items-center justify-center text-sm font-medium">3</div>
            <span className="ml-2 text-slate-400">Resumen</span>
          </div>
        </div>
      </div>

      {/* Configuration Form */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center">
            {getQuantityIcon()}
            <span className="ml-2">Detalles del servicio</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Quantity */}
          <div className="space-y-2">
            <Label htmlFor="quantity">{getQuantityLabel()}</Label>
            <Input
              id="quantity"
              type="number"
              min="1"
              value={quantity}
              onChange={(e) => setQuantity(parseInt(e.target.value) || 0)}
              className="w-full"
              placeholder="Ingresa la cantidad"
            />
          </div>

          {/* Scaffold Type (only for inspection services) */}
          {service.type !== 'curso' && (
            <div className="space-y-2">
              <Label htmlFor="scaffold-type">Tipo de andamio</Label>
              <Select value={scaffoldType} onValueChange={setScaffoldType}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona el tipo de andamio" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="estructural">Andamio Estructural</SelectItem>
                  <SelectItem value="colgante">Andamio Colgante</SelectItem>
                  <SelectItem value="multidireccional">Andamio Multidireccional</SelectItem>
                  <SelectItem value="tubular">Andamio Tubular</SelectItem>
                  <SelectItem value="movil">Andamio Móvil</SelectItem>
                  <SelectItem value="otro">Otro</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Date */}
          <div className="space-y-2">
            <Label htmlFor="date" className="flex items-center">
              <Calendar className="w-4 h-4 mr-2" />
              Fecha preferida para el servicio
            </Label>
            <Input
              id="date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full"
              min={new Date().toISOString().split('T')[0]}
            />
          </div>

          {/* Location */}
          <div className="space-y-2">
            <Label htmlFor="location" className="flex items-center">
              <MapPin className="w-4 h-4 mr-2" />
              Ubicación del servicio
            </Label>
            <Input
              id="location"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full"
              placeholder="Ciudad, dirección o zona del proyecto"
            />
          </div>

          {/* Observations */}
          <div className="space-y-2">
            <Label htmlFor="observations">Observaciones adicionales</Label>
            <Textarea
              id="observations"
              value={observations}
              onChange={(e) => setObservations(e.target.value)}
              className="w-full"
              placeholder="Describe detalles específicos del proyecto, horarios preferidos, o cualquier información relevante..."
              rows={4}
            />
          </div>
        </CardContent>
      </Card>

      {/* Service Summary */}
      <Card className="mb-6 bg-blue-50 border-blue-200">
        <CardContent className="p-6">
          <h3 className="font-medium text-blue-800 mb-3">Resumen del servicio</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-blue-700">Servicio:</span>
              <span className="font-medium text-blue-900">{service.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-blue-700">{getQuantityLabel()}:</span>
              <span className="font-medium text-blue-900">{quantity}</span>
            </div>
            {scaffoldType && (
              <div className="flex justify-between">
                <span className="text-blue-700">Tipo:</span>
                <span className="font-medium text-blue-900">{scaffoldType}</span>
              </div>
            )}
            {date && (
              <div className="flex justify-between">
                <span className="text-blue-700">Fecha:</span>
                <span className="font-medium text-blue-900">{new Date(date).toLocaleDateString('es-ES')}</span>
              </div>
            )}
            {location && (
              <div className="flex justify-between">
                <span className="text-blue-700">Ubicación:</span>
                <span className="font-medium text-blue-900">{location}</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Submit Button */}
      <div className="flex justify-center">
        <Button
          onClick={handleSubmit}
          disabled={!isFormValid}
          className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3"
          size="lg"
        >
          Agregar al carrito
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}