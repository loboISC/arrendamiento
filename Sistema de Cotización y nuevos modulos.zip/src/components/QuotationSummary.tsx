import { useState } from 'react';
import { ArrowLeft, ArrowRight, Trash2, Edit, Plus, User, Building, Phone, Mail, MapPin, Hash, Calendar, DollarSign, Download, Save } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { QuotationItem, ClientInfo, AdvisorInfo } from '../types/quotation';

interface QuotationSummaryProps {
  quotationItems: QuotationItem[];
  clientInfo: ClientInfo;
  quotationNumber: string;
  validUntil: string;
  advisor: AdvisorInfo;
  onRemoveItem: (itemId: string) => void;
  onUpdateClientInfo: (clientInfo: ClientInfo) => void;
  onGenerate: () => void;
  onAddMoreServices: () => void;
  onSavePDF: () => void;
  onSaveToSystem: () => void;
}

export function QuotationSummary({ 
  quotationItems, 
  clientInfo, 
  quotationNumber,
  validUntil,
  advisor,
  onRemoveItem, 
  onUpdateClientInfo, 
  onGenerate,
  onAddMoreServices,
  onSavePDF,
  onSaveToSystem
}: QuotationSummaryProps) {
  const [formData, setFormData] = useState<ClientInfo>(clientInfo);
  const [notes, setNotes] = useState<string>('');

  const handleInputChange = (field: keyof ClientInfo, value: string) => {
    const updatedData = { ...formData, [field]: value };
    setFormData(updatedData);
    onUpdateClientInfo(updatedData);
  };

  const isFormValid = formData.name && formData.company && formData.phone && formData.email;

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('es-ES', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const calculateTotal = () => {
    return quotationItems.reduce((total, item) => total + (item.totalPrice || 0), 0);
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-semibold text-slate-800 mb-2">Resumen de Cotización</h1>
            <p className="text-slate-600">
              Revisa los servicios y completa la información del cliente antes de generar.
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <Button variant="outline" onClick={onSavePDF} className="text-blue-600">
              <Download className="w-4 h-4 mr-2" />
              Guardar PDF
            </Button>
            <Button variant="outline" onClick={onSaveToSystem} className="text-green-600">
              <Save className="w-4 h-4 mr-2" />
              Guardar en Sistema
            </Button>
          </div>
        </div>

        {/* Cotización Info */}
        <Card className="mb-6 bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <p className="text-blue-600 mb-1">Asesor</p>
                <p className="font-medium text-blue-800">{advisor.name}</p>
              </div>
              <div>
                <p className="text-blue-600 mb-1">Departamento</p>
                <p className="font-medium text-blue-800">{advisor.department}</p>
              </div>
              <div>
                <p className="text-blue-600 mb-1">Válida hasta</p>
                <p className="font-medium text-blue-800">{formatDate(validUntil)}</p>
              </div>
              <div>
                <p className="text-blue-600 mb-1">Servicios</p>
                <p className="font-medium text-blue-800">{quotationItems.length} item(s)</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Progress Indicator */}
      <div className="flex items-center justify-center mb-8">
        <div className="flex items-center space-x-4">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center text-sm font-medium">✓</div>
            <span className="ml-2 text-green-600 font-medium">Selección de Servicios</span>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-400" />
          <div className="flex items-center">
            <div className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center text-sm font-medium">✓</div>
            <span className="ml-2 text-green-600 font-medium">Configuración</span>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-400" />
          <div className="flex items-center">
            <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-medium">3</div>
            <span className="ml-2 text-blue-600 font-medium">Generar Cotización</span>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Services Summary */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg">Servicios Cotizados</CardTitle>
              <Button
                variant="outline"
                size="sm"
                onClick={onAddMoreServices}
                className="text-blue-600 border-blue-200 hover:bg-blue-50"
              >
                <Plus className="w-4 h-4 mr-2" />
                Agregar más
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {quotationItems.length === 0 ? (
                <div className="text-center py-8 text-slate-500">
                  <p>No hay servicios en esta cotización</p>
                  <Button
                    variant="ghost"
                    onClick={onAddMoreServices}
                    className="mt-2 text-blue-600"
                  >
                    Agregar servicios
                  </Button>
                </div>
              ) : (
                <>
                  {quotationItems.map((item, index) => (
                    <Card key={item.id} className="border-l-4 border-l-blue-500">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="font-medium text-slate-800">
                                {item.serviceName}
                              </h4>
                              <span className="text-sm text-slate-500">#{index + 1}</span>
                            </div>
                            <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm text-slate-600">
                              <div className="flex justify-between">
                                <span>Cantidad:</span>
                                <span className="font-medium">{item.quantity}</span>
                              </div>
                              {item.scaffoldType && (
                                <div className="flex justify-between">
                                  <span>Tipo:</span>
                                  <span className="font-medium">{item.scaffoldType}</span>
                                </div>
                              )}
                              <div className="flex justify-between">
                                <span>Fecha:</span>
                                <span className="font-medium">{formatDate(item.date)}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Ubicación:</span>
                                <span className="font-medium">{item.location}</span>
                              </div>
                              {item.unitPrice && (
                                <div className="flex justify-between">
                                  <span>Precio unitario:</span>
                                  <span className="font-medium">${item.unitPrice.toLocaleString()}</span>
                                </div>
                              )}
                              {item.totalPrice && (
                                <div className="flex justify-between">
                                  <span>Total:</span>
                                  <span className="font-medium text-green-600">${item.totalPrice.toLocaleString()}</span>
                                </div>
                              )}
                            </div>
                            {item.observations && (
                              <div className="mt-3 pt-3 border-t">
                                <span className="text-xs text-slate-500">Observaciones:</span>
                                <p className="text-sm mt-1">{item.observations}</p>
                              </div>
                            )}
                          </div>
                          <div className="flex flex-col ml-4 space-y-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-slate-500 hover:text-slate-700 p-1"
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => onRemoveItem(item.id)}
                              className="text-red-500 hover:text-red-700 p-1"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  
                  {/* Total */}
                  {quotationItems.some(item => item.totalPrice) && (
                    <Card className="bg-green-50 border-green-200">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-center">
                          <span className="font-medium text-green-800">Total Cotización:</span>
                          <span className="text-xl font-semibold text-green-900">
                            ${calculateTotal().toLocaleString()}
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Client Information */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <Building className="w-5 h-5 mr-2" />
                Información del Cliente
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="flex items-center">
                  <User className="w-4 h-4 mr-2" />
                  Nombre del contacto *
                </Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  placeholder="Nombre completo del contacto"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="company" className="flex items-center">
                  <Building className="w-4 h-4 mr-2" />
                  Empresa *
                </Label>
                <Input
                  id="company"
                  value={formData.company}
                  onChange={(e) => handleInputChange('company', e.target.value)}
                  placeholder="Nombre de la empresa"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone" className="flex items-center">
                  <Phone className="w-4 h-4 mr-2" />
                  Teléfono *
                </Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  placeholder="+57 (1) 234-5678"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="flex items-center">
                  <Mail className="w-4 h-4 mr-2" />
                  Correo electrónico *
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  placeholder="contacto@empresa.com"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="address" className="flex items-center">
                  <MapPin className="w-4 h-4 mr-2" />
                  Dirección
                </Label>
                <Input
                  id="address"
                  value={formData.address}
                  onChange={(e) => handleInputChange('address', e.target.value)}
                  placeholder="Dirección completa (opcional)"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="taxId" className="flex items-center">
                  <Hash className="w-4 h-4 mr-2" />
                  NIT/Identificación fiscal
                </Label>
                <Input
                  id="taxId"
                  value={formData.taxId}
                  onChange={(e) => handleInputChange('taxId', e.target.value)}
                  placeholder="000.000.000-0 (opcional)"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Notas internas</Label>
                <Textarea
                  id="notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Notas para el seguimiento interno..."
                  rows={3}
                />
              </div>

              <div className="pt-4 space-y-3">
                <Button
                  onClick={onGenerate}
                  disabled={!isFormValid || quotationItems.length === 0}
                  className="w-full bg-green-600 hover:bg-green-700 text-white py-3"
                  size="lg"
                >
                  <DollarSign className="w-4 h-4 mr-2" />
                  Generar Cotización
                </Button>

                {(!isFormValid || quotationItems.length === 0) && (
                  <p className="text-sm text-red-500 text-center">
                    {quotationItems.length === 0 
                      ? "Agrega al menos un servicio para continuar"
                      : "Completa los campos obligatorios (*)"
                    }
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}