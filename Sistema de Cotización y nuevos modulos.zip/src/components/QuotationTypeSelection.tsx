import { ShoppingCart, Calendar, Wrench, ArrowRight, TrendingUp, Clock, Users } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { QuotationType } from '../types/rental';

interface QuotationTypeSelectionProps {
  onTypeSelect: (type: QuotationType) => void;
  stats: {
    activeRentals: number;
    monthlySales: number;
    pendingServices: number;
  };
}

export function QuotationTypeSelection({ onTypeSelect, stats }: QuotationTypeSelectionProps) {
  const quotationTypes = [
    {
      type: 'rental' as QuotationType,
      title: 'Renta',
      description: 'Alquiler de equipos por tiempo determinado',
      icon: Calendar,
      color: 'bg-blue-500',
      hoverColor: 'hover:bg-blue-600',
      borderColor: 'border-blue-200',
      textColor: 'text-blue-700',
      bgColor: 'bg-blue-50',
      features: ['Periodo flexible', 'Entrega incluida', 'Mantenimiento']
    },
    {
      type: 'sale' as QuotationType,
      title: 'Venta',
      description: 'Compra directa de equipos',
      icon: ShoppingCart,
      color: 'bg-green-500',
      hoverColor: 'hover:bg-green-600',
      borderColor: 'border-green-200',
      textColor: 'text-green-700',
      bgColor: 'bg-green-50',
      features: ['Propiedad total', 'Garantía incluida', 'Financiamiento']
    },
    {
      type: 'service' as QuotationType,
      title: 'Servicio',
      description: 'Servicios especializados',
      icon: Wrench,
      color: 'bg-orange-500',
      hoverColor: 'hover:bg-orange-600',
      borderColor: 'border-orange-200',
      textColor: 'text-orange-700',
      bgColor: 'bg-orange-50',
      features: ['Capacitación', 'Inspección', 'Certificación']
    }
  ];

  const getStatValue = (type: QuotationType) => {
    switch (type) {
      case 'rental':
        return stats.activeRentals;
      case 'sale':
        return stats.monthlySales;
      case 'service':
        return stats.pendingServices;
      default:
        return 0;
    }
  };

  const getStatLabel = (type: QuotationType) => {
    switch (type) {
      case 'rental':
        return 'Activas';
      case 'sale':
        return 'Este mes';
      case 'service':
        return 'Pendientes';
      default:
        return '';
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-3xl font-semibold text-slate-800 mb-4">Nueva Cotización</h1>
        <p className="text-lg text-slate-600 max-w-2xl mx-auto">
          Sigue los pasos para crear tu cotización
        </p>
        
        {/* Progress dots */}
        <div className="flex items-center justify-center mt-8 space-x-2">
          <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
          {Array.from({ length: 8 }, (_, i) => (
            <div key={i} className="w-3 h-3 bg-slate-300 rounded-full"></div>
          ))}
        </div>
      </div>

      {/* Main Step */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center bg-blue-50 text-blue-700 px-4 py-2 rounded-full mb-4">
          <span className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm mr-3">1</span>
          Paso 1: Selección de Tipo
        </div>
        <h2 className="text-xl text-slate-800 mb-2">¿Qué tipo de cotización deseas crear?</h2>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <Card className="bg-gradient-to-r from-blue-50 to-blue-100 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-600 text-sm">Rentas Activas</p>
                <p className="text-2xl text-blue-800">{stats.activeRentals}</p>
              </div>
              <Calendar className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-r from-green-50 to-green-100 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-600 text-sm">Ventas del Mes</p>
                <p className="text-2xl text-green-800">{stats.monthlySales}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-r from-orange-50 to-orange-100 border-orange-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-600 text-sm">Servicios Pendientes</p>
                <p className="text-2xl text-orange-800">{stats.pendingServices}</p>
              </div>
              <Wrench className="w-8 h-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Type Selection Cards */}
      <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
        {quotationTypes.map((type) => {
          const IconComponent = type.icon;
          const statValue = getStatValue(type.type);
          const statLabel = getStatLabel(type.type);
          
          return (
            <Card 
              key={type.type} 
              className={`cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1 ${type.borderColor} group`}
              onClick={() => onTypeSelect(type.type)}
            >
              <CardHeader className="text-center pb-4">
                <div className={`w-16 h-16 ${type.color} rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform`}>
                  <IconComponent className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl text-slate-800">{type.title}</CardTitle>
                <p className="text-slate-600 text-sm">{type.description}</p>
              </CardHeader>
              
              <CardContent className="pt-0">
                {/* Features */}
                <div className="space-y-2 mb-6">
                  {type.features.map((feature, index) => (
                    <div key={index} className="flex items-center text-sm text-slate-600">
                      <div className="w-1.5 h-1.5 bg-slate-400 rounded-full mr-3"></div>
                      {feature}
                    </div>
                  ))}
                </div>

                {/* Stats */}
                <div className={`${type.bgColor} ${type.borderColor} border rounded-lg p-3 mb-4`}>
                  <div className="flex items-center justify-between">
                    <span className={`text-sm ${type.textColor}`}>{statLabel}</span>
                    <Badge className={`${type.textColor} ${type.bgColor} border-0`}>
                      {statValue}
                    </Badge>
                  </div>
                </div>

                {/* Action Button */}
                <Button 
                  className={`w-full ${type.color} ${type.hoverColor} text-white group-hover:shadow-md transition-all`}
                  onClick={(e) => {
                    e.stopPropagation();
                    onTypeSelect(type.type);
                  }}
                >
                  Seleccionar {type.title}
                  <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Additional Info */}
      <div className="mt-12 text-center">
        <Card className="bg-slate-50 border-slate-200 max-w-4xl mx-auto">
          <CardContent className="p-6">
            <h3 className="text-lg text-slate-800 mb-4">¿Necesitas ayuda para decidir?</h3>
            <div className="grid md:grid-cols-3 gap-6 text-sm">
              <div className="flex items-start space-x-3">
                <Clock className="w-5 h-5 text-blue-500 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium text-slate-700">Renta</p>
                  <p className="text-slate-600">Ideal para proyectos temporales o cuando necesitas equipos especializados por periodos específicos.</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <ShoppingCart className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium text-slate-700">Venta</p>
                  <p className="text-slate-600">Perfecta cuando necesitas equipos de forma permanente y quieres la propiedad total del activo.</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Users className="w-5 h-5 text-orange-500 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium text-slate-700">Servicio</p>
                  <p className="text-slate-600">Para capacitaciones, inspecciones y servicios especializados que complementan tus operaciones.</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}