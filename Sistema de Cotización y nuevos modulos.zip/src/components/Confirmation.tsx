import { CheckCircle, Download, Mail, Share2, ArrowLeft, Plus, FileText, Clock, User, CreditCard, ArrowRight, FileSignature } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ClientInfo, AdvisorInfo } from '../types/quotation';
import { QuotationType } from '../types/rental';

interface ConfirmationProps {
  quotationNumber: string;
  clientInfo: ClientInfo;
  advisor: AdvisorInfo;
  onStartNew: () => void;
  onBackToSummary: () => void;
  onGoToInvoice: () => void;
  onSavePDF: () => void;
  onSaveToSystem: () => void;
  quotationType?: QuotationType;
  onGoToContract?: () => void;
}

export function Confirmation({ 
  quotationNumber, 
  clientInfo, 
  advisor, 
  onStartNew, 
  onBackToSummary, 
  onGoToInvoice,
  onSavePDF,
  onSaveToSystem,
  quotationType,
  onGoToContract
}: ConfirmationProps) {
  const handleSendEmail = () => {
    // En un sistema real, esto abriría un modal para enviar por email
    console.log('Enviando cotización por email...');
  };

  const handleCopyLink = () => {
    // En un sistema real, esto copiaría un enlace para compartir
    navigator.clipboard.writeText(`https://sistema.tecnoseguridadpro.com/cotizacion/${quotationNumber}`);
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      {/* Success Header */}
      <div className="text-center mb-8">
        <div className="flex justify-center mb-6">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
            <CheckCircle className="w-12 h-12 text-green-600" />
          </div>
        </div>
        <h1 className="text-3xl font-semibold text-slate-800 mb-4">
          ¡Cotización Generada Exitosamente!
        </h1>
        <p className="text-lg text-slate-600 max-w-2xl mx-auto">
          La cotización <span className="font-mono font-medium">{quotationNumber}</span> ha sido creada 
          y está lista para ser enviada al cliente.
        </p>
      </div>

      {/* Quick Actions */}
      <div className={`grid ${quotationType === 'rental' ? 'md:grid-cols-5' : 'md:grid-cols-4'} gap-4 mb-8`}>
        <Button 
          onClick={onSavePDF}
          className="bg-blue-600 hover:bg-blue-700 text-white h-auto py-4"
        >
          <Download className="w-5 h-5 mr-2" />
          <div className="text-left">
            <div>Descargar PDF</div>
            <div className="text-xs opacity-90">Formato profesional</div>
          </div>
        </Button>
        
        <Button 
          onClick={handleSendEmail}
          variant="outline"
          className="h-auto py-4 border-blue-200 text-blue-700 hover:bg-blue-50"
        >
          <Mail className="w-5 h-5 mr-2" />
          <div className="text-left">
            <div>Enviar por Email</div>
            <div className="text-xs opacity-70">Al cliente directamente</div>
          </div>
        </Button>
        
        <Button 
          onClick={handleCopyLink}
          variant="outline"
          className="h-auto py-4"
        >
          <Share2 className="w-5 h-5 mr-2" />
          <div className="text-left">
            <div>Compartir Enlace</div>
            <div className="text-xs opacity-70">Copia al portapapeles</div>
          </div>
        </Button>

        {quotationType === 'rental' && onGoToContract && (
          <Button 
            onClick={onGoToContract}
            className="bg-orange-600 hover:bg-orange-700 text-white h-auto py-4"
          >
            <FileSignature className="w-5 h-5 mr-2" />
            <div className="text-left">
              <div>Generar Contrato</div>
              <div className="text-xs opacity-90">Para renta de equipos</div>
            </div>
          </Button>
        )}

        <Button 
          onClick={onGoToInvoice}
          className="bg-purple-600 hover:bg-purple-700 text-white h-auto py-4"
        >
          <CreditCard className="w-5 h-5 mr-2" />
          <div className="text-left">
            <div>Crear Factura</div>
            <div className="text-xs opacity-90">Si está aprobada</div>
          </div>
        </Button>
      </div>

      {/* Progress Indicator - All Complete */}
      <div className="flex items-center justify-center mb-8">
        <div className="flex items-center space-x-4">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center text-sm font-medium">✓</div>
            <span className="ml-2 text-green-600 font-medium">Selección de Servicios</span>
          </div>
          <ArrowRight className="w-4 h-4 text-green-500" />
          <div className="flex items-center">
            <div className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center text-sm font-medium">✓</div>
            <span className="ml-2 text-green-600 font-medium">Configuración</span>
          </div>
          <ArrowRight className="w-4 h-4 text-green-500" />
          <div className="flex items-center">
            <div className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center text-sm font-medium">✓</div>
            <span className="ml-2 text-green-600 font-medium">Cotización Generada</span>
          </div>
        </div>
      </div>

      {/* Cotización Details */}
      <div className="grid lg:grid-cols-3 gap-8 mb-8">
        {/* Cotización Info */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-lg">
              <FileText className="w-5 h-5 mr-2" />
              Detalles de la Cotización
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-slate-600">Número:</span>
              <span className="font-mono font-medium">{quotationNumber}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-600">Estado:</span>
              <Badge className="bg-green-100 text-green-800 border-green-200">
                Generada
              </Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-600">Fecha:</span>
              <span className="font-medium">{new Date().toLocaleDateString('es-ES')}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-600">Válida hasta:</span>
              <span className="font-medium">
                {new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString('es-ES')}
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Client Info */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-lg">
              <User className="w-5 h-5 mr-2" />
              Información del Cliente
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <p className="text-slate-600 text-sm">Contacto</p>
              <p className="font-medium">{clientInfo.name}</p>
            </div>
            <div>
              <p className="text-slate-600 text-sm">Empresa</p>
              <p className="font-medium">{clientInfo.company}</p>
            </div>
            <div>
              <p className="text-slate-600 text-sm">Email</p>
              <p className="font-medium text-blue-600">{clientInfo.email}</p>
            </div>
            <div>
              <p className="text-slate-600 text-sm">Teléfono</p>
              <p className="font-medium">{clientInfo.phone}</p>
            </div>
          </CardContent>
        </Card>

        {/* Advisor Info */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-lg">
              <User className="w-5 h-5 mr-2" />
              Asesor Responsable
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <p className="text-slate-600 text-sm">Nombre</p>
              <p className="font-medium">{advisor.name}</p>
            </div>
            <div>
              <p className="text-slate-600 text-sm">Departamento</p>
              <p className="font-medium">{advisor.department}</p>
            </div>
            <div>
              <p className="text-slate-600 text-sm">Email</p>
              <p className="font-medium text-blue-600">{advisor.email}</p>
            </div>
            <div>
              <p className="text-slate-600 text-sm">ID Asesor</p>
              <p className="font-mono font-medium">{advisor.id}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Next Steps */}
      <Card className="mb-8 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
        <CardContent className="p-8">
          <h2 className="text-xl font-semibold text-slate-800 mb-6 text-center">
            Próximos Pasos Recomendados
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Mail className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="font-medium text-slate-800 mb-2">Envío al Cliente</h3>
              <p className="text-sm text-slate-600">
                Envía la cotización por email o compártela directamente con el cliente
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-6 h-6 text-orange-600" />
              </div>
              <h3 className="font-medium text-slate-800 mb-2">Seguimiento</h3>
              <p className="text-sm text-slate-600">
                Programa un recordatorio para hacer seguimiento en 3-5 días hábiles
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                {quotationType === 'rental' ? <FileSignature className="w-6 h-6 text-purple-600" /> : <CreditCard className="w-6 h-6 text-purple-600" />}
              </div>
              <h3 className="font-medium text-slate-800 mb-2">
                {quotationType === 'rental' ? 'Contrato de Renta' : 'Facturación'}
              </h3>
              <p className="text-sm text-slate-600">
                {quotationType === 'rental' 
                  ? 'Si es para renta, genera el contrato con garantías y términos'
                  : 'Una vez aprobada, puedes generar la factura directamente'
                }
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4 justify-center">
        <Button
          variant="outline"
          onClick={onBackToSummary}
          className="border-slate-300 text-slate-700 hover:bg-slate-50"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Volver al Resumen
        </Button>
        <Button
          onClick={onStartNew}
          className="bg-blue-600 hover:bg-blue-700 text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nueva Cotización
        </Button>
      </div>

      {/* Footer */}
      <div className="text-center mt-12 pt-8 border-t border-slate-200">
        <p className="text-sm text-slate-500">
          Sistema de Cotizaciones • TecnoSeguridad Pro • Versión 2.1
        </p>
      </div>
    </div>
  );
}