import { useState, useMemo } from 'react';
import { Plus, Search, Users, Star, Phone, Mail, Building, CreditCard, History, MessageSquare, Filter, Eye, Edit, Trash2, TrendingUp } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Progress } from './ui/progress';
import { Customer, CustomerTransaction, CustomerSatisfactionSurvey } from '../types/rental';
import { CustomerForm } from './CustomerForm';
import { CustomerDetails } from './CustomerDetails';
import { SatisfactionSurvey } from './SatisfactionSurvey';

interface CustomerManagementProps {
  onBack: () => void;
}

export function CustomerManagement({ onBack }: CustomerManagementProps) {
  // Datos mock de clientes
  const [customers, setCustomers] = useState<Customer[]>([
    {
      id: 'CUST-001',
      personalInfo: {
        name: 'Juan Carlos Rodríguez',
        company: 'Constructora Rodríguez S.A.S.',
        phone: '+57 300 123 4567',
        email: 'juan.rodriguez@constructora.com',
        address: 'Cra 15 #85-32, Bogotá',
        taxId: '900123456-1'
      },
      rating: {
        score: 4.5,
        paymentReliability: 5,
        communicationQuality: 4,
        equipmentCare: 4,
        overallSatisfaction: 5,
        lastReviewDate: '2024-01-15',
        reviewNotes: 'Excelente cliente, siempre paga a tiempo y cuida bien los equipos.'
      },
      segment: 'medium_business',
      creditLimit: 10000000,
      currentDebt: 2500000,
      paymentTerms: 30,
      paymentMethod: 'transfer',
      registrationDate: '2023-03-15',
      lastActivityDate: '2024-01-20',
      totalTransactions: 25,
      totalSpent: 45000000,
      status: 'active',
      notes: 'Cliente preferencial con historial excelente'
    },
    {
      id: 'CUST-002',
      personalInfo: {
        name: 'María Elena González',
        company: 'Reformas González',
        phone: '+57 310 987 6543',
        email: 'maria@reformas.com',
        address: 'Calle 72 #11-45, Medellín',
        taxId: '43123456-7'
      },
      rating: {
        score: 3.8,
        paymentReliability: 3,
        communicationQuality: 4,
        equipmentCare: 4,
        overallSatisfaction: 4,
        lastReviewDate: '2024-01-10',
        reviewNotes: 'Cliente confiable pero ocasionalmente se retrasa en pagos.'
      },
      segment: 'small_business',
      creditLimit: 5000000,
      currentDebt: 1200000,
      paymentTerms: 15,
      paymentMethod: 'check',
      registrationDate: '2023-06-20',
      lastActivityDate: '2024-01-18',
      totalTransactions: 18,
      totalSpent: 22000000,
      status: 'active',
      notes: 'Requiere seguimiento en pagos'
    },
    {
      id: 'CUST-003',
      personalInfo: {
        name: 'Constructora Magna Ltda.',
        company: 'Constructora Magna Ltda.',
        phone: '+57 320 555 7890',
        email: 'proyectos@magna.com',
        address: 'Av 19 #120-30, Bogotá',
        taxId: '800654321-9'
      },
      rating: {
        score: 5.0,
        paymentReliability: 5,
        communicationQuality: 5,
        equipmentCare: 5,
        overallSatisfaction: 5,
        lastReviewDate: '2024-01-22',
        reviewNotes: 'Cliente premium, proyectos grandes, excelente relación comercial.'
      },
      segment: 'enterprise',
      creditLimit: 50000000,
      currentDebt: 8500000,
      paymentTerms: 45,
      paymentMethod: 'transfer',
      registrationDate: '2022-09-10',
      lastActivityDate: '2024-01-22',
      totalTransactions: 67,
      totalSpent: 180000000,
      status: 'active',
      notes: 'Cliente VIP - máxima prioridad'
    }
  ]);

  // Transacciones mock
  const mockTransactions: CustomerTransaction[] = [
    {
      id: 'TXN-001',
      customerId: 'CUST-001',
      type: 'rental',
      referenceNumber: 'CON-2024-001234',
      description: 'Renta de andamios estructurales - Proyecto Torres del Norte',
      amount: 2500000,
      status: 'completed',
      transactionDate: '2024-01-15',
      completedDate: '2024-01-20',
      items: [
        { productId: 'PROD-001', productName: 'Andamio Estructural Modular', quantity: 5, unitPrice: 300000 }
      ],
      advisorId: 'ADV001',
      advisorName: 'María González'
    },
    {
      id: 'TXN-002',
      customerId: 'CUST-001',
      type: 'payment',
      referenceNumber: 'PAY-2024-001234',
      description: 'Pago contrato CON-2024-001234',
      amount: 2500000,
      status: 'completed',
      transactionDate: '2024-01-20',
      completedDate: '2024-01-20',
      items: [],
      advisorId: 'ADV001',
      advisorName: 'María González'
    }
  ];

  // Estados del componente
  const [activeTab, setActiveTab] = useState('customers');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSegment, setSelectedSegment] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [isCustomerFormOpen, setIsCustomerFormOpen] = useState(false);
  const [isCustomerDetailsOpen, setIsCustomerDetailsOpen] = useState(false);
  const [isSurveyOpen, setIsSurveyOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);

  // Filtrar clientes
  const filteredCustomers = useMemo(() => {
    return customers.filter(customer => {
      const matchesSearch = customer.personalInfo.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           customer.personalInfo.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           customer.personalInfo.email.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesSegment = selectedSegment === 'all' || customer.segment === selectedSegment;
      const matchesStatus = selectedStatus === 'all' || customer.status === selectedStatus;
      
      return matchesSearch && matchesSegment && matchesStatus;
    });
  }, [customers, searchTerm, selectedSegment, selectedStatus]);

  // Estadísticas de clientes
  const customerStats = useMemo(() => {
    const totalCustomers = customers.length;
    const activeCustomers = customers.filter(c => c.status === 'active').length;
    const averageRating = customers.reduce((sum, c) => sum + c.rating.score, 0) / customers.length;
    const totalRevenue = customers.reduce((sum, c) => sum + c.totalSpent, 0);
    const highValueCustomers = customers.filter(c => c.totalSpent > 50000000).length;
    
    return {
      totalCustomers,
      activeCustomers,
      averageRating,
      totalRevenue,
      highValueCustomers
    };
  }, [customers]);

  // Handlers CRUD
  const handleCreateCustomer = (customerData: Omit<Customer, 'id' | 'registrationDate' | 'lastActivityDate' | 'totalTransactions' | 'totalSpent'>) => {
    const newCustomer: Customer = {
      ...customerData,
      id: `CUST-${String(Date.now()).slice(-6)}`,
      registrationDate: new Date().toISOString().split('T')[0],
      lastActivityDate: new Date().toISOString().split('T')[0],
      totalTransactions: 0,
      totalSpent: 0
    };
    setCustomers([...customers, newCustomer]);
    setIsCustomerFormOpen(false);
  };

  const handleUpdateCustomer = (customerData: Omit<Customer, 'id' | 'registrationDate' | 'lastActivityDate' | 'totalTransactions' | 'totalSpent'>) => {
    if (!editingCustomer) return;
    
    const updatedCustomer: Customer = {
      ...customerData,
      id: editingCustomer.id,
      registrationDate: editingCustomer.registrationDate,
      lastActivityDate: new Date().toISOString().split('T')[0],
      totalTransactions: editingCustomer.totalTransactions,
      totalSpent: editingCustomer.totalSpent
    };
    
    setCustomers(customers.map(c => c.id === editingCustomer.id ? updatedCustomer : c));
    setEditingCustomer(null);
    setIsCustomerFormOpen(false);
  };

  const handleDeleteCustomer = (customerId: string) => {
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return;

    const confirmMessage = `¿Estás seguro de que deseas eliminar al cliente "${customer.personalInfo.name}"?\n\nEsta acción no se puede deshacer.`;
    
    if (confirm(confirmMessage)) {
      setCustomers(customers.filter(c => c.id !== customerId));
    }
  };

  const handleViewCustomer = (customer: Customer) => {
    setSelectedCustomer(customer);
    setIsCustomerDetailsOpen(true);
  };

  const handleEditCustomer = (customer: Customer) => {
    setEditingCustomer(customer);
    setIsCustomerFormOpen(true);
  };

  const handleCreateSurvey = (customer: Customer) => {
    setSelectedCustomer(customer);
    setIsSurveyOpen(true);
  };

  // Utilidades
  const getSegmentText = (segment: string) => {
    switch (segment) {
      case 'individual': return 'Individual';
      case 'small_business': return 'Pequeña Empresa';
      case 'medium_business': return 'Mediana Empresa';
      case 'enterprise': return 'Gran Empresa';
      case 'government': return 'Gobierno';
      default: return segment;
    }
  };

  const getSegmentColor = (segment: string) => {
    switch (segment) {
      case 'individual': return 'bg-gray-100 text-gray-800';
      case 'small_business': return 'bg-blue-100 text-blue-800';
      case 'medium_business': return 'bg-green-100 text-green-800';
      case 'enterprise': return 'bg-purple-100 text-purple-800';
      case 'government': return 'bg-indigo-100 text-indigo-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'inactive': return 'bg-gray-100 text-gray-800';
      case 'blacklisted': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getRatingColor = (rating: number) => {
    if (rating >= 4.5) return 'text-green-600';
    if (rating >= 3.5) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl text-slate-900">Gestión de Clientes</h1>
          <p className="text-slate-600 mt-2">Administra clientes, historiales y satisfacción</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={onBack}>
            Volver al Sistema
          </Button>
          <Button 
            onClick={() => {
              setEditingCustomer(null);
              setIsCustomerFormOpen(true);
            }}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nuevo Cliente
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="dashboard" className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Dashboard
          </TabsTrigger>
          <TabsTrigger value="customers" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            Clientes
          </TabsTrigger>
          <TabsTrigger value="transactions" className="flex items-center gap-2">
            <History className="w-4 h-4" />
            Transacciones
          </TabsTrigger>
          <TabsTrigger value="satisfaction" className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4" />
            Satisfacción
          </TabsTrigger>
        </TabsList>

        {/* Dashboard */}
        <TabsContent value="dashboard" className="space-y-6">
          {/* Estadísticas principales */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-slate-600">Total Clientes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-slate-900">{customerStats.totalCustomers}</div>
                <p className="text-sm text-slate-500 mt-1">Registrados</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-slate-600">Clientes Activos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-green-600">{customerStats.activeCustomers}</div>
                <p className="text-sm text-slate-500 mt-1">Con actividad reciente</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-slate-600">Calificación Promedio</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-yellow-600 flex items-center">
                  {customerStats.averageRating.toFixed(1)}
                  <Star className="w-6 h-6 ml-1 fill-current" />
                </div>
                <p className="text-sm text-slate-500 mt-1">De 5.0 estrellas</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-slate-600">Ingresos Totales</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-blue-600">${(customerStats.totalRevenue / 1000000).toFixed(0)}M</div>
                <p className="text-sm text-slate-500 mt-1">Facturación acumulada</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-slate-600">Clientes VIP</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-purple-600">{customerStats.highValueCustomers}</div>
                <p className="text-sm text-slate-500 mt-1">Alto valor</p>
              </CardContent>
            </Card>
          </div>

          {/* Distribución por segmento */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Distribución por Segmento</CardTitle>
                <CardDescription>Clientes agrupados por tipo de negocio</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {['individual', 'small_business', 'medium_business', 'enterprise', 'government'].map(segment => {
                  const segmentCustomers = customers.filter(c => c.segment === segment);
                  const percentage = customers.length > 0 ? (segmentCustomers.length / customers.length) * 100 : 0;
                  
                  return (
                    <div key={segment} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">{getSegmentText(segment)}</span>
                        <span className="text-sm text-slate-500">{segmentCustomers.length} clientes</span>
                      </div>
                      <Progress value={percentage} className="h-2" />
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            {/* Top clientes */}
            <Card>
              <CardHeader>
                <CardTitle>Top Clientes por Facturación</CardTitle>
                <CardDescription>Clientes con mayor volumen de negocio</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {customers
                    .sort((a, b) => b.totalSpent - a.totalSpent)
                    .slice(0, 5)
                    .map((customer, index) => (
                    <div key={customer.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-semibold ${index === 0 ? 'bg-yellow-500' : index === 1 ? 'bg-gray-400' : index === 2 ? 'bg-orange-500' : 'bg-slate-400'}`}>
                          {index + 1}
                        </div>
                        <div>
                          <p className="font-medium">{customer.personalInfo.name}</p>
                          <p className="text-sm text-slate-500">{customer.personalInfo.company}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">${(customer.totalSpent / 1000000).toFixed(1)}M</p>
                        <div className="flex items-center">
                          <Star className={`w-4 h-4 fill-current ${getRatingColor(customer.rating.score)}`} />
                          <span className="text-sm ml-1">{customer.rating.score}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Clientes */}
        <TabsContent value="customers" className="space-y-6">
          {/* Filtros */}
          <Card>
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="md:col-span-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                    <Input
                      placeholder="Buscar por nombre, empresa o email..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                
                <Select value={selectedSegment} onValueChange={setSelectedSegment}>
                  <SelectTrigger>
                    <SelectValue placeholder="Segmento" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los segmentos</SelectItem>
                    <SelectItem value="individual">Individual</SelectItem>
                    <SelectItem value="small_business">Pequeña Empresa</SelectItem>
                    <SelectItem value="medium_business">Mediana Empresa</SelectItem>
                    <SelectItem value="enterprise">Gran Empresa</SelectItem>
                    <SelectItem value="government">Gobierno</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger>
                    <SelectValue placeholder="Estado" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los estados</SelectItem>
                    <SelectItem value="active">Activo</SelectItem>
                    <SelectItem value="inactive">Inactivo</SelectItem>
                    <SelectItem value="blacklisted">Lista Negra</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Lista de clientes */}
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredCustomers.map(customer => (
              <Card key={customer.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-slate-900 mb-1">{customer.personalInfo.name}</h3>
                      <p className="text-sm text-slate-500 mb-2">{customer.personalInfo.company}</p>
                      <div className="flex gap-2 mb-3">
                        <Badge className={getSegmentColor(customer.segment)}>
                          {getSegmentText(customer.segment)}
                        </Badge>
                        <Badge className={getStatusColor(customer.status)}>
                          {customer.status === 'active' ? 'Activo' : 
                           customer.status === 'inactive' ? 'Inactivo' : 'Lista Negra'}
                        </Badge>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <Star className={`w-4 h-4 fill-current ${getRatingColor(customer.rating.score)}`} />
                      <span className="ml-1 text-sm font-medium">{customer.rating.score}</span>
                    </div>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center gap-2 text-sm">
                      <Phone className="w-4 h-4 text-slate-400" />
                      <span>{customer.personalInfo.phone}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Mail className="w-4 h-4 text-slate-400" />
                      <span className="truncate">{customer.personalInfo.email}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <CreditCard className="w-4 h-4 text-slate-400" />
                      <span>${(customer.totalSpent / 1000000).toFixed(1)}M facturado</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center text-xs mb-4">
                    <div>
                      <p className="text-slate-500">Transacciones</p>
                      <p className="font-semibold">{customer.totalTransactions}</p>
                    </div>
                    <div>
                      <p className="text-slate-500">Crédito</p>
                      <p className="font-semibold">${(customer.creditLimit / 1000000).toFixed(0)}M</p>
                    </div>
                    <div>
                      <p className="text-slate-500">Deuda</p>
                      <p className="font-semibold text-orange-600">${(customer.currentDebt / 1000000).toFixed(1)}M</p>
                    </div>
                  </div>

                  <div className="flex gap-1">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleViewCustomer(customer)}
                      className="flex-1"
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      Ver
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEditCustomer(customer)}
                      className="flex-1"
                    >
                      <Edit className="w-4 h-4 mr-1" />
                      Editar
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleCreateSurvey(customer)}
                    >
                      <MessageSquare className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDeleteCustomer(customer.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredCustomers.length === 0 && (
            <Card>
              <CardContent className="py-12 text-center">
                <Users className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-slate-500 mb-2">No se encontraron clientes</h3>
                <p className="text-slate-400">Intenta ajustar los filtros de búsqueda</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Transacciones */}
        <TabsContent value="transactions" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Historial de Transacciones</CardTitle>
              <CardDescription>Todas las transacciones de clientes</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Cliente</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Referencia</TableHead>
                    <TableHead>Descripción</TableHead>
                    <TableHead>Monto</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Fecha</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockTransactions.map(transaction => {
                    const customer = customers.find(c => c.id === transaction.customerId);
                    return (
                      <TableRow key={transaction.id}>
                        <TableCell>
                          <div>
                            <p className="font-medium">{customer?.personalInfo.name}</p>
                            <p className="text-sm text-slate-500">{customer?.personalInfo.company}</p>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={transaction.type === 'payment' ? 'default' : 'secondary'}>
                            {transaction.type === 'rental' ? 'Renta' :
                             transaction.type === 'sale' ? 'Venta' :
                             transaction.type === 'payment' ? 'Pago' : transaction.type}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-mono text-sm">{transaction.referenceNumber}</TableCell>
                        <TableCell>{transaction.description}</TableCell>
                        <TableCell>${transaction.amount.toLocaleString()}</TableCell>
                        <TableCell>
                          <Badge variant={transaction.status === 'completed' ? 'default' : 'secondary'}>
                            {transaction.status === 'completed' ? 'Completada' : transaction.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{new Date(transaction.transactionDate).toLocaleDateString()}</TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Satisfacción */}
        <TabsContent value="satisfaction" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Encuestas de Satisfacción</CardTitle>
              <CardDescription>Gestión de la satisfacción del cliente</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <MessageSquare className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-slate-500 mb-2">Módulo de Satisfacción</h3>
                <p className="text-slate-400">Las encuestas de satisfacción se mostrarán aquí</p>
                <Button 
                  className="mt-4"
                  onClick={() => setIsSurveyOpen(true)}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Nueva Encuesta
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Formulario de cliente */}
      <Dialog open={isCustomerFormOpen} onOpenChange={setIsCustomerFormOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingCustomer ? 'Editar Cliente' : 'Nuevo Cliente'}
            </DialogTitle>
            <DialogDescription>
              {editingCustomer 
                ? 'Modifica la información del cliente'
                : 'Completa la información para crear un nuevo cliente'
              }
            </DialogDescription>
          </DialogHeader>
          <CustomerForm
            customer={editingCustomer}
            onSubmit={editingCustomer ? handleUpdateCustomer : handleCreateCustomer}
            onCancel={() => {
              setIsCustomerFormOpen(false);
              setEditingCustomer(null);
            }}
          />
        </DialogContent>
      </Dialog>

      {/* Detalles del cliente */}
      <Dialog open={isCustomerDetailsOpen} onOpenChange={setIsCustomerDetailsOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Detalles del Cliente</DialogTitle>
          </DialogHeader>
          {selectedCustomer && (
            <CustomerDetails
              customer={selectedCustomer}
              transactions={mockTransactions.filter(t => t.customerId === selectedCustomer.id)}
              onEdit={() => {
                setIsCustomerDetailsOpen(false);
                handleEditCustomer(selectedCustomer);
              }}
              onClose={() => setIsCustomerDetailsOpen(false)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Encuesta de satisfacción */}
      <Dialog open={isSurveyOpen} onOpenChange={setIsSurveyOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Encuesta de Satisfacción</DialogTitle>
            <DialogDescription>
              {selectedCustomer ? `Evalúa la satisfacción de ${selectedCustomer.personalInfo.name}` : 'Nueva encuesta de satisfacción'}
            </DialogDescription>
          </DialogHeader>
          <SatisfactionSurvey
            customer={selectedCustomer}
            onSubmit={(survey) => {
              console.log('Nueva encuesta:', survey);
              setIsSurveyOpen(false);
            }}
            onCancel={() => setIsSurveyOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}