import { Save, Plus, FileText, User, Settings, Download, Database, CheckCircle, Package, Users, BarChart3 } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { AdvisorInfo } from '../types/quotation';

interface HeaderProps {
  advisor: AdvisorInfo;
  quotationNumber: string;
  status: 'draft' | 'generated' | 'sent' | 'approved' | 'rejected' | 'invoiced' | 'contracted';
  savedToPdf: boolean;
  savedToSystem: boolean;
  onSaveDraft: () => void;
  onSavePDF: () => void;
  onSaveToSystem: () => void;
  onStartNew: () => void;
  title?: string;
  onGoToScaffoldingInventory?: () => void;
  onGoToCustomerManagement?: () => void;
  onGoToAnalytics?: () => void;
  showModuleButtons?: boolean;
}

export function Header({ 
  advisor, 
  quotationNumber, 
  status, 
  savedToPdf,
  savedToSystem,
  onSaveDraft, 
  onSavePDF,
  onSaveToSystem,
  onStartNew,
  title = 'Sistema de Cotizaciones',
  onGoToScaffoldingInventory,
  onGoToCustomerManagement,
  onGoToAnalytics,
  showModuleButtons = false
}: HeaderProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'draft':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'generated':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'sent':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'approved':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'rejected':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'invoiced':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'contracted':
        return 'bg-indigo-100 text-indigo-800 border-indigo-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'draft':
        return 'Borrador';
      case 'generated':
        return 'Generada';
      case 'sent':
        return 'Enviada';
      case 'approved':
        return 'Aprobada';
      case 'rejected':
        return 'Rechazada';
      case 'invoiced':
        return 'Facturada';
      case 'contracted':
        return 'Contratada';
      default:
        return status;
    }
  };

  // Determinar icono según el tipo de sistema
  const getSystemIcon = () => {
    if (title.includes('Arrendamiento')) {
      return '🏗️';
    } else if (title.includes('Ventas')) {
      return '🛒';
    } else if (title.includes('Servicios')) {
      return '🔧';
    } else if (title.includes('Andamios')) {
      return '🏗️';
    }
    return '📋';
  };

  return (
    <header className="bg-white border-b border-slate-200 px-6 py-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between">
          {/* Logo y título */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-600 text-white p-2 rounded-lg">
                <FileText className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-slate-800">{title}</h1>
                <p className="text-sm text-slate-500">RentalPro ERP {getSystemIcon()}</p>
              </div>
            </div>
            
            {/* Información de la cotización */}
            <div className="hidden md:flex items-center space-x-4 ml-8 pl-8 border-l border-slate-200">
              <div className="flex items-center space-x-2">
                <span className="text-sm text-slate-600">Cotización:</span>
                <span className="font-mono text-sm font-medium text-slate-800">{quotationNumber}</span>
              </div>
              <Badge className={getStatusColor(status)}>
                {getStatusText(status)}
              </Badge>
            </div>
          </div>

          {/* Información del asesor y acciones */}
          <div className="flex items-center space-x-4">
            {/* Acciones rápidas */}
            <div className="hidden lg:flex items-center space-x-2">
              {showModuleButtons && (
                <>
                  {onGoToScaffoldingInventory && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={onGoToScaffoldingInventory}
                      className="text-orange-600 border-orange-300 hover:bg-orange-50"
                    >
                      <Package className="w-4 h-4 mr-2" />
                      Inventario
                    </Button>
                  )}
                  {onGoToCustomerManagement && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={onGoToCustomerManagement}
                      className="text-green-600 border-green-300 hover:bg-green-50"
                    >
                      <Users className="w-4 h-4 mr-2" />
                      Clientes
                    </Button>
                  )}
                  {onGoToAnalytics && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={onGoToAnalytics}
                      className="text-purple-600 border-purple-300 hover:bg-purple-50"
                    >
                      <BarChart3 className="w-4 h-4 mr-2" />
                      Análisis
                    </Button>
                  )}
                </>
              )}
              <Button
                variant="outline"
                size="sm"
                onClick={onSavePDF}
                className={`${savedToPdf ? 'text-green-600 border-green-300 bg-green-50' : 'text-blue-600 border-blue-300'}`}
              >
                {savedToPdf ? <CheckCircle className="w-4 h-4 mr-2" /> : <Download className="w-4 h-4 mr-2" />}
                PDF
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={onSaveToSystem}
                className={`${savedToSystem ? 'text-green-600 border-green-300 bg-green-50' : 'text-slate-600 border-slate-300'}`}
              >
                {savedToSystem ? <CheckCircle className="w-4 h-4 mr-2" /> : <Database className="w-4 h-4 mr-2" />}
                Sistema
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={onSaveDraft}
                className="text-slate-600 border-slate-300"
              >
                <Save className="w-4 h-4 mr-2" />
                Guardar
              </Button>
            </div>

            {/* Acciones móviles */}
            <div className="lg:hidden flex items-center space-x-2">
              <Button variant="outline" size="sm" onClick={onSavePDF}>
                {savedToPdf ? <CheckCircle className="w-4 h-4" /> : <Download className="w-4 h-4" />}
              </Button>
              <Button variant="outline" size="sm" onClick={onSaveToSystem}>
                {savedToSystem ? <CheckCircle className="w-4 h-4" /> : <Database className="w-4 h-4" />}
              </Button>
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={onStartNew}
              className="text-blue-600 border-blue-300 hover:bg-blue-50"
            >
              <Plus className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Nueva</span>
            </Button>

            {/* Información del asesor */}
            <div className="flex items-center space-x-3 pl-4 border-l border-slate-200">
              <div className="hidden sm:block text-right">
                <p className="text-sm font-medium text-slate-800">{advisor.name}</p>
                <p className="text-xs text-slate-500">{advisor.department}</p>
              </div>
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <User className="w-4 h-4 text-blue-600" />
              </div>
            </div>

            {/* Configuración */}
            <Button variant="ghost" size="sm" className="text-slate-400 hover:text-slate-600">
              <Settings className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Información móvil */}
        <div className="md:hidden mt-3 pt-3 border-t border-slate-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <span className="text-sm text-slate-600">Cotización:</span>
              <span className="font-mono text-sm font-medium text-slate-800">{quotationNumber}</span>
              <Badge className={getStatusColor(status)} size="sm">
                {getStatusText(status)}
              </Badge>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" onClick={onSaveDraft}>
                <Save className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Indicadores de guardado móvil */}
          {(savedToPdf || savedToSystem) && (
            <div className="flex items-center space-x-4 mt-2">
              {savedToPdf && (
                <div className="flex items-center text-xs text-green-600">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  PDF guardado
                </div>
              )}
              {savedToSystem && (
                <div className="flex items-center text-xs text-green-600">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Guardado en sistema
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </header>
  );
}