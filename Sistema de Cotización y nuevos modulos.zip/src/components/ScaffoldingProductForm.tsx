import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Separator } from './ui/separator';
import { Badge } from './ui/badge';
import { Plus, Minus, ImageIcon, X } from 'lucide-react';
import { ScaffoldingProduct, ScaffoldingCategory } from './ScaffoldingInventoryManagement';

interface ScaffoldingProductFormProps {
  product?: ScaffoldingProduct | null;
  categories: ScaffoldingCategory[];
  onSubmit: (productData: Omit<ScaffoldingProduct, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onCancel: () => void;
}

export function ScaffoldingProductForm({ 
  product, 
  categories, 
  onSubmit, 
  onCancel 
}: ScaffoldingProductFormProps) {
  // Estado del formulario
  const [formData, setFormData] = useState({
    sku: '',
    name: '',
    description: '',
    categoryId: '',
    subcategoryId: '',
    brand: '',
    model: '',
    material: '',
    loadCapacity: 0,
    certifications: [] as string[],
    
    // Dimensiones y peso
    weight: 0,
    length: 0,
    width: 0,
    height: 0,
    
    // Precios
    salePrice: 0,
    dailyRentalRate: 0,
    weeklyRentalRate: 0,
    monthlyRentalRate: 0,
    yearlyRentalRate: 0,
    
    // Inventario
    totalStock: 0,
    availableStock: 0,
    rentedStock: 0,
    reservedStock: 0,
    maintenanceStock: 0,
    
    // Estado
    status: 'active' as const,
    condition: 'new' as const,
    
    // Especificaciones técnicas
    specifications: {} as Record<string, any>,
    
    // Imágenes
    images: [] as string[]
  });

  const [newSpecKey, setNewSpecKey] = useState('');
  const [newSpecValue, setNewSpecValue] = useState('');
  const [newCertification, setNewCertification] = useState('');
  const [newImageUrl, setNewImageUrl] = useState('');

  // Cargar datos del producto en edición
  useEffect(() => {
    if (product) {
      setFormData({
        sku: product.sku,
        name: product.name,
        description: product.description,
        categoryId: product.categoryId,
        subcategoryId: product.subcategoryId || '',
        brand: product.brand,
        model: product.model,
        material: product.material,
        loadCapacity: product.loadCapacity,
        certifications: product.certifications,
        weight: product.weight,
        length: product.dimensions.length,
        width: product.dimensions.width,
        height: product.dimensions.height,
        salePrice: product.salePrice,
        dailyRentalRate: product.dailyRentalRate,
        weeklyRentalRate: product.weeklyRentalRate,
        monthlyRentalRate: product.monthlyRentalRate,
        yearlyRentalRate: product.yearlyRentalRate,
        totalStock: product.totalStock,
        availableStock: product.availableStock,
        rentedStock: product.rentedStock,
        reservedStock: product.reservedStock,
        maintenanceStock: product.maintenanceStock,
        status: product.status,
        condition: product.condition,
        specifications: product.specifications,
        images: product.images
      });
    }
  }, [product]);

  // Subcategorías disponibles
  const availableSubcategories = categories.filter(cat => 
    cat.isSubcategory && cat.parentId === formData.categoryId
  );

  // Handlers
  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSpecificationAdd = () => {
    if (newSpecKey.trim() && newSpecValue.trim()) {
      setFormData(prev => ({
        ...prev,
        specifications: {
          ...prev.specifications,
          [newSpecKey.trim()]: newSpecValue.trim()
        }
      }));
      setNewSpecKey('');
      setNewSpecValue('');
    }
  };

  const handleSpecificationRemove = (key: string) => {
    setFormData(prev => {
      const newSpecs = { ...prev.specifications };
      delete newSpecs[key];
      return { ...prev, specifications: newSpecs };
    });
  };

  const handleCertificationAdd = () => {
    if (newCertification.trim() && !formData.certifications.includes(newCertification.trim())) {
      setFormData(prev => ({
        ...prev,
        certifications: [...prev.certifications, newCertification.trim()]
      }));
      setNewCertification('');
    }
  };

  const handleCertificationRemove = (certification: string) => {
    setFormData(prev => ({
      ...prev,
      certifications: prev.certifications.filter(cert => cert !== certification)
    }));
  };

  const handleImageAdd = () => {
    if (newImageUrl.trim() && !formData.images.includes(newImageUrl.trim())) {
      setFormData(prev => ({
        ...prev,
        images: [...prev.images, newImageUrl.trim()]
      }));
      setNewImageUrl('');
    }
  };

  const handleImageRemove = (imageUrl: string) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images.filter(img => img !== imageUrl)
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validaciones básicas
    if (!formData.name.trim() || !formData.sku.trim() || !formData.categoryId) {
      alert('Por favor completa los campos obligatorios (Nombre, SKU, Categoría)');
      return;
    }

    // Obtener nombres de categoría
    const category = categories.find(cat => cat.id === formData.categoryId);
    const subcategory = formData.subcategoryId ? 
      categories.find(cat => cat.id === formData.subcategoryId) : undefined;

    // Preparar datos para envío
    const productData: Omit<ScaffoldingProduct, 'id' | 'createdAt' | 'updatedAt'> = {
      sku: formData.sku.trim(),
      name: formData.name.trim(),
      description: formData.description.trim(),
      categoryId: formData.categoryId,
      categoryName: category?.name || '',
      subcategoryId: formData.subcategoryId || undefined,
      subcategoryName: subcategory?.name,
      brand: formData.brand.trim(),
      model: formData.model.trim(),
      material: formData.material.trim(),
      loadCapacity: formData.loadCapacity,
      certifications: formData.certifications,
      specifications: formData.specifications,
      images: formData.images,
      salePrice: formData.salePrice,
      dailyRentalRate: formData.dailyRentalRate,
      weeklyRentalRate: formData.weeklyRentalRate,
      monthlyRentalRate: formData.monthlyRentalRate,
      yearlyRentalRate: formData.yearlyRentalRate,
      totalStock: formData.totalStock,
      availableStock: formData.availableStock,
      rentedStock: formData.rentedStock,
      reservedStock: formData.reservedStock,
      maintenanceStock: formData.maintenanceStock,
      status: formData.status,
      condition: formData.condition,
      weight: formData.weight,
      dimensions: {
        length: formData.length,
        width: formData.width,
        height: formData.height
      }
    };

    onSubmit(productData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Información básica */}
      <Card>
        <CardHeader>
          <CardTitle>Información Básica</CardTitle>
          <CardDescription>Datos principales del producto de andamio</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="sku">SKU *</Label>
              <Input
                id="sku"
                value={formData.sku}
                onChange={(e) => handleInputChange('sku', e.target.value)}
                placeholder="Ej: AND-MAR-001"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="name">Nombre del Producto *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                placeholder="Ej: Marco de Andamio 2.00 x 1.20m"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Descripción</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              placeholder="Descripción detallada del producto..."
              rows={3}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="brand">Marca</Label>
              <Input
                id="brand"
                value={formData.brand}
                onChange={(e) => handleInputChange('brand', e.target.value)}
                placeholder="Ej: ProScaffold"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="model">Modelo</Label>
              <Input
                id="model"
                value={formData.model}
                onChange={(e) => handleInputChange('model', e.target.value)}
                placeholder="Ej: PS-MAR-2012"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="material">Material</Label>
              <Input
                id="material"
                value={formData.material}
                onChange={(e) => handleInputChange('material', e.target.value)}
                placeholder="Ej: Acero galvanizado"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Categorización */}
      <Card>
        <CardHeader>
          <CardTitle>Categorización</CardTitle>
          <CardDescription>Clasificación del producto</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category">Categoría *</Label>
              <Select 
                value={formData.categoryId} 
                onValueChange={(value) => {
                  handleInputChange('categoryId', value);
                  handleInputChange('subcategoryId', '');
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Seleccionar categoría" />
                </SelectTrigger>
                <SelectContent>
                  {categories.filter(cat => !cat.isSubcategory).map(category => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {availableSubcategories.length > 0 && (
              <div className="space-y-2">
                <Label htmlFor="subcategory">Subcategoría</Label>
                <Select 
                  value={formData.subcategoryId} 
                  onValueChange={(value) => handleInputChange('subcategoryId', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar subcategoría" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Sin subcategoría</SelectItem>
                    {availableSubcategories.map(subcategory => (
                      <SelectItem key={subcategory.id} value={subcategory.id}>
                        {subcategory.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Especificaciones técnicas */}
      <Card>
        <CardHeader>
          <CardTitle>Especificaciones Técnicas</CardTitle>
          <CardDescription>Características técnicas del producto</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="weight">Peso (kg)</Label>
              <Input
                id="weight"
                type="number"
                value={formData.weight}
                onChange={(e) => handleInputChange('weight', Number(e.target.value))}
                placeholder="0"
                min="0"
                step="0.1"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="loadCapacity">Capacidad de Carga (kg)</Label>
              <Input
                id="loadCapacity"
                type="number"
                value={formData.loadCapacity}
                onChange={(e) => handleInputChange('loadCapacity', Number(e.target.value))}
                placeholder="0"
                min="0"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Dimensiones</Label>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-1">
                <Label htmlFor="length" className="text-sm">Largo (m)</Label>
                <Input
                  id="length"
                  type="number"
                  value={formData.length}
                  onChange={(e) => handleInputChange('length', Number(e.target.value))}
                  placeholder="0"
                  min="0"
                  step="0.01"
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="width" className="text-sm">Ancho (m)</Label>
                <Input
                  id="width"
                  type="number"
                  value={formData.width}
                  onChange={(e) => handleInputChange('width', Number(e.target.value))}
                  placeholder="0"
                  min="0"
                  step="0.01"
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="height" className="text-sm">Alto (m)</Label>
                <Input
                  id="height"
                  type="number"
                  value={formData.height}
                  onChange={(e) => handleInputChange('height', Number(e.target.value))}
                  placeholder="0"
                  min="0"
                  step="0.01"
                />
              </div>
            </div>
          </div>

          {/* Especificaciones personalizadas */}
          <div className="space-y-3">
            <Label>Especificaciones Adicionales</Label>
            <div className="flex gap-2">
              <Input
                value={newSpecKey}
                onChange={(e) => setNewSpecKey(e.target.value)}
                placeholder="Nombre de la especificación"
                className="flex-1"
              />
              <Input
                value={newSpecValue}
                onChange={(e) => setNewSpecValue(e.target.value)}
                placeholder="Valor"
                className="flex-1"
              />
              <Button 
                type="button" 
                onClick={handleSpecificationAdd}
                size="sm"
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            
            {Object.entries(formData.specifications).length > 0 && (
              <div className="flex flex-wrap gap-2">
                {Object.entries(formData.specifications).map(([key, value]) => (
                  <Badge key={key} variant="secondary" className="flex items-center gap-1">
                    {key}: {value}
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => handleSpecificationRemove(key)}
                      className="h-auto p-0 ml-1 hover:bg-transparent"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Certificaciones */}
          <div className="space-y-3">
            <Label>Certificaciones</Label>
            <div className="flex gap-2">
              <Input
                value={newCertification}
                onChange={(e) => setNewCertification(e.target.value)}
                placeholder="Ej: EN-12811, CE, ISO-9001"
                className="flex-1"
              />
              <Button 
                type="button" 
                onClick={handleCertificationAdd}
                size="sm"
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            
            {formData.certifications.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {formData.certifications.map((cert, index) => (
                  <Badge key={index} variant="secondary" className="flex items-center gap-1">
                    {cert}
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => handleCertificationRemove(cert)}
                      className="h-auto p-0 ml-1 hover:bg-transparent"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </Badge>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Precios */}
      <Card>
        <CardHeader>
          <CardTitle>Precios</CardTitle>
          <CardDescription>Precios de venta y renta</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="salePrice">Precio de Venta ($)</Label>
              <Input
                id="salePrice"
                type="number"
                value={formData.salePrice}
                onChange={(e) => handleInputChange('salePrice', Number(e.target.value))}
                placeholder="0"
                min="0"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dailyRentalRate">Renta Diaria ($)</Label>
              <Input
                id="dailyRentalRate"
                type="number"
                value={formData.dailyRentalRate}
                onChange={(e) => handleInputChange('dailyRentalRate', Number(e.target.value))}
                placeholder="0"
                min="0"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="weeklyRentalRate">Renta Semanal ($)</Label>
              <Input
                id="weeklyRentalRate"
                type="number"
                value={formData.weeklyRentalRate}
                onChange={(e) => handleInputChange('weeklyRentalRate', Number(e.target.value))}
                placeholder="0"
                min="0"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="monthlyRentalRate">Renta Mensual ($)</Label>
              <Input
                id="monthlyRentalRate"
                type="number"
                value={formData.monthlyRentalRate}
                onChange={(e) => handleInputChange('monthlyRentalRate', Number(e.target.value))}
                placeholder="0"
                min="0"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="yearlyRentalRate">Renta Anual ($)</Label>
              <Input
                id="yearlyRentalRate"
                type="number"
                value={formData.yearlyRentalRate}
                onChange={(e) => handleInputChange('yearlyRentalRate', Number(e.target.value))}
                placeholder="0"
                min="0"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Inventario */}
      <Card>
        <CardHeader>
          <CardTitle>Control de Inventario</CardTitle>
          <CardDescription>Cantidades en stock</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            <div className="space-y-2">
              <Label htmlFor="totalStock">Stock Total</Label>
              <Input
                id="totalStock"
                type="number"
                value={formData.totalStock}
                onChange={(e) => handleInputChange('totalStock', Number(e.target.value))}
                placeholder="0"
                min="0"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="availableStock">Disponible</Label>
              <Input
                id="availableStock"
                type="number"
                value={formData.availableStock}
                onChange={(e) => handleInputChange('availableStock', Number(e.target.value))}
                placeholder="0"
                min="0"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="rentedStock">En Renta</Label>
              <Input
                id="rentedStock"
                type="number"
                value={formData.rentedStock}
                onChange={(e) => handleInputChange('rentedStock', Number(e.target.value))}
                placeholder="0"
                min="0"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="reservedStock">Reservado</Label>
              <Input
                id="reservedStock"
                type="number"
                value={formData.reservedStock}
                onChange={(e) => handleInputChange('reservedStock', Number(e.target.value))}
                placeholder="0"
                min="0"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="maintenanceStock">Mantenimiento</Label>
              <Input
                id="maintenanceStock"
                type="number"
                value={formData.maintenanceStock}
                onChange={(e) => handleInputChange('maintenanceStock', Number(e.target.value))}
                placeholder="0"
                min="0"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Estado */}
      <Card>
        <CardHeader>
          <CardTitle>Estado del Producto</CardTitle>
          <CardDescription>Estado actual y condición</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="status">Estado</Label>
              <Select 
                value={formData.status} 
                onValueChange={(value: any) => handleInputChange('status', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Activo</SelectItem>
                  <SelectItem value="inactive">Inactivo</SelectItem>
                  <SelectItem value="discontinued">Descontinuado</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="condition">Condición</Label>
              <Select 
                value={formData.condition} 
                onValueChange={(value: any) => handleInputChange('condition', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="new">Nuevo</SelectItem>
                  <SelectItem value="good">Bueno</SelectItem>
                  <SelectItem value="fair">Regular</SelectItem>
                  <SelectItem value="maintenance">En Mantenimiento</SelectItem>
                  <SelectItem value="damaged">Dañado</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Imágenes */}
      <Card>
        <CardHeader>
          <CardTitle>Imágenes del Producto</CardTitle>
          <CardDescription>URLs de las imágenes del producto</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              value={newImageUrl}
              onChange={(e) => setNewImageUrl(e.target.value)}
              placeholder="URL de la imagen"
              className="flex-1"
            />
            <Button 
              type="button" 
              onClick={handleImageAdd}
              size="sm"
            >
              <ImageIcon className="w-4 h-4 mr-2" />
              Agregar
            </Button>
          </div>
          
          {formData.images.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {formData.images.map((imageUrl, index) => (
                <div key={index} className="relative">
                  <img
                    src={imageUrl}
                    alt={`Imagen ${index + 1}`}
                    className="w-full h-32 object-cover rounded-lg"
                  />
                  <Button
                    type="button"
                    variant="destructive"
                    size="sm"
                    onClick={() => handleImageRemove(imageUrl)}
                    className="absolute top-2 right-2"
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Separator />

      {/* Botones de acción */}
      <div className="flex justify-end gap-3">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancelar
        </Button>
        <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
          {product ? 'Actualizar Producto' : 'Crear Producto'}
        </Button>
      </div>
    </form>
  );
}