import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { Edit, Package, BarChart3, Camera, Award, Ruler, Weight, Settings } from 'lucide-react';
import { ScaffoldingProduct, ScaffoldingCategory } from './ScaffoldingInventoryManagement';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ScaffoldingProductDetailsProps {
  product: ScaffoldingProduct;
  categories: ScaffoldingCategory[];
  onEdit: () => void;
  onClose: () => void;
}

export function ScaffoldingProductDetails({ 
  product, 
  categories, 
  onEdit, 
  onClose 
}: ScaffoldingProductDetailsProps) {
  
  // Obtener nombres de categorías
  const category = categories.find(cat => cat.id === product.categoryId);
  const subcategory = product.subcategoryId ? 
    categories.find(cat => cat.id === product.subcategoryId) : undefined;

  // Calcular porcentajes de stock
  const availablePercentage = product.totalStock > 0 ? (product.availableStock / product.totalStock) * 100 : 0;
  const rentedPercentage = product.totalStock > 0 ? (product.rentedStock / product.totalStock) * 100 : 0;
  const reservedPercentage = product.totalStock > 0 ? (product.reservedStock / product.totalStock) * 100 : 0;
  const maintenancePercentage = product.totalStock > 0 ? (product.maintenanceStock / product.totalStock) * 100 : 0;

  // Utilidades de estado
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'inactive': return 'bg-gray-500';
      case 'discontinued': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case 'new': return 'bg-green-500';
      case 'good': return 'bg-blue-500';
      case 'fair': return 'bg-yellow-500';
      case 'maintenance': return 'bg-orange-500';
      case 'damaged': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getConditionText = (condition: string) => {
    switch (condition) {
      case 'new': return 'Nuevo';
      case 'good': return 'Bueno';
      case 'fair': return 'Regular';
      case 'maintenance': return 'En Mantenimiento';
      case 'damaged': return 'Dañado';
      default: return 'Desconocido';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return 'Activo';
      case 'inactive': return 'Inactivo';
      case 'discontinued': return 'Descontinuado';
      default: return 'Desconocido';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header con información básica */}
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h2 className="text-2xl text-slate-900">{product.name}</h2>
            <Badge variant="outline" className="text-xs">
              {product.sku}
            </Badge>
          </div>
          <p className="text-slate-600 mb-3">{product.description}</p>
          <div className="flex flex-wrap gap-2">
            <Badge variant="secondary">
              {category?.name}
            </Badge>
            {subcategory && (
              <Badge variant="outline">
                {subcategory.name}
              </Badge>
            )}
            <Badge className={getStatusColor(product.status)}>
              {getStatusText(product.status)}
            </Badge>
            <Badge className={getConditionColor(product.condition)}>
              {getConditionText(product.condition)}
            </Badge>
          </div>
        </div>
        <div className="flex gap-2">
          <Button onClick={onEdit} className="bg-blue-600 hover:bg-blue-700">
            <Edit className="w-4 h-4 mr-2" />
            Editar
          </Button>
          <Button variant="outline" onClick={onClose}>
            Cerrar
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <Package className="w-4 h-4" />
            General
          </TabsTrigger>
          <TabsTrigger value="specifications" className="flex items-center gap-2">
            <Settings className="w-4 h-4" />
            Especificaciones
          </TabsTrigger>
          <TabsTrigger value="inventory" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            Inventario
          </TabsTrigger>
          <TabsTrigger value="pricing" className="flex items-center gap-2">
            <Package className="w-4 h-4" />
            Precios
          </TabsTrigger>
          <TabsTrigger value="images" className="flex items-center gap-2">
            <Camera className="w-4 h-4" />
            Imágenes
          </TabsTrigger>
        </TabsList>

        {/* Pestaña General */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Información del producto */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="w-5 h-5" />
                  Información del Producto
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-slate-600">Marca</label>
                    <p className="font-medium">{product.brand || 'No especificada'}</p>
                  </div>
                  <div>
                    <label className="text-sm text-slate-600">Modelo</label>
                    <p className="font-medium">{product.model || 'No especificado'}</p>
                  </div>
                  <div>
                    <label className="text-sm text-slate-600">Material</label>
                    <p className="font-medium">{product.material || 'No especificado'}</p>
                  </div>
                  <div>
                    <label className="text-sm text-slate-600">Capacidad de Carga</label>
                    <p className="font-medium">{product.loadCapacity} kg</p>
                  </div>
                </div>

                <Separator />

                <div>
                  <label className="text-sm text-slate-600">Fechas</label>
                  <div className="grid grid-cols-2 gap-4 mt-2">
                    <div>
                      <span className="text-xs text-slate-500">Creado:</span>
                      <p className="text-sm">{new Date(product.createdAt).toLocaleDateString()}</p>
                    </div>
                    <div>
                      <span className="text-xs text-slate-500">Actualizado:</span>
                      <p className="text-sm">{new Date(product.updatedAt).toLocaleDateString()}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Dimensiones y peso */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Ruler className="w-5 h-5" />
                  Dimensiones y Peso
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-slate-600">Largo</label>
                    <p className="font-medium">{product.dimensions.length} m</p>
                  </div>
                  <div>
                    <label className="text-sm text-slate-600">Ancho</label>
                    <p className="font-medium">{product.dimensions.width} m</p>
                  </div>
                  <div>
                    <label className="text-sm text-slate-600">Alto</label>
                    <p className="font-medium">{product.dimensions.height} m</p>
                  </div>
                  <div>
                    <label className="text-sm text-slate-600 flex items-center gap-1">
                      <Weight className="w-4 h-4" />
                      Peso
                    </label>
                    <p className="font-medium">{product.weight} kg</p>
                  </div>
                </div>

                <Separator />

                <div>
                  <label className="text-sm text-slate-600">Volumen aproximado</label>
                  <p className="font-medium">
                    {(product.dimensions.length * product.dimensions.width * product.dimensions.height).toFixed(2)} m³
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Certificaciones */}
          {product.certifications.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="w-5 h-5" />
                  Certificaciones
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {product.certifications.map((cert, index) => (
                    <Badge key={index} variant="secondary" className="flex items-center gap-1">
                      <Award className="w-3 h-3" />
                      {cert}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Pestaña Especificaciones */}
        <TabsContent value="specifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Especificaciones Técnicas</CardTitle>
              <CardDescription>Características técnicas detalladas del producto</CardDescription>
            </CardHeader>
            <CardContent>
              {Object.keys(product.specifications).length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Especificación</TableHead>
                      <TableHead>Valor</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Object.entries(product.specifications).map(([key, value]) => (
                      <TableRow key={key}>
                        <TableCell className="font-medium">{key}</TableCell>
                        <TableCell>{String(value)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-8">
                  <Settings className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-500">No hay especificaciones técnicas definidas</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Pestaña Inventario */}
        <TabsContent value="inventory" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Resumen de stock */}
            <Card>
              <CardHeader>
                <CardTitle>Resumen de Stock</CardTitle>
                <CardDescription>Distribución actual del inventario</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <div className="text-3xl text-slate-900 mb-1">{product.totalStock}</div>
                  <p className="text-sm text-slate-500">Total de unidades</p>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Disponible</span>
                    <span className="font-medium text-green-600">{product.availableStock}</span>
                  </div>
                  <Progress value={availablePercentage} className="h-2" />

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">En Renta</span>
                    <span className="font-medium text-blue-600">{product.rentedStock}</span>
                  </div>
                  <Progress value={rentedPercentage} className="h-2" />

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Reservado</span>
                    <span className="font-medium text-yellow-600">{product.reservedStock}</span>
                  </div>
                  <Progress value={reservedPercentage} className="h-2" />

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Mantenimiento</span>
                    <span className="font-medium text-orange-600">{product.maintenanceStock}</span>
                  </div>
                  <Progress value={maintenancePercentage} className="h-2" />
                </div>
              </CardContent>
            </Card>

            {/* Estado del inventario */}
            <Card>
              <CardHeader>
                <CardTitle>Estado del Inventario</CardTitle>
                <CardDescription>Información de estado y condición</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-slate-50 rounded-lg">
                    <div className="text-2xl mb-1">{availablePercentage.toFixed(0)}%</div>
                    <p className="text-sm text-slate-600">Disponibilidad</p>
                  </div>
                  <div className="text-center p-4 bg-slate-50 rounded-lg">
                    <div className="text-2xl mb-1">{rentedPercentage.toFixed(0)}%</div>
                    <p className="text-sm text-slate-600">En Uso</p>
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-slate-600">Estado del Producto:</span>
                    <Badge className={getStatusColor(product.status)}>
                      {getStatusText(product.status)}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-slate-600">Condición General:</span>
                    <Badge className={getConditionColor(product.condition)}>
                      {getConditionText(product.condition)}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Pestaña Precios */}
        <TabsContent value="pricing" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Precios de venta */}
            <Card>
              <CardHeader>
                <CardTitle>Precio de Venta</CardTitle>
                <CardDescription>Precio para venta directa</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-3xl text-green-600 mb-2">
                    ${product.salePrice.toLocaleString()}
                  </div>
                  <p className="text-sm text-slate-500">Precio por unidad</p>
                </div>
              </CardContent>
            </Card>

            {/* Precios de renta */}
            <Card>
              <CardHeader>
                <CardTitle>Precios de Renta</CardTitle>
                <CardDescription>Tarifas según período de arrendamiento</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Diario</span>
                    <span className="font-medium">${product.dailyRentalRate.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Semanal</span>
                    <span className="font-medium">${product.weeklyRentalRate.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Mensual</span>
                    <span className="font-medium">${product.monthlyRentalRate.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Anual</span>
                    <span className="font-medium">${product.yearlyRentalRate.toLocaleString()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Análisis de rentabilidad */}
          <Card>
            <CardHeader>
              <CardTitle>Análisis de Rentabilidad</CardTitle>
              <CardDescription>Comparación entre venta y renta</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-slate-50 rounded-lg">
                  <div className="text-xl mb-1">
                    {(product.salePrice / product.monthlyRentalRate).toFixed(1)} meses
                  </div>
                  <p className="text-sm text-slate-600">Para recuperar inversión (renta mensual)</p>
                </div>
                <div className="text-center p-4 bg-slate-50 rounded-lg">
                  <div className="text-xl mb-1">
                    ${(product.monthlyRentalRate * product.rentedStock).toLocaleString()}
                  </div>
                  <p className="text-sm text-slate-600">Ingresos mensuales actuales</p>
                </div>
                <div className="text-center p-4 bg-slate-50 rounded-lg">
                  <div className="text-xl mb-1">
                    ${(product.salePrice * product.totalStock / 1000000).toFixed(1)}M
                  </div>
                  <p className="text-sm text-slate-600">Valor total del inventario</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Pestaña Imágenes */}
        <TabsContent value="images" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Galería de Imágenes</CardTitle>
              <CardDescription>Imágenes del producto</CardDescription>
            </CardHeader>
            <CardContent>
              {product.images.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {product.images.map((imageUrl, index) => (
                    <div key={index} className="relative">
                      <ImageWithFallback
                        src={imageUrl}
                        alt={`${product.name} - Imagen ${index + 1}`}
                        className="w-full h-48 object-cover rounded-lg"
                      />
                      <div className="absolute bottom-2 left-2">
                        <Badge variant="secondary" className="text-xs">
                          {index + 1} / {product.images.length}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Camera className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <h3 className="text-slate-500 mb-2">No hay imágenes disponibles</h3>
                  <p className="text-slate-400">Agrega imágenes del producto para mostrar aquí</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}