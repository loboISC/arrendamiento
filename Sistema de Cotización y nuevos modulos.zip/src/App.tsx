import { useState } from 'react';
import { QuotationTypeSelection } from './components/QuotationTypeSelection';
import { ProductSelection } from './components/ProductSelection';
import { ProductConfiguration } from './components/ProductConfiguration';
import { ServiceSelection } from './components/ServiceSelection';
import { ServiceConfiguration } from './components/ServiceConfiguration';
import { QuotationSummary } from './components/QuotationSummary';
import { Confirmation } from './components/Confirmation';
import { InvoiceGeneration } from './components/InvoiceGeneration';
import { Header } from './components/Header';
import { ScaffoldingInventoryManagement } from './components/ScaffoldingInventoryManagement';
import { RentalContractForm } from './components/RentalContractForm';
import { CustomerManagement } from './components/CustomerManagement';
import { AnalyticsModule } from './components/AnalyticsModule';
import { 
  RentalQuotationState, 
  QuotationType, 
  Product, 
  ProductCategory, 
  Location, 
  RentalItem, 
  SaleItem,
  Accessory,
  RentalContract
} from './types/rental';
import { Service, QuotationItem, ClientInfo, AdvisorInfo, InvoiceInfo } from './types/quotation';

export default function App() {
  // Información del asesor (en un sistema real vendría de autenticación)
  const currentAdvisor: AdvisorInfo = {
    id: 'ADV001',
    name: 'María González',
    email: 'maria.gonzalez@rentalpro.com',
    department: 'Ventas de Equipos'
  };

  // Estado unificado para el sistema de arrendamiento
  const [state, setState] = useState<RentalQuotationState>({
    currentStep: 'type-selection',
    quotationType: 'rental',
    rentalItems: [],
    saleItems: [],
    serviceItems: [],
    clientInfo: {
      name: '',
      company: '',
      phone: '',
      email: '',
      address: '',
      taxId: ''
    },
    advisorInfo: currentAdvisor,
    deliveryInfo: {
      type: 'pickup',
      additionalCost: 0
    },
    quotationNumber: `COT-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`,
    validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    status: 'draft',
    savedToPdf: false,
    savedToSystem: false
  });

  // Estado para navegación a módulos especializados
  const [currentView, setCurrentView] = useState<'main' | 'scaffolding-inventory' | 'customer-management' | 'analytics'>('main');

  // Datos mock para desarrollo
  const mockStats = {
    activeRentals: 45,
    monthlySales: 12,
    pendingServices: 8
  };

  const mockProducts: Product[] = [
    {
      id: 'PROD-001',
      sku: 'AND-EST-001',
      name: 'Andamio Estructural Modular 2m x 2m',
      description: 'Andamio estructural modular de alta resistencia para construcción. Incluye plataformas, barandillas y elementos de fijación.',
      categoryId: 'CAT-001',
      categoryName: 'Andamios',
      brand: 'ProScaffold',
      model: 'ES-152',
      specifications: {
        'Altura máxima': '2m',
        'Carga máxima': '200kg/m²',
        'Material': 'Acero galvanizado',
        'Peso': '25kg'
      },
      images: ['https://images.unsplash.com/photo-1699625809637-31c6f327ac96?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjBzY2FmZm9sZGluZyUyMGVxdWlwbWVudHxlbnwxfHx8fDE3NTYxNTkxMjR8MA&ixlib=rb-4.1.0&q=80&w=1080'],
      salePrice: 850000,
      dailyRentalRate: 15000,
      weeklyRentalRate: 90000,
      monthlyRentalRate: 300000,
      yearlyRentalRate: 3000000,
      totalStock: 50,
      availableStock: 35,
      reservedStock: 10,
      maintenanceStock: 5,
      status: 'active',
      condition: 'good',
      weight: 25,
      dimensions: { length: 2, width: 2, height: 2 },
      createdAt: '2024-01-01',
      updatedAt: '2024-01-15'
    },
    {
      id: 'PROD-002',
      sku: 'TAL-ELE-001',
      name: 'Taladro Percutor Profesional 800W',
      description: 'Taladro percutor de alta potencia ideal para perforación en concreto, ladrillo y metal. Incluye maletín y brocas.',
      categoryId: 'CAT-002',
      categoryName: 'Herramientas Eléctricas',
      brand: 'PowerDrill Pro',
      model: 'PD-800',
      specifications: {
        'Potencia': '800W',
        'Velocidad': '0-3000 RPM',
        'Capacidad mandril': '13mm',
        'Peso': '2.5kg'
      },
      images: ['https://images.unsplash.com/photo-1755168648692-ef8937b7e63e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3dlciUyMHRvb2xzJTIwY29uc3RydWN0aW9uJTIwZHJpbGx8ZW58MXx8fHwxNzU2MTU5MTI4fDA&ixlib=rb-4.1.0&q=80&w=1080'],
      salePrice: 250000,
      dailyRentalRate: 8000,
      weeklyRentalRate: 45000,
      monthlyRentalRate: 150000,
      yearlyRentalRate: 1500000,
      totalStock: 25,
      availableStock: 18,
      reservedStock: 5,
      maintenanceStock: 2,
      status: 'active',
      condition: 'new',
      weight: 2.5,
      dimensions: { length: 0.3, width: 0.1, height: 0.25 },
      createdAt: '2024-01-01',
      updatedAt: '2024-01-15'
    },
    {
      id: 'PROD-003',
      sku: 'GRU-MOV-001',
      name: 'Grúa Torre Móvil 2 Toneladas',
      description: 'Grúa torre móvil autoerigible para construcción. Ideal para proyectos de mediana envergadura con fácil movilización.',
      categoryId: 'CAT-005',
      categoryName: 'Maquinaria Pesada',
      brand: 'CraneTech',
      model: 'CT-2000M',
      specifications: {
        'Capacidad máxima': '2 toneladas',
        'Altura máxima': '25m',
        'Radio máximo': '30m',
        'Base': 'Móvil sobre orugas'
      },
      images: ['https://images.unsplash.com/photo-1710056169848-ce12600ac93a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjBjcmFuZSUyMG1hY2hpbmVyeXxlbnwxfHx8fDE3NTYxNTkxMzF8MA&ixlib=rb-4.1.0&q=80&w=1080'],
      salePrice: 85000000,
      dailyRentalRate: 180000,
      weeklyRentalRate: 1100000,
      monthlyRentalRate: 4000000,
      yearlyRentalRate: 42000000,
      totalStock: 5,
      availableStock: 2,
      reservedStock: 2,
      maintenanceStock: 1,
      status: 'active',
      condition: 'good',
      weight: 8500,
      dimensions: { length: 12, width: 3, height: 4 },
      createdAt: '2024-01-01',
      updatedAt: '2024-01-15'
    },
    {
      id: 'PROD-004',
      sku: 'SEG-CAS-001',
      name: 'Kit Completo de Seguridad Personal',
      description: 'Kit completo de protección personal que incluye casco, arnés, guantes, gafas y botas de seguridad. Certificado CE.',
      categoryId: 'CAT-004',
      categoryName: 'Equipos de Seguridad',
      brand: 'SafetyPro',
      model: 'SP-COMPLETE',
      specifications: {
        'Certificación': 'CE EN397',
        'Tallas': 'S, M, L, XL',
        'Resistencia': 'Clase II',
        'Componentes': '5 elementos'
      },
      images: ['https://images.unsplash.com/photo-1603516270950-26e4f5004ffd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYWZldHklMjBlcXVpcG1lbnQlMjBjb25zdHJ1Y3Rpb24lMjBoZWxtZXR8ZW58MXx8fHwxNzU2MTU5MTM0fDA&ixlib=rb-4.1.0&q=80&w=1080'],
      salePrice: 180000,
      dailyRentalRate: 5000,
      weeklyRentalRate: 28000,
      monthlyRentalRate: 95000,
      yearlyRentalRate: 950000,
      totalStock: 100,
      availableStock: 75,
      reservedStock: 15,
      maintenanceStock: 10,
      status: 'active',
      condition: 'new',
      weight: 3,
      dimensions: { length: 0.4, width: 0.3, height: 0.25 },
      createdAt: '2024-01-01',
      updatedAt: '2024-01-15'
    },
    {
      id: 'PROD-005',
      sku: 'EXC-HID-001',
      name: 'Excavadora Hidráulica 20 Toneladas',
      description: 'Excavadora hidráulica sobre orugas para trabajos pesados de excavación, demolición y movimiento de tierras.',
      categoryId: 'CAT-005',
      categoryName: 'Maquinaria Pesada',
      brand: 'HeavyDig',
      model: 'HD-320',
      specifications: {
        'Peso operativo': '20 toneladas',
        'Potencia motor': '150 HP',
        'Profund. excavación': '6.5m',
        'Capacidad balde': '1.2 m³'
      },
      images: ['https://images.unsplash.com/photo-1642927778267-4e8b787b325a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxleGNhdmF0b3IlMjBoZWF2eSUyMG1hY2hpbmVyeXxlbnwxfHx8fDE3NTYxNTkxMzh8MA&ixlib=rb-4.1.0&q=80&w=1080'],
      salePrice: 120000000,
      dailyRentalRate: 250000,
      weeklyRentalRate: 1500000,
      monthlyRentalRate: 5500000,
      yearlyRentalRate: 58000000,
      totalStock: 3,
      availableStock: 1,
      reservedStock: 1,
      maintenanceStock: 1,
      status: 'active',
      condition: 'good',
      weight: 20000,
      dimensions: { length: 9, width: 2.8, height: 3.2 },
      createdAt: '2024-01-01',
      updatedAt: '2024-01-15'
    },
    {
      id: 'PROD-006',
      sku: 'HER-MAN-001',
      name: 'Set Herramientas Manuales Profesional',
      description: 'Set completo de herramientas manuales para construcción. Incluye martillos, destornilladores, llaves y alicates de alta calidad.',
      categoryId: 'CAT-003',
      categoryName: 'Herramientas Manuales',
      brand: 'ToolMaster',
      model: 'TM-PRO-50',
      specifications: {
        'Cantidad piezas': '50 herramientas',
        'Material': 'Acero al cromo-vanadio',
        'Garantía': '5 años',
        'Estuche': 'Incluido'
      },
      images: ['https://images.unsplash.com/photo-1721250527686-9b31f11bfe3e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYW5kJTIwdG9vbHMlMjBjb25zdHJ1Y3Rpb24lMjB3b3Jrc2hvcHxlbnwxfHx8fDE3NTYxNTkxNDJ8MA&ixlib=rb-4.1.0&q=80&w=1080'],
      salePrice: 350000,
      dailyRentalRate: 8000,
      weeklyRentalRate: 48000,
      monthlyRentalRate: 170000,
      yearlyRentalRate: 1700000,
      totalStock: 30,
      availableStock: 22,
      reservedStock: 5,
      maintenanceStock: 3,
      status: 'active',
      condition: 'new',
      weight: 15,
      dimensions: { length: 0.6, width: 0.4, height: 0.2 },
      createdAt: '2024-01-01',
      updatedAt: '2024-01-15'
    },
    {
      id: 'PROD-007',
      sku: 'AND-COL-001',
      name: 'Andamio Colgante Profesional 6m',
      description: 'Sistema de andamio colgante para trabajos en fachadas y alturas. Incluye poleas, cables de acero y sistema de seguridad.',
      categoryId: 'CAT-001',
      categoryName: 'Andamios',
      brand: 'SkyWork',
      model: 'SW-300',
      specifications: {
        'Capacidad': '300kg',
        'Longitud plataforma': '6m',
        'Certificación': 'CE',
        'Cable': 'Acero galvanizado 8mm'
      },
      images: ['https://images.unsplash.com/photo-1699625809637-31c6f327ac96?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjBzY2FmZm9sZGluZyUyMGVxdWlwbWVudHxlbnwxfHx8fDE3NTYxNTkxMjR8MA&ixlib=rb-4.1.0&q=80&w=1080'],
      salePrice: 2500000,
      dailyRentalRate: 45000,
      weeklyRentalRate: 280000,
      monthlyRentalRate: 900000,
      yearlyRentalRate: 9500000,
      totalStock: 15,
      availableStock: 8,
      reservedStock: 5,
      maintenanceStock: 2,
      status: 'active',
      condition: 'good',
      weight: 120,
      dimensions: { length: 6, width: 0.6, height: 0.8 },
      createdAt: '2024-01-01',
      updatedAt: '2024-01-15'
    },
    {
      id: 'PROD-008',
      sku: 'GEN-ELE-001',
      name: 'Generador Eléctrico Diésel 15KVA',
      description: 'Generador eléctrico diésel silencioso de 15KVA. Ideal para obras de construcción y eventos. Arranque automático.',
      categoryId: 'CAT-002',
      categoryName: 'Herramientas Eléctricas',
      brand: 'PowerGen',
      model: 'PG-15D',
      specifications: {
        'Potencia': '15 KVA',
        'Combustible': 'Diésel',
        'Autonomía': '12 horas',
        'Nivel ruido': '65 dB'
      },
      images: ['https://images.unsplash.com/photo-1755168648692-ef8937b7e63e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3dlciUyMHRvb2xzJTIwY29uc3RydWN0aW9uJTIwZHJpbGx8ZW58MXx8fHwxNzU2MTU5MTI4fDA&ixlib=rb-4.1.0&q=80&w=1080'],
      salePrice: 4500000,
      dailyRentalRate: 85000,
      weeklyRentalRate: 500000,
      monthlyRentalRate: 1800000,
      yearlyRentalRate: 18000000,
      totalStock: 12,
      availableStock: 7,
      reservedStock: 3,
      maintenanceStock: 2,
      status: 'active',
      condition: 'good',
      weight: 450,
      dimensions: { length: 2.2, width: 1.1, height: 1.5 },
      createdAt: '2024-01-01',
      updatedAt: '2024-01-15'
    }
  ];

  const mockCategories: ProductCategory[] = [
    {
      id: 'CAT-001',
      name: 'Andamios',
      description: 'Sistemas de andamiaje y estructuras temporales',
      icon: 'scaffold',
      isActive: true
    },
    {
      id: 'CAT-002',
      name: 'Herramientas Eléctricas',
      description: 'Herramientas de construcción eléctricas',
      icon: 'zap',
      isActive: true
    },
    {
      id: 'CAT-003',
      name: 'Herramientas Manuales',
      description: 'Herramientas de mano y equipos manuales',
      icon: 'wrench',
      isActive: true
    },
    {
      id: 'CAT-004',
      name: 'Equipos de Seguridad',
      description: 'Equipos de protección personal y seguridad',
      icon: 'shield',
      isActive: true
    },
    {
      id: 'CAT-005',
      name: 'Maquinaria Pesada',
      description: 'Equipos y maquinaria de construcción pesada',
      icon: 'truck',
      isActive: true
    }
  ];

  const mockLocations: Location[] = [
    {
      id: 'LOC-001',
      name: 'Sede Principal Bogotá',
      address: 'Cra 50 #100-50',
      city: 'Bogotá',
      state: 'Cundinamarca',
      postalCode: '110111',
      phone: '(1) 234-5678',
      manager: 'Carlos Rodríguez',
      isActive: true
    },
    {
      id: 'LOC-002',
      name: 'Sucursal Medellín',
      address: 'Cra 70 #52-20',
      city: 'Medellín',
      state: 'Antioquia',
      postalCode: '050021',
      phone: '(4) 567-8901',
      manager: 'Ana Martínez',
      isActive: true
    },
    {
      id: 'LOC-003',
      name: 'Punto de Distribución Cali',
      address: 'Av 6N #25-30',
      city: 'Cali',
      state: 'Valle del Cauca',
      postalCode: '760001',
      phone: '(2) 345-6789',
      manager: 'Luis García',
      isActive: true
    }
  ];

  const mockAccessories: Accessory[] = [
    {
      id: 'ACC-001',
      name: 'Kit de Seguridad Básico',
      description: 'Incluye línea de vida, arnés y puntos de anclaje',
      productId: 'PROD-001',
      isRequired: true,
      additionalCost: 25000,
      images: []
    },
    {
      id: 'ACC-002',
      name: 'Ruedas para Andamio',
      description: 'Set de 4 ruedas con freno para movilidad',
      productId: 'PROD-001',
      isRequired: false,
      additionalCost: 15000,
      images: []
    },
    {
      id: 'ACC-003',
      name: 'Brocas Adicionales',
      description: 'Set de 10 brocas para concreto y metal',
      productId: 'PROD-002',
      isRequired: false,
      additionalCost: 35000,
      images: []
    },
    {
      id: 'ACC-004',
      name: 'Cables de Extensión',
      description: 'Cable de extensión de 50m para uso en obra',
      productId: 'PROD-008',
      isRequired: false,
      additionalCost: 45000,
      images: []
    }
  ];

  const [selectedLocation, setSelectedLocation] = useState<Location>();
  const [selectedProduct, setSelectedProduct] = useState<Product>();

  // Handlers principales
  const handleTypeSelect = (type: QuotationType) => {
    setState(prev => ({
      ...prev,
      quotationType: type,
      currentStep: type === 'service' ? 'service-selection' : 'product-selection'
    }));
  };

  const handleProductSelect = (product: Product) => {
    setSelectedProduct(product);
    setState(prev => ({
      ...prev,
      currentStep: 'configuration'
    }));
  };

  const handleServiceSelect = (service: Service) => {
    setState(prev => ({
      ...prev,
      currentStep: 'service-configuration'
    }));
  };

  const handleAddRentalItem = (item: RentalItem) => {
    setState(prev => ({
      ...prev,
      rentalItems: [...prev.rentalItems, item],
      currentStep: 'summary'
    }));
  };

  const handleAddSaleItem = (item: SaleItem) => {
    setState(prev => ({
      ...prev,
      saleItems: [...prev.saleItems, item],
      currentStep: 'summary'
    }));
  };

  const handleAddServiceItem = (item: QuotationItem) => {
    setState(prev => ({
      ...prev,
      serviceItems: [...prev.serviceItems, item],
      currentStep: 'summary'
    }));
  };

  const handleRemoveItem = (itemId: string) => {
    setState(prev => ({
      ...prev,
      rentalItems: prev.rentalItems.filter(item => item.id !== itemId),
      saleItems: prev.saleItems.filter(item => item.id !== itemId),
      serviceItems: prev.serviceItems.filter(item => item.id !== itemId)
    }));
  };

  const handleUpdateClientInfo = (clientInfo: ClientInfo) => {
    setState(prev => ({
      ...prev,
      clientInfo
    }));
  };

  const handleGenerateQuotation = () => {
    setState(prev => ({
      ...prev,
      currentStep: 'confirmation',
      status: 'generated'
    }));
  };

  const handleGenerateInvoice = (invoiceInfo: InvoiceInfo) => {
    setState(prev => ({
      ...prev,
      invoiceInfo,
      status: 'invoiced'
    }));
  };

  // Handler para contrato de renta
  const handleGenerateContract = (contract: Omit<RentalContract, 'id' | 'createdAt' | 'updatedAt'>) => {
    console.log('Generando contrato...', contract);
    // Aquí se guardaría el contrato en el sistema
    setState(prev => ({
      ...prev,
      status: 'contracted'
    }));
  };

  const handleGoToContract = () => {
    setState(prev => ({
      ...prev,
      currentStep: 'contract'
    }));
  };

  // Navigation handlers
  const handleBackToTypeSelection = () => {
    setState(prev => ({
      ...prev,
      currentStep: 'type-selection',
      quotationType: 'rental'
    }));
  };

  const handleBackToProductSelection = () => {
    setState(prev => ({
      ...prev,
      currentStep: 'product-selection'
    }));
    setSelectedProduct(undefined);
  };

  const handleBackToSummary = () => {
    setState(prev => ({
      ...prev,
      currentStep: 'summary'
    }));
  };

  const handleGoToInvoice = () => {
    setState(prev => ({
      ...prev,
      currentStep: 'invoice'
    }));
  };

  const handleBackToConfirmation = () => {
    setState(prev => ({
      ...prev,
      currentStep: 'confirmation'
    }));
  };

  const handleStartNew = () => {
    setState({
      currentStep: 'type-selection',
      quotationType: 'rental',
      rentalItems: [],
      saleItems: [],
      serviceItems: [],
      clientInfo: {
        name: '',
        company: '',
        phone: '',
        email: '',
        address: '',
        taxId: ''
      },
      advisorInfo: currentAdvisor,
      deliveryInfo: {
        type: 'pickup',
        additionalCost: 0
      },
      quotationNumber: `COT-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`,
      validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      status: 'draft',
      savedToPdf: false,
      savedToSystem: false
    });
    setSelectedLocation(undefined);
    setSelectedProduct(undefined);
  };

  // Save handlers
  const handleSaveDraft = () => {
    setState(prev => ({ ...prev, savedToSystem: true }));
    console.log('Guardando borrador...', state);
  };

  const handleSavePDF = () => {
    setState(prev => ({ ...prev, savedToPdf: true }));
    console.log('Generando PDF...', state);
    
    // Simular descarga
    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent('PDF Content'));
    element.setAttribute('download', `${state.quotationNumber}.pdf`);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleSaveToSystem = () => {
    setState(prev => ({ ...prev, savedToSystem: true }));
    console.log('Guardando en sistema...', state);
  };

  const getHeaderTitle = () => {
    switch (currentView) {
      case 'scaffolding-inventory':
        return 'Gestión de Inventario - Andamios';
      case 'customer-management':
        return 'Gestión de Clientes';
      case 'analytics':
        return 'Análisis y Métricas';
      default:
        break;
    }
    
    switch (state.quotationType) {
      case 'rental':
        return 'Sistema de Arrendamiento';
      case 'sale':
        return 'Sistema de Ventas';
      case 'service':
        return 'Sistema de Servicios';
      default:
        return 'Sistema ERP';
    }
  };

  // Handlers para navegación a módulos especializados
  const handleGoToScaffoldingInventory = () => {
    setCurrentView('scaffolding-inventory');
  };

  const handleGoToCustomerManagement = () => {
    setCurrentView('customer-management');
  };

  const handleGoToAnalytics = () => {
    setCurrentView('analytics');
  };

  const handleBackToMain = () => {
    setCurrentView('main');
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Header 
        advisor={state.advisorInfo}
        quotationNumber={state.quotationNumber}
        status={state.status}
        savedToPdf={state.savedToPdf}
        savedToSystem={state.savedToSystem}
        onSaveDraft={handleSaveDraft}
        onSavePDF={handleSavePDF}
        onSaveToSystem={handleSaveToSystem}
        onStartNew={handleStartNew}
        title={getHeaderTitle()}
        // Agregar props para navegación a módulos especializados
        onGoToScaffoldingInventory={handleGoToScaffoldingInventory}
        onGoToCustomerManagement={handleGoToCustomerManagement}
        onGoToAnalytics={handleGoToAnalytics}
        showModuleButtons={currentView === 'main'}
      />
      
      <main className="pt-4">
        {/* Módulo de gestión de inventario de andamios */}
        {currentView === 'scaffolding-inventory' && (
          <ScaffoldingInventoryManagement 
            onBack={handleBackToMain}
          />
        )}

        {/* Módulo de gestión de clientes */}
        {currentView === 'customer-management' && (
          <CustomerManagement 
            onBack={handleBackToMain}
          />
        )}

        {/* Módulo de análisis */}
        {currentView === 'analytics' && (
          <AnalyticsModule 
            onBack={handleBackToMain}
          />
        )}

        {/* Vista principal del sistema */}
        {currentView === 'main' && (
          <>
            {/* Selección de tipo de cotización */}
            {state.currentStep === 'type-selection' && (
              <QuotationTypeSelection 
                onTypeSelect={handleTypeSelect}
                stats={mockStats}
              />
            )}

        {/* Selección de productos (para renta y venta) */}
        {state.currentStep === 'product-selection' && (
          <ProductSelection
            quotationType={state.quotationType}
            products={mockProducts}
            categories={mockCategories}
            locations={mockLocations}
            onProductSelect={handleProductSelect}
            onBack={handleBackToTypeSelection}
            selectedLocation={selectedLocation}
            onLocationChange={setSelectedLocation}
          />
        )}

        {/* Configuración de productos */}
        {state.currentStep === 'configuration' && selectedProduct && (
          <ProductConfiguration
            quotationType={state.quotationType}
            product={selectedProduct}
            accessories={mockAccessories.filter(acc => acc.productId === selectedProduct.id)}
            onAddItem={state.quotationType === 'rental' ? handleAddRentalItem : handleAddSaleItem}
            onBack={handleBackToProductSelection}
          />
        )}

        {/* Selección de servicios (sistema existente) */}
        {state.currentStep === 'service-selection' && (
          <ServiceSelection 
            onServiceSelect={handleServiceSelect}
            quotationItemsCount={state.serviceItems.length}
            onGoToSummary={() => setState(prev => ({ ...prev, currentStep: 'summary' }))}
          />
        )}
        
        {/* Configuración de servicios (sistema existente) */}
        {state.currentStep === 'service-configuration' && (
          <ServiceConfiguration
            service={{} as Service} // Implementar según necesidades
            onAddToQuotation={handleAddServiceItem}
            onBack={() => setState(prev => ({ ...prev, currentStep: 'service-selection' }))}
          />
        )}
        
        {/* Resumen de cotización - adaptado para múltiples tipos */}
        {state.currentStep === 'summary' && (
          <QuotationSummary
            quotationItems={state.serviceItems}
            clientInfo={state.clientInfo}
            quotationNumber={state.quotationNumber}
            validUntil={state.validUntil}
            advisor={state.advisorInfo}
            onRemoveItem={handleRemoveItem}
            onUpdateClientInfo={handleUpdateClientInfo}
            onGenerate={handleGenerateQuotation}
            onAddMoreServices={() => setState(prev => ({ ...prev, currentStep: state.quotationType === 'service' ? 'service-selection' : 'product-selection' }))}
            onSavePDF={handleSavePDF}
            onSaveToSystem={handleSaveToSystem}
            // Props adicionales para renta/venta
            rentalItems={state.rentalItems}
            saleItems={state.saleItems}
            quotationType={state.quotationType}
          />
        )}
        
        {/* Confirmación */}
        {state.currentStep === 'confirmation' && (
          <Confirmation
            quotationNumber={state.quotationNumber}
            clientInfo={state.clientInfo}
            advisor={state.advisorInfo}
            onStartNew={handleStartNew}
            onBackToSummary={handleBackToSummary}
            onGoToInvoice={handleGoToInvoice}
            onSavePDF={handleSavePDF}
            onSaveToSystem={handleSaveToSystem}
            // Agregar props para contratos de renta
            quotationType={state.quotationType}
            onGoToContract={state.quotationType === 'rental' ? handleGoToContract : undefined}
          />
        )}

        {/* Formulario de contrato de renta */}
        {state.currentStep === 'contract' && state.quotationType === 'rental' && (
          <RentalContractForm
            rentalItems={state.rentalItems}
            clientInfo={state.clientInfo}
            advisorInfo={state.advisorInfo}
            quotationNumber={state.quotationNumber}
            onSubmit={handleGenerateContract}
            onBack={handleBackToConfirmation}
          />
        )}

        {/* Generación de factura */}
        {state.currentStep === 'invoice' && (
          <InvoiceGeneration
            quotationItems={state.serviceItems}
            clientInfo={state.clientInfo}
            quotationNumber={state.quotationNumber}
            advisor={state.advisorInfo}
            onGenerateInvoice={handleGenerateInvoice}
            onBack={handleBackToConfirmation}
            onSavePDF={handleSavePDF}
            onSaveToSystem={handleSaveToSystem}
          />
        )}
          </>
        )}
      </main>
    </div>
  );
}